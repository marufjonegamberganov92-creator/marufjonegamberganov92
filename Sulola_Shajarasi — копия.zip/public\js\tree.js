/**
 * Shajara Interaktiv Daraxt Vizualizatsiyasi Dvigateli — 2.0 (Motion)
 * ------------------------------------------------------------------
 * Eski API to'liq saqlangan: setData, setRoot, render, toggleCollapse,
 * selectNode, highlightLineage, clearHighlight, focusOnMember, zoomIn,
 * zoomOut, resetZoom, fitToScreen, renderedNodes.
 *
 * Yangi imkoniyatlar:
 *  - "O'sish" animatsiyasi: kartalar avlodma-avlod paydo bo'ladi, chiziqlar chizilib boradi
 *  - Yig'ish/ochishda kartalar yangi joyiga silliq suriladi (FLIP)
 *  - Yumaloq burchakli shajara chiziqlari
 *  - Ajdodlar yo'lida oqib yuruvchi oltin uchqunlar
 *  - Avlod qatlamlari (fon chiziqlari va yorliqlar)
 *  - Mini-xarita (navigatsiya)
 *  - Vaqt mashinasi: setTimeYear(yil) — o'sha yilgacha tug'ilganlar ko'rinadi
 *  - Zoom ko'rsatkichi, klaviatura (+ − 0 F, strelkalar), ikki marta bosish = markazlash
 *  - Yashirin tabda yaratilsa ham to'g'ri markazlashadi (ResizeObserver)
 */

const esc = (v) => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const SVG_NS = 'http://www.w3.org/2000/svg';
const prefersReducedMotion = () => {
  try { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; }
};

class ShajaraTree {
  constructor(containerId, options = {}) {
    this.container = document.getElementById(containerId);
    if (!this.container) throw new Error(`Container #${containerId} topilmadi`);

    this.options = {
      singleCardWidth: 230,
      coupleCardWidth: 430,
      cardHeight: 125,
      horizontalGap: 45,
      verticalGap: 95,
      cornerRadius: 16,
      showMinimap: true,
      showGenerationBands: true,
      onNodeClick: options.onNodeClick || (() => {}),
      ...options
    };

    this.members = [];
    this.memberMap = new Map();
    this.rootId = null;
    this.collapsedIds = new Set();
    this.selectedNodeId = null;
    this.highlightedAncestors = new Set();
    this.timeYear = null;
    this.prevPositions = new Map();
    this.hasRenderedOnce = false;
    this.pendingFit = false;

    // Pan & Zoom state
    this.scale = 1;
    this.translateX = 0;
    this.translateY = 0;
    this.isDragging = false;
    this.startX = 0;
    this.startY = 0;
    this.animationFrameId = null;
    this.morphFrameId = null;

    this.initDOM();
    this.bindEvents();

    // Boshqa skriptlar (motion.js) uchun ro'yxatga olish
    ShajaraTree.instances.push(this);
    if (!window.shajaraTree) window.shajaraTree = this;
    document.dispatchEvent(new CustomEvent('shajara:tree-ready', { detail: { tree: this } }));
  }

  /* ============================== DOM ============================== */

  initDOM() {
    this.container.innerHTML = '';
    this.container.classList.add('tree-container');

    this.svg = document.createElementNS(SVG_NS, 'svg');
    this.svg.classList.add('tree-svg');

    const defs = document.createElementNS(SVG_NS, 'defs');
    defs.innerHTML = `
      <linearGradient id="linkGradGold" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="#f3c969"/>
        <stop offset="100%" stop-color="#c8912b"/>
      </linearGradient>
      <radialGradient id="sparkGrad">
        <stop offset="0%" stop-color="#fffbe8"/>
        <stop offset="45%" stop-color="#f6c453"/>
        <stop offset="100%" stop-color="rgba(200,145,43,0)"/>
      </radialGradient>
      <filter id="royalGlow" x="-50%" y="-50%" width="200%" height="200%">
        <feGaussianBlur stdDeviation="3" result="blur" />
        <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
      </filter>
    `;
    this.svg.appendChild(defs);

    this.viewport = document.createElementNS(SVG_NS, 'g');
    this.viewport.setAttribute('class', 'tree-viewport');

    this.bandsGroup = document.createElementNS(SVG_NS, 'g');
    this.bandsGroup.setAttribute('class', 'tree-bands');

    this.effectsGroup = document.createElementNS(SVG_NS, 'g');
    this.effectsGroup.setAttribute('class', 'tree-effects');

    this.linksGroup = document.createElementNS(SVG_NS, 'g');
    this.linksGroup.setAttribute('class', 'tree-links');

    this.sparksGroup = document.createElementNS(SVG_NS, 'g');
    this.sparksGroup.setAttribute('class', 'tree-sparks');

    this.nodesGroup = document.createElementNS(SVG_NS, 'g');
    this.nodesGroup.setAttribute('class', 'tree-nodes');

    this.viewport.appendChild(this.bandsGroup);
    this.viewport.appendChild(this.effectsGroup);
    this.viewport.appendChild(this.linksGroup);
    this.viewport.appendChild(this.sparksGroup);
    this.viewport.appendChild(this.nodesGroup);
    this.svg.appendChild(this.viewport);
    this.container.appendChild(this.svg);

    // Bo'sh holat (HTML qatlam)
    this.emptyEl = document.createElement('div');
    this.emptyEl.className = 'tree-empty-state hidden';
    this.emptyEl.innerHTML = `
      <div class="tree-empty-icon">
        <svg viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <path class="draw" d="M32 58V34"/><path class="draw" d="M32 40c-8 0-14-6-14-14"/><path class="draw" d="M32 34c8 0 14-6 14-14"/>
          <circle class="pop" cx="18" cy="22" r="5"/><circle class="pop" cx="46" cy="16" r="5"/><circle class="pop" cx="32" cy="12" r="6"/>
        </svg>
      </div>
      <h3>Shajara hali bo‘sh</h3>
      <p>Admin panelidan birinchi ajdodni qo‘shing — daraxt shu yerdan o‘sib chiqadi.</p>`;
    this.container.appendChild(this.emptyEl);

    // Zoom ko'rsatkichi
    this.zoomHud = document.createElement('div');
    this.zoomHud.className = 'tree-zoom-hud no-print';
    this.container.appendChild(this.zoomHud);

    // Vaqt mashinasi yil ko'rsatkichi
    this.yearHud = document.createElement('div');
    this.yearHud.className = 'tree-year-hud no-print';
    this.container.appendChild(this.yearHud);

    if (this.options.showMinimap) this.initMinimap();
  }

  initMinimap() {
    this.minimap = document.createElement('div');
    this.minimap.className = 'tree-minimap no-print';
    this.minimap.innerHTML = `
      <div class="tree-minimap-head">
        <span>Xarita</span>
        <button type="button" class="tree-minimap-toggle" title="Xaritani yig‘ish">–</button>
      </div>
      <canvas width="200" height="130"></canvas>`;
    this.container.appendChild(this.minimap);
    this.minimapCanvas = this.minimap.querySelector('canvas');
    this.minimapCtx = this.minimapCanvas.getContext('2d');

    const toggle = this.minimap.querySelector('.tree-minimap-toggle');
    toggle.addEventListener('click', (e) => {
      e.stopPropagation();
      this.minimap.classList.toggle('collapsed');
      toggle.textContent = this.minimap.classList.contains('collapsed') ? '+' : '–';
      this.scheduleMinimap();
    });

    const navigate = (e) => {
      if (!this.minimapState) return;
      const r = this.minimapCanvas.getBoundingClientRect();
      const { minX, minY, k, ox, oy } = this.minimapState;
      const treeX = (e.clientX - r.left - ox) / k + minX;
      const treeY = (e.clientY - r.top - oy) / k + minY;
      const rect = this.container.getBoundingClientRect();
      this.cancelAnimation();
      this.translateX = rect.width / 2 - treeX * this.scale;
      this.translateY = rect.height / 2 - treeY * this.scale;
      this.applyTransform();
    };
    let mmDrag = false;
    this.minimapCanvas.addEventListener('mousedown', (e) => { e.stopPropagation(); mmDrag = true; navigate(e); });
    window.addEventListener('mousemove', (e) => { if (mmDrag) navigate(e); });
    window.addEventListener('mouseup', () => { mmDrag = false; });
    this.minimap.addEventListener('wheel', (e) => e.stopPropagation(), { passive: true });
  }

  /* ============================ EVENTS ============================ */

  bindEvents() {
    this.container.addEventListener('mousedown', (e) => {
      if (e.target.closest('.node-interactive-btn') || e.target.closest('.member-sub-card') ||
          e.target.closest('.node-card') || e.target.closest('.tree-minimap')) {
        return;
      }
      this.cancelAnimation();
      this.isDragging = true;
      this.startX = e.clientX - this.translateX;
      this.startY = e.clientY - this.translateY;
      this.container.classList.add('dragging');
    });

    window.addEventListener('mousemove', (e) => {
      if (!this.isDragging) return;
      this.translateX = e.clientX - this.startX;
      this.translateY = e.clientY - this.startY;
      if (!this._dragRaf) {
        this._dragRaf = requestAnimationFrame(() => {
          this._dragRaf = null;
          this.applyTransform();
        });
      }
    }, { passive: true });

    window.addEventListener('mouseup', () => {
      if (this.isDragging) {
        this.isDragging = false;
        if (this._dragRaf) {
          cancelAnimationFrame(this._dragRaf);
          this._dragRaf = null;
        }
        this.applyTransform();
        this.container.classList.remove('dragging');
      }
    });

    // Bo'sh joyni ikki marta bosish — ekranga moslash
    this.container.addEventListener('dblclick', (e) => {
      if (e.target.closest('.node-card') || e.target.closest('.tree-minimap')) return;
      this.fitToScreen(true);
    });

    this.container.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.cancelAnimation();
      const rect = this.container.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;

      const zoomFactor = e.deltaY < 0 ? 1.12 : 0.88;
      const newScale = Math.min(Math.max(this.scale * zoomFactor, 0.2), 2.5);

      if (newScale !== this.scale) {
        this.translateX = mouseX - (mouseX - this.translateX) * (newScale / this.scale);
        this.translateY = mouseY - (mouseY - this.translateY) * (newScale / this.scale);
        this.scale = newScale;
        this.applyTransform();
        this.flashZoomHud();
      }
    }, { passive: false });

    // Sensorli ekran
    let initialTouchDist = 0;
    this.container.addEventListener('touchstart', (e) => {
      if (e.target.closest('.tree-minimap')) return;
      this.cancelAnimation();
      if (e.touches.length === 1) {
        this.isDragging = true;
        this.startX = e.touches[0].clientX - this.translateX;
        this.startY = e.touches[0].clientY - this.translateY;
      } else if (e.touches.length === 2) {
        this.isDragging = false;
        initialTouchDist = Math.hypot(
          e.touches[0].clientX - e.touches[1].clientX,
          e.touches[0].clientY - e.touches[1].clientY
        );
      }
    }, { passive: true });

    this.container.addEventListener('touchmove', (e) => {
      if (e.touches.length === 1 && this.isDragging) {
        this.translateX = e.touches[0].clientX - this.startX;
        this.translateY = e.touches[0].clientY - this.startY;
        this.applyTransform();
      } else if (e.touches.length === 2) {
        const t0 = e.touches[0], t1 = e.touches[1];
        const currentDist = Math.hypot(t0.clientX - t1.clientX, t0.clientY - t1.clientY);
        if (initialTouchDist > 0) {
          const rect = this.container.getBoundingClientRect();
          const cx = (t0.clientX + t1.clientX) / 2 - rect.left;
          const cy = (t0.clientY + t1.clientY) / 2 - rect.top;
          const newScale = Math.min(Math.max(this.scale * (currentDist / initialTouchDist), 0.2), 2.5);
          this.translateX = cx - (cx - this.translateX) * (newScale / this.scale);
          this.translateY = cy - (cy - this.translateY) * (newScale / this.scale);
          this.scale = newScale;
          initialTouchDist = currentDist;
          this.applyTransform();
          this.flashZoomHud();
        }
      }
    }, { passive: true });

    this.container.addEventListener('touchend', () => { this.isDragging = false; });

    window.addEventListener('resize', () => this.updateDimensions());

    // Yashirin tabdan ko'rinadigan holatga o'tganda kechiktirilgan markazlash
    if ('ResizeObserver' in window) {
      this.resizeObserver = new ResizeObserver(() => {
        this.updateDimensions();
        if (this.pendingFit && this.isVisible()) {
          this.pendingFit = false;
          this.fitToScreen(false);
        }
      });
      this.resizeObserver.observe(this.container);
    }

    // Klaviatura
    window.addEventListener('keydown', (e) => {
      if (!this.isVisible()) return;
      const t = e.target;
      if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      if (document.querySelector('.modal-overlay:not(.hidden)')) return;
      const step = 70;
      switch (e.key) {
        case '+': case '=': this.zoomIn(); break;
        case '-': case '_': this.zoomOut(); break;
        case '0': case 'f': case 'F': this.fitToScreen(true); break;
        case 'ArrowLeft':  this.panBy(step, 0); break;
        case 'ArrowRight': this.panBy(-step, 0); break;
        case 'ArrowUp':    this.panBy(0, step); break;
        case 'ArrowDown':  this.panBy(0, -step); break;
        default: return;
      }
      e.preventDefault();
    });
  }

  isVisible() {
    const r = this.container.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }

  panBy(dx, dy) {
    this.animateToTransform(this.translateX + dx, this.translateY + dy, this.scale, 180);
  }

  cancelAnimation() {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
  }

  animateToTransform(targetX, targetY, targetScale, duration = 400) {
    this.cancelAnimation();
    if (prefersReducedMotion()) duration = 1;

    const startX = this.translateX;
    const startY = this.translateY;
    const startScale = this.scale;
    const startTime = performance.now();
    const ease = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

    const step = (now) => {
      const progress = Math.min((now - startTime) / duration, 1);
      const e = ease(progress);
      this.translateX = startX + (targetX - startX) * e;
      this.translateY = startY + (targetY - startY) * e;
      this.scale = startScale + (targetScale - startScale) * e;
      this.applyTransform();
      this.animationFrameId = progress < 1 ? requestAnimationFrame(step) : null;
    };
    this.animationFrameId = requestAnimationFrame(step);
    if (Math.abs(targetScale - startScale) > 0.001) this.flashZoomHud(targetScale);
  }

  applyTransform() {
    this.viewport.setAttribute('transform', `translate(${this.translateX}, ${this.translateY}) scale(${this.scale})`);
    // Avlod yorliqlari chap chetga "yopishib" turadi
    if (this.bandLabels) {
      const leftTreeX = (16 - this.translateX) / this.scale;
      const inv = 1 / this.scale;
      this.bandLabels.forEach(lbl => {
        lbl.setAttribute('transform', `translate(${leftTreeX}, ${lbl.dataset.y}) scale(${inv})`);
      });
    }
    this.scheduleMinimap();
  }

  flashZoomHud(value = this.scale) {
    if (!this.zoomHud) return;
    this.zoomHud.textContent = `${Math.round(value * 100)}%`;
    this.zoomHud.classList.add('show');
    clearTimeout(this._zoomHudTimer);
    this._zoomHudTimer = setTimeout(() => this.zoomHud.classList.remove('show'), 900);
  }

  updateDimensions() {
    const rect = this.container.getBoundingClientRect();
    this.svg.setAttribute('width', rect.width);
    this.svg.setAttribute('height', rect.height);
  }

  /* ============================== DATA ============================== */

  setData(members, preferredRootId = null) {
    const prevRoot = this.rootId;
    this.members = members || [];
    this.memberMap.clear();
    this.members.forEach(m => this.memberMap.set(m.id, m));

    if (preferredRootId && this.memberMap.has(preferredRootId)) {
      this.rootId = preferredRootId;
    } else {
      const roots = this.members.filter(m => !m.fatherId && !m.motherId);
      const maleRoot = roots.find(m => m.gender === 'male');
      this.rootId = maleRoot ? maleRoot.id : (roots[0]?.id || this.members[0]?.id || null);
    }

    const first = !this.hasRenderedOnce || prevRoot !== this.rootId;
    if (first) this.prevPositions.clear();
    this.render({ animate: first ? 'grow' : 'morph' });
    if (first) setTimeout(() => this.fitToScreen(false), 60);
    document.dispatchEvent(new CustomEvent('shajara:data', { detail: { tree: this } }));
  }

  setRoot(rootId) {
    if (this.memberMap.has(rootId)) {
      this.rootId = rootId;
      this.prevPositions.clear();
      this.render({ animate: 'grow' });
      setTimeout(() => this.fitToScreen(true), 60);
    }
  }

  getMembers() { return this.members.slice(); }

  getChildren(parentId) {
    return this.members.filter(m => m.fatherId === parentId || m.motherId === parentId)
      .sort((a, b) => (a.birthYear || 9999) - (b.birthYear || 9999));
  }

  getPrimarySpouse(memberId) {
    const m = this.memberMap.get(memberId);
    if (!m) return null;
    const spouseId = m.spouseIds?.[0];
    if (spouseId && this.memberMap.has(spouseId)) return this.memberMap.get(spouseId);
    return this.members.find(other => other.spouseIds && other.spouseIds.includes(memberId)) || null;
  }

  getNodeWidth(member) {
    return this.getPrimarySpouse(member.id) ? this.options.coupleCardWidth : this.options.singleCardWidth;
  }

  getYearRange() {
    const years = this.members.map(m => Number(m.birthYear)).filter(y => y > 0);
    const now = new Date().getFullYear();
    if (!years.length) return { min: now - 100, max: now };
    return { min: Math.min(...years), max: Math.max(now, ...years) };
  }

  /* ============================= LAYOUT ============================= */

  computeLayout(rootId) {
    const { cardHeight, horizontalGap, verticalGap } = this.options;
    const layoutNodes = [];
    const layoutLinks = [];
    if (!rootId || !this.memberMap.has(rootId)) return { nodes: [], links: [] };

    const widthCache = new Map();
    const placed = new Set();

    const measureSubtree = (nodeId, guard = new Set()) => {
      if (widthCache.has(nodeId)) return widthCache.get(nodeId);
      const member = this.memberMap.get(nodeId);
      if (!member) return this.options.singleCardWidth;
      const myWidth = this.getNodeWidth(member);
      if (guard.has(nodeId)) return myWidth; // aylanma bog'lanishdan himoya
      guard.add(nodeId);

      const children = this.getChildren(nodeId);
      let result = myWidth;
      if (children.length && !this.collapsedIds.has(nodeId)) {
        let total = 0;
        children.forEach((child, idx) => {
          total += measureSubtree(child.id, guard) + (idx < children.length - 1 ? horizontalGap : 0);
        });
        result = Math.max(myWidth, total);
      }
      guard.delete(nodeId);
      widthCache.set(nodeId, result);
      return result;
    };

    const positionSubtree = (nodeId, startX, currentY, depth, parentId) => {
      const member = this.memberMap.get(nodeId);
      if (!member || placed.has(nodeId)) return;
      placed.add(nodeId);

      const spouse = this.getPrimarySpouse(nodeId);
      const isCouple = !!spouse;
      const nodeWidth = isCouple ? this.options.coupleCardWidth : this.options.singleCardWidth;
      const children = this.getChildren(nodeId);
      const isCollapsed = this.collapsedIds.has(nodeId);
      const subtreeWidth = measureSubtree(nodeId);

      const nodeX = startX + (subtreeWidth - nodeWidth) / 2;
      const nodeY = currentY;

      layoutNodes.push({
        id: member.id, member, spouse, isCouple,
        x: nodeX, y: nodeY, width: nodeWidth, height: cardHeight,
        depth, parentId: parentId || null,
        childrenCount: children.length, isCollapsed
      });

      if (!isCollapsed && children.length > 0) {
        let childX = startX;
        const nextY = currentY + cardHeight + verticalGap;
        const childTargets = [];

        children.forEach(child => {
          const childSubtreeWidth = measureSubtree(child.id);
          const childNodeWidth = this.getNodeWidth(child);
          const childActualX = childX + (childSubtreeWidth - childNodeWidth) / 2;
          childTargets.push({ childId: child.id, x: childActualX + childNodeWidth / 2, y: nextY });
          positionSubtree(child.id, childX, nextY, depth + 1, member.id);
          childX += childSubtreeWidth + horizontalGap;
        });

        layoutLinks.push({
          parentId: member.id,
          px: nodeX + nodeWidth / 2,
          py: nodeY + cardHeight,
          nextY,
          depth,
          children: childTargets
        });
      }
    };

    positionSubtree(rootId, 100, 40, 1, null);
    return { nodes: layoutNodes, links: layoutLinks };
  }

  roundedPath(px, py, midY, cx, cy) {
    const dx = cx - px;
    if (Math.abs(dx) < 0.5) return `M ${px} ${py} L ${cx} ${cy}`;
    const sx = Math.sign(dx);
    const r = Math.min(this.options.cornerRadius, Math.abs(dx) / 2, (midY - py) * 0.9, (cy - midY) * 0.9);
    return `M ${px} ${py} L ${px} ${midY - r} Q ${px} ${midY} ${px + sx * r} ${midY} ` +
           `L ${cx - sx * r} ${midY} Q ${cx} ${midY} ${cx} ${midY + r} L ${cx} ${cy}`;
  }

  /* ============================= EFFECTS ============================= */

  triggerClickRipple(cx, cy) {
    if (prefersReducedMotion()) return;
    [0, 120].forEach((delay, i) => {
      const circle = document.createElementNS(SVG_NS, 'circle');
      circle.setAttribute('cx', cx);
      circle.setAttribute('cy', cy);
      circle.setAttribute('r', '18');
      circle.setAttribute('class', 'tree-ripple');
      circle.style.animationDelay = `${delay}ms`;
      if (i === 1) circle.style.opacity = '0';
      this.effectsGroup.appendChild(circle);
      setTimeout(() => circle.remove(), 900 + delay);
    });
  }

  /* ============================== RENDER ============================== */

  render(opts = {}) {
    const mode = prefersReducedMotion() ? false : (opts.animate || false);
    this.updateDimensions();
    if (this.morphFrameId) { cancelAnimationFrame(this.morphFrameId); this.morphFrameId = null; }

    this.linksGroup.innerHTML = '';
    this.nodesGroup.innerHTML = '';
    this.effectsGroup.innerHTML = '';
    this.sparksGroup.innerHTML = '';
    this.bandsGroup.innerHTML = '';
    this.bandLabels = [];

    if (!this.rootId) {
      this.renderedNodes = [];
      this.renderedLinks = [];
      this.showEmptyState();
      this.scheduleMinimap();
      return;
    }
    this.emptyEl.classList.add('hidden');

    const { nodes, links } = this.computeLayout(this.rootId);
    this.renderedNodes = nodes;
    this.renderedLinks = links;
    const nodeById = new Map(nodes.map(n => [n.id, n]));
    const prev = this.prevPositions;

    // Har bir avlod uchun kechikish (o'sish animatsiyasi)
    const STEP = 210;
    const growDelay = (depth) => (depth - 1) * STEP;

    /* ---------- 0. Avlod qatlamlari ---------- */
    if (this.options.showGenerationBands && nodes.length) {
      const minX = Math.min(...nodes.map(n => n.x)) - 2000;
      const maxX = Math.max(...nodes.map(n => n.x + n.width)) + 2000;
      const depths = [...new Set(nodes.map(n => n.depth))].sort((a, b) => a - b);
      depths.forEach((d, i) => {
        const sample = nodes.find(n => n.depth === d);
        const y = sample.y - 26;
        const h = this.options.cardHeight + 52;
        const band = document.createElementNS(SVG_NS, 'rect');
        band.setAttribute('x', minX);
        band.setAttribute('y', y);
        band.setAttribute('width', maxX - minX);
        band.setAttribute('height', h);
        band.setAttribute('class', `tree-band ${i % 2 ? 'odd' : 'even'}`);
        this.bandsGroup.appendChild(band);

        const gen = sample.member.generation || d;
        const lbl = document.createElementNS(SVG_NS, 'g');
        lbl.setAttribute('class', 'tree-band-label');
        lbl.dataset.y = String(sample.y + this.options.cardHeight / 2);
        lbl.innerHTML = `<rect x="0" y="-13" rx="13" width="78" height="26"></rect>` +
                        `<text x="39" y="4.5" text-anchor="middle">${esc(gen)}-avlod</text>`;
        this.bandsGroup.appendChild(lbl);
        this.bandLabels.push(lbl);
      });
    }

    /* ---------- 1. Chiziqlar ---------- */
    const highlightedPaths = [];
    links.forEach(bus => {
      const { parentId, px, py, nextY, children, depth } = bus;
      const midY = py + (nextY - py) / 2;
      const parentHL = this.highlightedAncestors.has(parentId);

      // Avval oddiy, keyin yoritilgan chiziqlar (ustida turishi uchun)
      const ordered = [...children].sort((a, b) =>
        (parentHL && this.highlightedAncestors.has(a.childId) ? 1 : 0) -
        (parentHL && this.highlightedAncestors.has(b.childId) ? 1 : 0));

      ordered.forEach(ch => {
        const isHL = parentHL && this.highlightedAncestors.has(ch.childId);
        const d = this.roundedPath(px, py, midY, ch.x, ch.y);
        const path = document.createElementNS(SVG_NS, 'path');
        path.setAttribute('d', d);
        path.setAttribute('pathLength', '1');
        path.setAttribute('class', `tree-link ${isHL ? 'highlighted' : ''}`);
        path.dataset.child = ch.childId;
        path.dataset.parent = parentId;

        if (mode === 'grow') {
          path.classList.add('link-draw');
          path.style.animationDelay = `${growDelay(depth) + 140}ms`;
        } else if (mode === 'morph') {
          path.classList.add('link-fade');
        }
        this.linksGroup.appendChild(path);

        if (isHL) highlightedPaths.push({ d, depth });
      });
    });

    // Ajdodlar yo'li bo'ylab oqib yuruvchi uchqunlar
    if (highlightedPaths.length && !prefersReducedMotion()) {
      highlightedPaths.forEach(({ d }, i) => {
        const flow = document.createElementNS(SVG_NS, 'path');
        flow.setAttribute('d', d);
        flow.setAttribute('class', 'tree-link-flow');
        this.sparksGroup.appendChild(flow);

        const spark = document.createElementNS(SVG_NS, 'circle');
        spark.setAttribute('r', '6');
        spark.setAttribute('class', 'lineage-spark');
        spark.setAttribute('fill', 'url(#sparkGrad)');
        spark.innerHTML = `<animateMotion dur="1.8s" begin="${(i * 0.25).toFixed(2)}s" repeatCount="indefinite" path="${d}" />`;
        this.sparksGroup.appendChild(spark);
      });
    }

    /* ---------- 2. Shaxs bloki ---------- */
    const renderPersonBlock = (m, roleLabel = null) => {
      const isMale = m.gender === 'male';
      const birthStr = m.birthYear ? m.birthYear : '?';
      const deathStr = m.isLiving ? 'hozir' : (m.deathYear ? m.deathYear : '—');
      const age = (m.birthYear && (m.isLiving || m.deathYear))
        ? ((m.isLiving ? new Date().getFullYear() : m.deathYear) - m.birthYear) : null;

      const tone = isMale ? 'avatar-male' : 'avatar-female';
      const initial = esc((m.firstName || '?').charAt(0));
      const avatarHtml = m.photoUrl
        ? `<img src="${esc(m.photoUrl)}" alt="${esc(m.firstName)}" loading="lazy" decoding="async" data-initial="${initial}" data-tone="${tone}" class="avatar-arch ${tone} w-12 h-12 object-cover flex-shrink-0">`
        : `<div class="avatar-arch ${tone} w-12 h-12 flex items-center justify-center font-serif font-bold text-lg flex-shrink-0">${initial}</div>`;

      const statusBadge = m.isLiving
        ? `<span class="status-chip status-living" title="Hozirda hayot"><i class="live-dot"></i>Hayot</span>`
        : `<span class="status-chip status-deceased" title="Marhum">Marhum</span>`;

      return `
        <div class="member-sub-card couple-half ${m.isLiving ? '' : 'is-deceased'} flex items-center gap-2.5 p-2 rounded-xl cursor-pointer"
             data-person-id="${esc(m.id)}" data-birth="${esc(m.birthYear || '')}" data-death="${esc(m.isLiving ? '' : (m.deathYear || ''))}"
             title="${esc(m.firstName)} ${esc(m.lastName)} profilini ochish">
          <div class="avatar-wrap">${avatarHtml}</div>
          <div class="flex-1 min-w-0">
            <div class="flex items-center gap-1.5 flex-wrap">
              ${roleLabel ? `<span class="role-chip ${isMale ? 'role-male' : 'role-female'}">${roleLabel}</span>` : ''}
              ${statusBadge}
            </div>
            <h4 class="font-serif font-bold text-[13.5px] truncate leading-snug mt-0.5" title="${esc(m.firstName)} ${esc(m.lastName)}">
              ${esc(m.firstName)} ${esc(m.lastName)}
            </h4>
            <div class="person-years">${birthStr} – ${deathStr}${age !== null && age >= 0 ? ` <span class="person-age">· ${age} yosh</span>` : ''}</div>
          </div>
        </div>`;
    };

    /* ---------- 3. Kartalar ---------- */
    const movers = [];
    nodes.forEach((item, index) => {
      const { member, spouse, isCouple, x, y, width, height, childrenCount, isCollapsed, depth, parentId } = item;
      const isRoot = member.id === this.rootId;
      const isSelected = this.selectedNodeId === member.id || (spouse && this.selectedNodeId === spouse.id);
      const isHighlightedAncestor = this.highlightedAncestors.has(member.id) || (spouse && this.highlightedAncestors.has(spouse.id));

      const group = document.createElementNS(SVG_NS, 'g');
      group.setAttribute('class', `tree-node ${isSelected ? 'selected' : ''} ${isHighlightedAncestor ? 'highlighted-ancestor' : ''}`);
      group.setAttribute('data-id', member.id);

      // FLIP: oldingi joyidan yangisiga suriladi
      const old = prev.get(member.id);
      let enterClass = '';
      let enterDelay = 0;
      if (mode === 'grow') {
        enterClass = 'node-grow';
        enterDelay = growDelay(depth) + (index % 7) * 18;
        group.setAttribute('transform', `translate(${x}, ${y})`);
      } else if (mode === 'morph' && old && (old.x !== x || old.y !== y)) {
        group.setAttribute('transform', `translate(${old.x}, ${old.y})`);
        movers.push({ el: group, fx: old.x, fy: old.y, tx: x, ty: y });
      } else if (mode === 'morph' && !old) {
        // Yangi paydo bo'lgan karta ota-onasi joyidan "chiqadi"
        const parentNode = parentId && nodeById.get(parentId);
        enterClass = 'node-pop';
        enterDelay = 120;
        if (parentNode) {
          const pOld = prev.get(parentId) || parentNode;
          const sx = pOld.x + parentNode.width / 2 - width / 2;
          group.setAttribute('transform', `translate(${sx}, ${pOld.y})`);
          movers.push({ el: group, fx: sx, fy: pOld.y, tx: x, ty: y });
        } else {
          group.setAttribute('transform', `translate(${x}, ${y})`);
        }
      } else {
        group.setAttribute('transform', `translate(${x}, ${y})`);
      }

      const fo = document.createElementNS(SVG_NS, 'foreignObject');
      fo.setAttribute('width', width);
      fo.setAttribute('height', height + 24);
      fo.style.overflow = 'visible';

      const card = document.createElement('div');
      card.className = `node-card ${isCouple ? 'card-couple' : (member.gender === 'male' ? 'card-single-male' : 'card-single-female')} ${isRoot ? 'card-root-glow' : ''} gen-${Math.min(Math.max(member.generation || depth || 1, 1), 6)} ${enterClass}`;
      if (enterClass) card.style.animationDelay = `${enterDelay}ms`;

      if (isCouple) {
        card.innerHTML = `
          <div class="card-corner-tl"></div>
          <div class="card-corner-br"></div>
          <div class="card-shine"></div>
          <div class="card-gen-badge ${isRoot ? 'is-root' : ''}">
            ${isRoot ? '<span class="crown">♛</span> Sulola asoschilari' : `${esc(member.generation || depth)}-avlod oilasi`}
          </div>
          <div class="grid grid-cols-2 gap-1 items-center pt-1">
            ${renderPersonBlock(member, member.gender === 'male' ? 'Er' : 'Ayol')}
            <div class="relative flex items-center">
              <div class="wedding-knot" title="Turmush o‘rtoqlar">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="13" r="5"/><circle cx="15" cy="13" r="5"/><path d="M12 3l1.5 2.5L12 7l-1.5-1.5z" fill="currentColor"/></svg>
              </div>
              ${renderPersonBlock(spouse, spouse.gender === 'female' ? 'Ayol' : 'Er')}
            </div>
          </div>`;
      } else {
        card.innerHTML = `
          <div class="card-corner-tl"></div>
          <div class="card-corner-br"></div>
          <div class="card-shine"></div>
          <div class="p-1">
            <div class="flex items-center justify-between mb-0.5">
              <span class="role-chip ${member.gender === 'male' ? 'role-male' : 'role-female'}">${esc(member.generation || depth)}-avlod</span>
              ${isRoot ? '<span class="crown-mini" title="Sulola asoschisi">♛</span>' : ''}
            </div>
            ${renderPersonBlock(member, null)}
          </div>`;
      }

      card.querySelectorAll('img[data-initial]').forEach(img => {
        img.addEventListener('error', () => {
          const d = document.createElement('div');
          d.className = `avatar-arch ${img.dataset.tone} w-12 h-12 flex items-center justify-center font-serif font-bold text-lg flex-shrink-0`;
          d.textContent = img.dataset.initial;
          img.replaceWith(d);
        }, { once: true });
      });

      if (childrenCount > 0) {
        const toggleBtn = document.createElement('div');
        toggleBtn.className = `node-interactive-btn node-toggle ${isCollapsed ? 'is-collapsed' : ''}`;
        toggleBtn.innerHTML = isCollapsed
          ? `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M12 5v14M5 12h14"/></svg><span>${childrenCount} farzand</span>`
          : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M5 12h14"/></svg><span>yig‘ish</span>`;
        toggleBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          this.toggleCollapse(member.id);
        });
        card.appendChild(toggleBtn);
      }

      card.querySelectorAll('.member-sub-card').forEach(sub => {
        sub.addEventListener('click', (e) => {
          e.stopPropagation();
          const targetMember = this.memberMap.get(sub.getAttribute('data-person-id'));
          if (targetMember) {
            const node = this.renderedNodes.find(n => n.id === member.id) || item;
            this.triggerClickRipple(node.x + width / 2, node.y + height / 2);
            this.selectNode(targetMember.id);
            this.options.onNodeClick(targetMember);
          }
        });
      });

      card.addEventListener('click', () => {
        this.triggerClickRipple(x + width / 2, y + height / 2);
        this.selectNode(member.id);
        this.options.onNodeClick(member);
      });

      fo.appendChild(card);
      group.appendChild(fo);
      this.nodesGroup.appendChild(group);
    });

    if (movers.length) this.runMorph(movers, 520);

    // Keyingi morph uchun joylarni eslab qolamiz
    this.prevPositions = new Map(nodes.map(n => [n.id, { x: n.x, y: n.y }]));
    this.hasRenderedOnce = true;

    if (this.timeYear !== null) this.applyTimeFilter();
    this.buildMinimapCache();
    this.applyTransform();
    this.scheduleMinimap();
  }

  runMorph(movers, duration) {
    const start = performance.now();
    const ease = (t) => 1 - Math.pow(1 - t, 4);
    const tick = (now) => {
      const p = Math.min((now - start) / duration, 1);
      const e = ease(p);
      movers.forEach(m => {
        m.el.setAttribute('transform', `translate(${m.fx + (m.tx - m.fx) * e}, ${m.fy + (m.ty - m.fy) * e})`);
      });
      this.morphFrameId = p < 1 ? requestAnimationFrame(tick) : null;
    };
    this.morphFrameId = requestAnimationFrame(tick);
  }

  /** Daraxtni boshidan "o'stirib" ko'rsatish */
  replayGrowth() {
    this.prevPositions.clear();
    this.render({ animate: 'grow' });
    this.fitToScreen(true);
  }

  showEmptyState() {
    this.emptyEl.classList.remove('hidden');
  }

  toggleCollapse(nodeId) {
    if (this.collapsedIds.has(nodeId)) this.collapsedIds.delete(nodeId);
    else this.collapsedIds.add(nodeId);
    this.render({ animate: 'morph' });
  }

  expandAll() {
    this.collapsedIds.clear();
    this.render({ animate: 'morph' });
    setTimeout(() => this.fitToScreen(true), 540);
  }

  selectNode(nodeId) {
    this.selectedNodeId = nodeId;
    this.nodesGroup.querySelectorAll('.tree-node').forEach(el => {
      const dataId = el.getAttribute('data-id');
      const renderedNode = this.renderedNodes?.find(n => n.id === dataId);
      el.classList.toggle('selected', dataId === nodeId || renderedNode?.spouse?.id === nodeId);
    });
  }

  highlightLineage(memberId) {
    this.highlightedAncestors.clear();
    let current = this.memberMap.get(memberId);
    const guard = new Set();
    while (current && !guard.has(current.id)) {
      guard.add(current.id);
      this.highlightedAncestors.add(current.id);
      if (current.fatherId && this.memberMap.has(current.fatherId)) current = this.memberMap.get(current.fatherId);
      else if (current.motherId && this.memberMap.has(current.motherId)) current = this.memberMap.get(current.motherId);
      else break;
    }
    this.render();
  }

  clearHighlight() {
    this.highlightedAncestors.clear();
    this.render();
  }

  /* =========================== VAQT MASHINASI =========================== */

  /** yil = null bo'lsa filtr o'chiriladi */
  setTimeYear(year) {
    this.timeYear = (year === null || year === undefined || year === '') ? null : Number(year);
    this.applyTimeFilter();
  }

  applyTimeFilter() {
    const Y = this.timeYear;
    this.container.classList.toggle('time-mode', Y !== null);
    if (this.yearHud) {
      this.yearHud.textContent = Y !== null ? String(Y) : '';
      this.yearHud.classList.toggle('show', Y !== null);
    }

    const futureIds = new Set();
    this.nodesGroup.querySelectorAll('.member-sub-card').forEach(sub => {
      const b = Number(sub.dataset.birth) || null;
      const d = Number(sub.dataset.death) || null;
      const future = Y !== null && b !== null && b > Y;
      const goneThen = Y !== null && !future && d !== null && d <= Y;
      sub.classList.toggle('is-future', future);
      sub.classList.toggle('is-gone-then', goneThen);
      if (future) futureIds.add(sub.dataset.personId);
    });

    this.nodesGroup.querySelectorAll('.tree-node').forEach(g => {
      const subs = g.querySelectorAll('.member-sub-card');
      const allFuture = subs.length > 0 && [...subs].every(s => s.classList.contains('is-future'));
      g.classList.toggle('node-future', allFuture);
    });

    this.linksGroup.querySelectorAll('.tree-link').forEach(p => {
      p.classList.toggle('link-future', futureIds.has(p.dataset.child));
    });

    if (Y !== null) {
      document.dispatchEvent(new CustomEvent('shajara:time', { detail: { year: Y, living: this.countLivingAt(Y) } }));
    }
  }

  countLivingAt(year) {
    return this.members.filter(m => {
      const b = Number(m.birthYear) || null;
      const d = m.isLiving ? null : (Number(m.deathYear) || null);
      if (b === null) return false;
      return b <= year && (d === null || d > year);
    }).length;
  }

  /* ============================= MINI-XARITA ============================= */

  scheduleMinimap() {
    if (!this.minimap || this._mmPending) return;
    this._mmPending = true;
    requestAnimationFrame(() => { this._mmPending = false; this.drawMinimap(); });
  }

  buildMinimapCache() {
    const nodes = this.renderedNodes || [];
    if (nodes.length < 2) return;
    const W = 200, H = 130;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    if (!this._minimapBgCanvas) {
      this._minimapBgCanvas = document.createElement('canvas');
    }
    this._minimapBgCanvas.width = W * dpr;
    this._minimapBgCanvas.height = H * dpr;
    const ctx = this._minimapBgCanvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);

    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (let i = 0; i < nodes.length; i++) {
      const n = nodes[i];
      if (n.x < minX) minX = n.x;
      if (n.x + n.width > maxX) maxX = n.x + n.width;
      if (n.y < minY) minY = n.y;
      if (n.y + n.height > maxY) maxY = n.y + n.height;
    }
    const pad = 8;
    const k = Math.min((W - pad * 2) / (maxX - minX || 1), (H - pad * 2) / (maxY - minY || 1));
    const ox = (W - (maxX - minX) * k) / 2;
    const oy = (H - (maxY - minY) * k) / 2;
    this.minimapState = { minX, minY, k, ox, oy };

    // Chiziqlar
    ctx.strokeStyle = 'rgba(68,85,143,0.35)';
    ctx.lineWidth = 1;
    (this.renderedLinks || []).forEach(l => {
      l.children.forEach(c => {
        ctx.beginPath();
        ctx.moveTo(ox + (l.px - minX) * k, oy + (l.py - minY) * k);
        ctx.lineTo(ox + (c.x - minX) * k, oy + (c.y - minY) * k);
        ctx.stroke();
      });
    });

    // Kartalar
    nodes.forEach(n => {
      const hl = this.highlightedAncestors.has(n.id);
      const sel = this.selectedNodeId === n.id || n.spouse?.id === this.selectedNodeId;
      ctx.fillStyle = sel ? '#2f4fa8' : hl ? '#c8912b' : n.isCouple ? '#d8b56a' : (n.member.gender === 'male' ? '#7d97d6' : '#d98aa8');
      const x = ox + (n.x - minX) * k, y = oy + (n.y - minY) * k;
      const w = Math.max(n.width * k, 2), h = Math.max(n.height * k, 2);
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(x, y, w, h, 2); else ctx.rect(x, y, w, h);
      ctx.fill();
    });
  }

  drawMinimap() {
    if (!this.minimap) return;
    const nodes = this.renderedNodes || [];
    this.minimap.classList.toggle('hidden-empty', nodes.length < 2);
    if (this.minimap.classList.contains('collapsed') || nodes.length < 2) return;

    if (!this._minimapBgCanvas || !this.minimapState) {
      this.buildMinimapCache();
    }
    if (!this.minimapState) return;

    const canvas = this.minimapCanvas;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const W = 200, H = 130;
    if (canvas.width !== W * dpr) { canvas.width = W * dpr; canvas.height = H * dpr; }
    const ctx = this.minimapCtx;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);

    // Blit pre-cached background image (instant ~0.02ms)
    if (this._minimapBgCanvas) {
      ctx.drawImage(this._minimapBgCanvas, 0, 0, W, H);
    }

    const { minX, minY, k, ox, oy } = this.minimapState;
    const cW = this.container.clientWidth;
    const cH = this.container.clientHeight;
    const vx = (-this.translateX / this.scale - minX) * k + ox;
    const vy = (-this.translateY / this.scale - minY) * k + oy;
    const vw = cW / this.scale * k;
    const vh = cH / this.scale * k;
    ctx.fillStyle = 'rgba(47,79,168,0.08)';
    ctx.strokeStyle = '#2f4fa8';
    ctx.lineWidth = 1.5;
    ctx.fillRect(vx, vy, vw, vh);
    ctx.strokeRect(vx, vy, vw, vh);
  }

  /* ============================ NAVIGATSIYA ============================ */

  focusOnMember(memberId, smooth = true) {
    if (!this.renderedNodes) return;
    let target = this.renderedNodes.find(n => n.id === memberId || n.spouse?.id === memberId);

    // Yig'ilgan shox ichida bo'lsa — ajdodlarini ochamiz
    if (!target && this.memberMap.has(memberId)) {
      let cur = this.memberMap.get(memberId);
      const guard = new Set();
      let opened = false;
      while (cur && !guard.has(cur.id)) {
        guard.add(cur.id);
        [cur.fatherId, cur.motherId].forEach(pid => {
          if (pid && this.collapsedIds.has(pid)) { this.collapsedIds.delete(pid); opened = true; }
          // Turmush o'rtog'i orqali ko'rsatilgan kartalar
          const sp = pid && this.getPrimarySpouse(pid);
          if (sp && this.collapsedIds.has(sp.id)) { this.collapsedIds.delete(sp.id); opened = true; }
        });
        cur = this.memberMap.get(cur.fatherId) || this.memberMap.get(cur.motherId);
      }
      if (opened) {
        this.render({ animate: 'morph' });
        target = this.renderedNodes.find(n => n.id === memberId || n.spouse?.id === memberId);
      }
    }
    if (!target) return;

    this.selectNode(memberId);
    const rect = this.container.getBoundingClientRect();
    const targetScale = Math.max(Math.min(this.scale, 1.1), 0.9);
    const targetX = rect.width / 2 - (target.x + target.width / 2) * targetScale;
    const targetY = rect.height / 2 - (target.y + target.height / 2) * targetScale;

    if (smooth) {
      this.animateToTransform(targetX, targetY, targetScale, 650);
      setTimeout(() => this.triggerClickRipple(target.x + target.width / 2, target.y + target.height / 2), 600);
    } else {
      this.scale = targetScale;
      this.translateX = targetX;
      this.translateY = targetY;
      this.applyTransform();
    }
  }

  zoomAround(factor, duration = 220) {
    const newScale = Math.min(Math.max(this.scale * factor, 0.2), 2.5);
    const rect = this.container.getBoundingClientRect();
    const cx = rect.width / 2, cy = rect.height / 2;
    const targetX = cx - (cx - this.translateX) * (newScale / this.scale);
    const targetY = cy - (cy - this.translateY) * (newScale / this.scale);
    this.animateToTransform(targetX, targetY, newScale, duration);
  }

  zoomIn() { this.zoomAround(1.25); }
  zoomOut() { this.zoomAround(0.8); }

  resetZoom() {
    // "100%" tugmasi: haqiqiy 100% masshtab, ko'rinib turgan markaz saqlanadi
    this.zoomAround(1 / this.scale, 300);
  }

  fitToScreen(smooth = true) {
    if (!this.renderedNodes || this.renderedNodes.length === 0) return;
    if (!this.isVisible()) { this.pendingFit = true; return; }

    const minX = Math.min(...this.renderedNodes.map(n => n.x));
    const maxX = Math.max(...this.renderedNodes.map(n => n.x + n.width));
    const minY = Math.min(...this.renderedNodes.map(n => n.y));
    const maxY = Math.max(...this.renderedNodes.map(n => n.y + n.height));
    const treeW = maxX - minX;
    const treeH = maxY - minY;

    const rect = this.container.getBoundingClientRect();
    // Chap tomonda avlod yorliqlari uchun joy qoldiramiz
    const narrow = rect.width < 640;
    const paddingLeft = narrow ? 20 : (this.options.showGenerationBands ? 120 : 70);
    const paddingRight = narrow ? 20 : 70, paddingTop = 40, paddingBottom = 70;
    const scaleX = (rect.width - paddingLeft - paddingRight) / (treeW || 1);
    const scaleY = (rect.height - paddingTop - paddingBottom) / (treeH || 1);
    const targetScale = Math.min(Math.max(Math.min(scaleX, scaleY), 0.3), 0.95);

    const freeW = rect.width - paddingLeft - paddingRight;
    const targetX = paddingLeft + Math.max(0, (freeW - treeW * targetScale) / 2) - minX * targetScale;
    const targetY = paddingTop - minY * targetScale;

    if (smooth) {
      this.animateToTransform(targetX, targetY, targetScale, 600);
    } else {
      this.scale = targetScale;
      this.translateX = targetX;
      this.translateY = targetY;
      this.applyTransform();
    }
  }
}

ShajaraTree.instances = [];
window.ShajaraTree = ShajaraTree;
