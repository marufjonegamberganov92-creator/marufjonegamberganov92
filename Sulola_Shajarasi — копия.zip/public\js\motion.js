/**
 * Shajara — Motion qatlami (motion.js)
 * -----------------------------------
 * app.js dan KEYIN ulanadi. app.js ichki tuzilishiga bog'liq emas:
 * faqat sahifadagi ID'lar va window.ShajaraTree.instances orqali ishlaydi.
 *
 *  1. Kirish animatsiyasi (sessiyada bir marta)
 *  2. Siljuvchi tab ko'rsatkichi + tablar orasida silliq o'tish
 *  3. Ro'yxat kartalari ketma-ket paydo bo'ladi, bildirishnomalar sirpanadi
 *  4. Statistika raqamlari sanab chiqadi, chiziqlar to'ladi
 *  5. Sichqoncha ortidan yuruvchi yorug'lik, tugmalarda to'lqin
 *  6. Tezkor o'tish oynasi (Ctrl/⌘ + K yoki "/")
 *  7. Vaqt mashinasi va "Daraxtni o'stirish"
 */
(function () {
  'use strict';

  const reduced = (() => { try { return matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; } })();
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const tree = () => (window.ShajaraTree && window.ShajaraTree.instances && window.ShajaraTree.instances[0]) || window.shajaraTree || null;
  const store = {
    get(k) { try { return sessionStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { sessionStorage.setItem(k, v); } catch (e) { /* ignore */ } }
  };

  /* ------------------------------------------------------------------
   * 1. KIRISH ANIMATSIYASI
   * ------------------------------------------------------------------ */
  function introSplash() {
    if (reduced || store.get('shajara-intro-seen')) return;
    store.set('shajara-intro-seen', '1');
    const el = document.createElement('div');
    el.id = 'intro-splash';
    el.innerHTML = `
      <svg viewBox="0 0 120 120" aria-hidden="true">
        <path class="ground" pathLength="1" d="M30 108 H90"/>
        <path class="trunk"  pathLength="1" d="M60 108 V58"/>
        <path class="branch"    pathLength="1" d="M60 80 C60 68 46 62 36 56"/>
        <path class="branch b2" pathLength="1" d="M60 72 C60 60 74 54 84 48"/>
        <path class="branch b3" pathLength="1" d="M60 62 V34"/>
        <circle class="leaf" cx="34" cy="54" r="9"  fill="#f3d79b" stroke="#c8912b" stroke-width="2" style="animation-delay:.95s"/>
        <circle class="leaf" cx="86" cy="46" r="10" fill="#dbe4ff" stroke="#2f4fa8" stroke-width="2" style="animation-delay:1.05s"/>
        <circle class="leaf" cx="60" cy="28" r="12" fill="#fbdbe7" stroke="#b4456b" stroke-width="2" style="animation-delay:1.15s"/>
      </svg>
      <div class="splash-title">${esc(($('#dynasty-header-title')?.textContent || 'Sulola Shajarasi').trim())}</div>
      <div class="splash-sub">Ajdodlar qadri — avlodlar zanjiri</div>`;
    document.body.appendChild(el);
    const close = () => { el.classList.add('done'); setTimeout(() => el.remove(), 800); };
    el.addEventListener('click', close);
    setTimeout(close, 2100);
  }

  /* ------------------------------------------------------------------
   * 2. TABLAR: siljuvchi ko'rsatkich va o'tish animatsiyasi
   * ------------------------------------------------------------------ */
  function navPill() {
    const nav = $('header nav');
    if (!nav) return;
    const pill = document.createElement('span');
    pill.className = 'nav-pill';
    nav.prepend(pill);

    const isActive = (b) => /\bbg-emerald-\d+/.test(b.className);
    let lastActive = null;
    const move = (btn) => {
      if (!btn || !btn.offsetWidth) return;
      lastActive = btn;
      pill.style.left = btn.offsetLeft + 'px';
      pill.style.width = btn.offsetWidth + 'px';
      if (!nav.classList.contains('has-pill')) nav.classList.add('has-pill');
    };
    const sync = () => {
      const active = $$('button', nav).find(isActive);
      if (active) move(active);
      else if (nav.classList.contains('has-pill')) nav.classList.remove('has-pill');
    };

    nav.addEventListener('click', (e) => {
      const b = e.target.closest('button');
      if (b) move(b);
      setTimeout(sync, 30); // app.js klassni almashtirgandan keyin aniqlaymiz
    });
    // Faqat tugmalarni kuzatamiz (nav'ning o'z klassi emas) — cheksiz aylanishning oldini olish uchun
    const mo = new MutationObserver(muts => { if (muts.some(m => m.target !== nav && m.target !== pill)) sync(); });
    $$('button', nav).forEach(b => mo.observe(b, { attributes: true, attributeFilter: ['class'] }));
    window.addEventListener('resize', () => lastActive && move(lastActive));
    // Shriftlar yuklangach o'lcham o'zgaradi
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(sync);
    sync();
  }

  function viewTransitions() {
    $$('[id^="view-"]').forEach(view => {
      let wasHidden = view.classList.contains('hidden');
      new MutationObserver(() => {
        const hidden = view.classList.contains('hidden');
        if (wasHidden && !hidden && !reduced) {
          view.classList.remove('view-enter');
          void view.offsetWidth;
          view.classList.add('view-enter');
          view.addEventListener('animationend', () => view.classList.remove('view-enter'), { once: true });
          if (view.id === 'view-stats') animateStats();
          if (view.id === 'view-tree') setTimeout(() => tree()?.scheduleMinimap?.(), 50);
        }
        wasHidden = hidden;
      }).observe(view, { attributes: true, attributeFilter: ['class'] });
    });
  }

  /* ------------------------------------------------------------------
   * 3. RO'YXATLAR: ketma-ket paydo bo'lish
   * ------------------------------------------------------------------ */
  function staggerLists() {
    const targets = ['#directory-list-container', '#memories-grid-container', '#seven-ancestors-list',
                     '#stat-generations-breakdown', '#stat-professions-breakdown', '#search-results-dropdown'];
    targets.forEach(sel => {
      const host = $(sel);
      if (!host) return;
      const apply = (nodes) => {
        if (reduced) return;
        let i = 0;
        nodes.forEach(n => {
          if (n.nodeType !== 1) return;
          n.classList.remove('stagger-in');
          void n.offsetWidth;
          n.style.animationDelay = Math.min(i * 45, 540) + 'ms';
          n.classList.add('stagger-in');
          i++;
        });
      };
      new MutationObserver(muts => {
        const added = [];
        muts.forEach(m => m.addedNodes.forEach(n => added.push(n)));
        if (added.length) apply(added);
      }).observe(host, { childList: true });
      apply(Array.from(host.children));
    });

    const toasts = $('#toast-container');
    if (toasts) {
      new MutationObserver(muts => muts.forEach(m => m.addedNodes.forEach(n => {
        if (n.nodeType === 1 && !reduced) n.classList.add('toast-in');
      }))).observe(toasts, { childList: true });
    }
  }

  /* ------------------------------------------------------------------
   * 4. STATISTIKA: sanab chiqish va chiziqlar
   * ------------------------------------------------------------------ */
  const counting = new WeakMap();
  function countUp(el, to, from = 0, dur = 1100) {
    if (reduced || !isFinite(to)) { el.textContent = String(to); return; }
    const prevRaf = counting.get(el);
    if (prevRaf) cancelAnimationFrame(prevRaf.raf);
    const state = { raf: 0, target: to };
    counting.set(el, state);
    const t0 = performance.now();
    const ease = (t) => 1 - Math.pow(1 - t, 3);
    const tick = (now) => {
      const p = Math.min((now - t0) / dur, 1);
      state.busy = true;
      el.textContent = String(Math.round(from + (to - from) * ease(p)));
      state.busy = false;
      if (p < 1) state.raf = requestAnimationFrame(tick);
      else counting.delete(el);
    };
    state.raf = requestAnimationFrame(tick);
  }

  function readNumber(el) {
    const st = counting.get(el);
    if (st) return st.target;
    const n = parseInt(String(el.textContent).replace(/\D+/g, ''), 10);
    return isNaN(n) ? null : n;
  }

  function animateStats() {
    if (reduced) return;
    $$('[id^="stat-total-"]').forEach(el => {
      const n = readNumber(el);
      if (n !== null) countUp(el, n, 0);
    });
    // Foizli chiziqlar noldan to'ladi
    const bars = $$('#view-stats [style*="width"]').filter(b => /%\s*$/.test(b.style.width));
    const widths = bars.map(b => b.style.width);
    bars.forEach(b => { b.style.transition = 'none'; b.style.width = '0%'; });
    void document.body.offsetWidth;
    requestAnimationFrame(() => bars.forEach((b, i) => { b.style.transition = ''; b.style.width = widths[i]; }));
  }

  function watchStats() {
    $$('[id^="stat-total-"]').forEach(el => {
      let last = readNumber(el) || 0;
      new MutationObserver(() => {
        const st = counting.get(el);
        if (st && st.busy) return;           // o'zimiz yozgan qiymat
        if (st) return;                       // animatsiya davom etmoqda
        const n = readNumber(el);
        if (n === null || n === last) return;
        const visible = !$('#view-stats')?.classList.contains('hidden');
        if (visible) countUp(el, n, last, 700);
        last = n;
      }).observe(el, { childList: true, characterData: true, subtree: true });
    });
  }

  /* ------------------------------------------------------------------
   * 5. MIKRO-INTERAKSIYALAR
   * ------------------------------------------------------------------ */
  function spotlight() {
    let raf = 0, lastEvt = null;
    document.addEventListener('pointermove', (e) => {
      // Daraxt ichida yoki sudrash paytida ortiqcha hisoblashlarni cheklaymiz (qotishning oldini oladi)
      const target = e.target;
      if (!target || target.closest?.('.tree-container, #shajara-tree-canvas')) return;
      lastEvt = e;
      if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        const t = lastEvt.target;
        if (!(t instanceof Element)) return;
        const card = t.closest('#directory-list-container > *, #memories-grid-container > *');
        if (!card) return;
        const r = card.getBoundingClientRect();
        card.style.setProperty('--mx', ((lastEvt.clientX - r.left) / r.width * 100).toFixed(1) + '%');
        card.style.setProperty('--my', ((lastEvt.clientY - r.top) / r.height * 100).toFixed(1) + '%');
      });
    }, { passive: true });
  }

  function buttonRipples() {
    if (reduced) return;
    document.addEventListener('pointerdown', (e) => {
      const btn = e.target.closest('button');
      if (!btn || btn.closest('header nav') || btn.disabled) return;
      const cs = getComputedStyle(btn);
      if (cs.position === 'absolute' || cs.position === 'fixed') return;
      if (!btn.classList.contains('btn-ripple-host')) btn.classList.add('btn-ripple-host');
      const r = btn.getBoundingClientRect();
      const size = Math.max(r.width, r.height);
      const s = document.createElement('span');
      s.className = 'btn-ripple';
      s.style.width = s.style.height = size + 'px';
      s.style.left = (e.clientX - r.left - size / 2) + 'px';
      s.style.top = (e.clientY - r.top - size / 2) + 'px';
      btn.appendChild(s);
      setTimeout(() => s.remove(), 650);
    });
  }

  function headerScroll() {
    const header = $('header');
    if (!header) return;
    const onScroll = () => header.classList.toggle('is-scrolled', window.scrollY > 6);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ------------------------------------------------------------------
   * 6. TEZKOR O'TISH (Ctrl/⌘ + K)
   * ------------------------------------------------------------------ */
  function commandPalette() {
    const overlay = $('#cmdk-overlay');
    const input = $('#cmdk-input');
    const list = $('#cmdk-list');
    if (!overlay || !input || !list) return;

    let items = [];
    let active = 0;
    let lastFocus = null;

    const norm = (s) => String(s || '').toLowerCase()
      .replace(/[ʻʼ‘’`']/g, '').replace(/ё/g, 'е');

    const open = () => {
      lastFocus = document.activeElement;
      overlay.classList.add('open');
      overlay.setAttribute('aria-hidden', 'false');
      input.value = '';
      search('');
      setTimeout(() => input.focus(), 30);
    };
    const close = () => {
      overlay.classList.remove('open');
      overlay.setAttribute('aria-hidden', 'true');
      // Ekrandan tashqaridagi elementga fokus qaytarilsa, daraxt maydoni siljib ketadi
      if (lastFocus && lastFocus.isConnected && lastFocus.focus && lastFocus.offsetParent !== null) {
        lastFocus.focus({ preventScroll: true });
      }
    };

    const search = (q) => {
      const t = tree();
      const members = t ? t.getMembers() : [];
      const nq = norm(q).trim();
      items = members
        .map(m => {
          const hay = norm([m.firstName, m.lastName, m.middleName, m.nickname, m.profession, m.birthYear].join(' '));
          let score = 0;
          if (!nq) score = 1;
          else if (norm(m.firstName).startsWith(nq)) score = 3;
          else if (hay.split(/\s+/).some(w => w.startsWith(nq))) score = 2;
          else if (hay.includes(nq)) score = 1;
          return { m, score };
        })
        .filter(x => x.score > 0)
        .sort((a, b) => b.score - a.score || (a.m.generation || 0) - (b.m.generation || 0) || (a.m.birthYear || 0) - (b.m.birthYear || 0))
        .slice(0, 40)
        .map(x => x.m);
      active = 0;
      paint();
    };

    const paint = () => {
      if (!tree()) { list.innerHTML = `<div class="cmdk-empty">Daraxt hali yuklanmagan…</div>`; return; }
      if (!items.length) { list.innerHTML = `<div class="cmdk-empty">Hech kim topilmadi</div>`; return; }
      list.innerHTML = items.map((m, i) => {
        const male = m.gender === 'male';
        const years = `${m.birthYear || '?'} – ${m.isLiving ? 'hozir' : (m.deathYear || '—')}`;
        return `
          <div class="cmdk-item ${i === active ? 'active' : ''}" role="option" data-i="${i}" style="animation-delay:${Math.min(i * 22, 300)}ms">
            <div class="cmdk-avatar ${male ? 'avatar-male' : 'avatar-female'}">${esc((m.firstName || '?').charAt(0))}</div>
            <div class="min-w-0">
              <div class="cmdk-name truncate">${esc(m.firstName)} ${esc(m.lastName)}</div>
              <div class="cmdk-meta truncate">${m.generation ? esc(m.generation) + '-avlod · ' : ''}${esc(years)}${m.profession ? ' · ' + esc(m.profession) : ''}</div>
            </div>
            <div class="cmdk-actions">
              <span data-act="tree">Daraxtda</span>
              <span data-act="lineage">Ajdodlari</span>
              <span data-act="profile">Profil</span>
            </div>
          </div>`;
      }).join('');
      list.querySelector('.cmdk-item.active')?.scrollIntoView({ block: 'nearest' });
    };

    const go = (m, act = 'tree') => {
      const t = tree();
      if (!t || !m) return;
      close();
      if (act === 'profile') { t.options.onNodeClick(m); return; }
      const treeBtn = $('#tab-btn-tree');
      if ($('#view-tree')?.classList.contains('hidden')) {
        if (window.App && typeof window.App.switchTab === 'function') window.App.switchTab('tree');
        else if (treeBtn) treeBtn.click();
      }
      setTimeout(() => {
        if (act === 'lineage') t.highlightLineage(m.id);
        t.focusOnMember(m.id, true);
      }, 260);
    };

    input.addEventListener('input', () => search(input.value));
    input.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown') { active = Math.min(active + 1, items.length - 1); paint(); e.preventDefault(); }
      else if (e.key === 'ArrowUp') { active = Math.max(active - 1, 0); paint(); e.preventDefault(); }
      else if (e.key === 'Enter') { go(items[active], e.shiftKey ? 'profile' : (e.altKey ? 'lineage' : 'tree')); e.preventDefault(); }
      else if (e.key === 'Escape') { close(); }
    });
    list.addEventListener('mousemove', (e) => {
      const it = e.target.closest('.cmdk-item');
      if (it && Number(it.dataset.i) !== active) {
        list.querySelector('.cmdk-item.active')?.classList.remove('active');
        it.classList.add('active');
        active = Number(it.dataset.i);
      }
    });
    list.addEventListener('click', (e) => {
      const it = e.target.closest('.cmdk-item');
      if (!it) return;
      const act = e.target.closest('[data-act]')?.dataset.act || 'tree';
      go(items[Number(it.dataset.i)], act);
    });
    overlay.addEventListener('mousedown', (e) => { if (e.target === overlay) close(); });

    window.addEventListener('keydown', (e) => {
      const typing = e.target && /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName);
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); overlay.classList.contains('open') ? close() : open(); }
      else if (e.key === '/' && !typing && !overlay.classList.contains('open') && !document.querySelector('.modal-overlay:not(.hidden)')) { e.preventDefault(); open(); }
      else if (e.key === 'Escape' && overlay.classList.contains('open')) close();
    });
    $$('[data-open-cmdk]').forEach(b => b.addEventListener('click', open));

    // Mac'da ⌘, boshqalarida Ctrl
    const isMac = /Mac|iPhone|iPad/.test(navigator.platform || '');
    $$('[data-mod-key]').forEach(el => { el.textContent = isMac ? '⌘K' : 'Ctrl K'; });
  }

  /* ------------------------------------------------------------------
   * 7. VAQT MASHINASI va O'STIRISH
   * ------------------------------------------------------------------ */
  function timeMachine() {
    const panel = $('#time-machine-panel');
    const range = $('#tm-range');
    const playBtn = $('#tm-play');
    const openBtn = $('#btn-time-machine');
    if (!panel || !range || !playBtn || !openBtn) return;

    const view = $('#view-tree');
    const living = $('#tm-living');
    const yearLbl = $('#tm-year');
    const minLbl = $('#tm-min');
    const maxLbl = $('#tm-max');
    const ICON_PLAY = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 4.5v15a1 1 0 0 0 1.5.86l12.5-7.5a1 1 0 0 0 0-1.72L8.5 3.64A1 1 0 0 0 7 4.5z"/></svg>';
    const ICON_PAUSE = '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16" rx="1.2"/><rect x="14" y="4" width="4" height="16" rx="1.2"/></svg>';
    let playing = false, raf = 0, lastT = 0, yearF = 0;

    const setProgress = () => {
      const p = (range.value - range.min) / ((range.max - range.min) || 1) * 100;
      range.style.setProperty('--p', p + '%');
    };
    const apply = (y) => {
      range.value = y;
      setProgress();
      tree()?.setTimeYear(Number(y));
    };
    const stop = () => {
      playing = false;
      cancelAnimationFrame(raf);
      playBtn.innerHTML = ICON_PLAY;
      playBtn.setAttribute('aria-label', 'Ijro etish');
    };
    const play = () => {
      if (Number(range.value) >= Number(range.max)) apply(range.min);
      playing = true;
      playBtn.innerHTML = ICON_PAUSE;
      playBtn.setAttribute('aria-label', 'To‘xtatish');
      yearF = Number(range.value);
      lastT = performance.now();
      const span = Number(range.max) - Number(range.min);
      const yearsPerSec = Math.max(span / 14, 4); // butun tarix ~14 soniyada
      const tick = (now) => {
        yearF += (now - lastT) / 1000 * yearsPerSec;
        lastT = now;
        const y = Math.min(Math.floor(yearF), Number(range.max));
        if (y !== Number(range.value)) apply(y);
        if (y >= Number(range.max)) { stop(); return; }
        raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    };

    const openPanel = () => {
      const t = tree();
      if (!t) return;
      const { min, max } = t.getYearRange();
      range.min = String(min);
      range.max = String(max);
      minLbl.textContent = min;
      maxLbl.textContent = max;
      panel.classList.add('open');
      view?.classList.add('tm-open');
      openBtn.setAttribute('aria-pressed', 'true');
      apply(min);
      setTimeout(play, 450);
    };
    const closePanel = () => {
      stop();
      panel.classList.remove('open');
      view?.classList.remove('tm-open');
      openBtn.setAttribute('aria-pressed', 'false');
      tree()?.setTimeYear(null);
      if (panel.contains(document.activeElement)) document.activeElement.blur();
    };

    openBtn.addEventListener('click', () => panel.classList.contains('open') ? closePanel() : openPanel());
    $('#tm-close')?.addEventListener('click', closePanel);
    playBtn.addEventListener('click', () => (playing ? stop() : play()));
    range.addEventListener('input', () => { stop(); apply(range.value); });
    document.addEventListener('shajara:time', (e) => {
      if (living) living.textContent = `Hayot: ${e.detail.living} kishi`;
      if (yearLbl) yearLbl.textContent = e.detail.year;
    });
    // Ma'lumot yangilansa diapazonni ham yangilaymiz
    document.addEventListener('shajara:data', () => {
      if (!panel.classList.contains('open')) return;
      const { min, max } = tree().getYearRange();
      range.min = String(min); range.max = String(max);
      minLbl.textContent = min; maxLbl.textContent = max;
      setProgress();
    });

    $('#btn-replay-growth')?.addEventListener('click', () => tree()?.replayGrowth());
    $('#btn-expand-all')?.addEventListener('click', () => tree()?.expandAll());
  }

  /* ------------------------------------------------------------------
   * ISHGA TUSHIRISH
   * ------------------------------------------------------------------ */
  // overflow:hidden konteynerlar fokus tufayli "ichidan" aylanib ketmasligi uchun
  function lockScrollers() {
    ['#view-tree', '#shajara-tree-canvas'].forEach(sel => {
      const el = $(sel);
      if (!el) return;
      el.addEventListener('scroll', () => { if (el.scrollTop || el.scrollLeft) { el.scrollTop = 0; el.scrollLeft = 0; } });
    });
  }

  function init() {
    lockScrollers();
    introSplash();
    navPill();
    viewTransitions();
    staggerLists();
    watchStats();
    spotlight();
    buttonRipples();
    headerScroll();
    commandPalette();
    timeMachine();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
