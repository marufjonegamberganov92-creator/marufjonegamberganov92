const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'shajara-sulola-secret-key-2026';

const DATA_DIR = path.join(__dirname, 'data');
const BACKUPS_DIR = path.join(DATA_DIR, 'backups');
const UPLOADS_DIR = path.join(__dirname, 'uploads');
const DB_FILE = path.join(DATA_DIR, 'shajara.json');
const CONFIG_FILE = path.join(DATA_DIR, 'config.json');

// Ensure directories exist
[DATA_DIR, BACKUPS_DIR, UPLOADS_DIR].forEach(dir => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

// Configure Multer for photo uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOADS_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const safeExt = ['.jpg', '.jpeg', '.png', '.webp', '.gif'].includes(ext) ? ext : '.jpg';
    cb(null, `avatar_${Date.now()}_${uuidv4().slice(0, 8)}${safeExt}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50 MB (Katta arxiv suratlari uchun bemalol yetadi)
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Faqat rasm fayllari (JPG, PNG, WEBP) qabul qilinadi!'));
    }
  }
});

// Middlewares
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Static files
app.use('/uploads', express.static(UPLOADS_DIR));
app.use(express.static(path.join(__dirname, 'public')));

// Initial Seed Data generator
function getInitialSeedData() {
  return {
    dynasty: {
      title: "Rahimovlar Sulolasi Shajarasi",
      subtitle: "Ajdodlar qadri, merosi va avlodlar zanjiri",
      motto: "O'z ajdodini bilgan insonning kelajagi nurli bo'lur",
      rootPersonId: "mem_karim",
      updatedAt: new Date().toISOString()
    },
    members: [
      {
        id: "mem_karim",
        firstName: "Karim",
        lastName: "Rahimov",
        middleName: "Boboxon o'g'li",
        nickname: "Usta Karim",
        gender: "male",
        birthYear: 1888,
        birthDate: "1888-03-12",
        birthPlace: "Qo'qon shahar, Dahbidi mahallasi",
        deathYear: 1968,
        deathDate: "1968-10-14",
        deathPlace: "Toshkent",
        isLiving: false,
        fatherId: null,
        motherId: null,
        spouseIds: ["mem_fotima"],
        photoUrl: "",
        profession: "Mashhur duradgor usta, naqqosh",
        bio: "Sulola asoschisi. O'z davrining mohir ustasi, ko'plab tarixiy binolar va milliy uylar naqshinkor ustunlarini yaratgan. Mehnatsevar, elparvar inson bo'lgan.",
        generation: 1
      },
      {
        id: "mem_fotima",
        firstName: "Fotima",
        lastName: "Rahimova",
        middleName: "Mirzo qizi",
        nickname: "Fotima aya",
        gender: "female",
        birthYear: 1895,
        birthDate: "1895-07-20",
        birthPlace: "Qo'qon shahar",
        deathYear: 1974,
        deathDate: "1974-05-18",
        deathPlace: "Toshkent",
        isLiving: false,
        fatherId: null,
        motherId: null,
        spouseIds: ["mem_karim"],
        photoUrl: "",
        profession: "Uy bekasi, mohir chevar",
        bio: "Sulolaning mehribon onasi, 8 farzandni tarbiyalab voyaga yetkazgan, mahallada obro'-e'tiborli momo bo'lgan.",
        generation: 1
      },
      {
        id: "mem_abdulla",
        firstName: "Abdulla",
        lastName: "Rahimov",
        middleName: "Karim o'g'li",
        nickname: "Muallim bobo",
        gender: "male",
        birthYear: 1918,
        birthDate: "1918-09-05",
        birthPlace: "Qo'qon shahar",
        deathYear: 1995,
        deathDate: "1995-12-01",
        deathPlace: "Toshkent shahar",
        isLiving: false,
        fatherId: "mem_karim",
        motherId: "mem_fotima",
        spouseIds: ["mem_salima"],
        photoUrl: "",
        profession: "Matematika o'qituvchisi, maktab direktori",
        bio: "Ikkinchi jahon urushi qatnashchisi. 40 yildan ortiq xalq maorifiga xizmat qilgan, yuzlab shogirdlar yetishtirgan.",
        generation: 2
      },
      {
        id: "mem_salima",
        firstName: "Salima",
        lastName: "Rahimova",
        middleName: "Said qizi",
        nickname: "Salima aya",
        gender: "female",
        birthYear: 1924,
        birthDate: "1924-04-10",
        birthPlace: "Toshkent, Chig'atoy",
        deathYear: 2008,
        deathDate: "2008-08-22",
        deathPlace: "Toshkent",
        isLiving: false,
        fatherId: null,
        motherId: null,
        spouseIds: ["mem_abdulla"],
        photoUrl: "",
        profession: "Kutubxonachi, pedagog",
        bio: "Maktab kutubxonasida uzoq yillar mehnat qilgan, kitobxonlik va adabiyotga oshno qalb egasi.",
        generation: 2
      },
      {
        id: "mem_mahmud",
        firstName: "Mahmud",
        lastName: "Rahimov",
        middleName: "Karim o'g'li",
        nickname: "Bog'bon ota",
        gender: "male",
        birthYear: 1922,
        birthDate: "1922-11-15",
        birthPlace: "Qo'qon shahar",
        deathYear: 1989,
        deathDate: "1989-06-30",
        deathPlace: "Farg'ona",
        isLiving: false,
        fatherId: "mem_karim",
        motherId: "mem_fotima",
        spouseIds: ["mem_xadicha"],
        photoUrl: "",
        profession: "Agronom, bog'dorchilik ustasi",
        bio: "Farg'ona vodiysida mevali bog'lar yaratgan mashhur soha mutaxassisi.",
        generation: 2
      },
      {
        id: "mem_xadicha",
        firstName: "Xadicha",
        lastName: "Rahimova",
        middleName: "Qosim qizi",
        nickname: "",
        gender: "female",
        birthYear: 1927,
        birthDate: "1927-02-14",
        birthPlace: "Farg'ona",
        deathYear: 2012,
        deathDate: "2012-03-10",
        deathPlace: "Farg'ona",
        isLiving: false,
        fatherId: null,
        motherId: null,
        spouseIds: ["mem_mahmud"],
        photoUrl: "",
        profession: "Hamshira",
        bio: "Shifoxonada ko'p yillar xalq salomatligi yo'lida fidokorona ishlagan.",
        generation: 2
      },
      {
        id: "mem_robiya",
        firstName: "Robiya",
        lastName: "Rahimova",
        middleName: "Karim qizi",
        nickname: "",
        gender: "female",
        birthYear: 1928,
        birthDate: "1928-06-25",
        birthPlace: "Toshkent",
        deathYear: 2015,
        deathDate: "2015-11-12",
        deathPlace: "Samarqand",
        isLiving: false,
        fatherId: "mem_karim",
        motherId: "mem_fotima",
        spouseIds: [],
        photoUrl: "",
        profession: "Ona tili va adabiyot o'qituvchisi",
        bio: "Samarqandda uzoq yillar dars bergan, maktabda hurmatli faxriy ustoz bo'lgan.",
        generation: 2
      },
      {
        id: "mem_rustam",
        firstName: "Rustam",
        lastName: "Rahimov",
        middleName: "Abdulla o'g'li",
        nickname: "",
        gender: "male",
        birthYear: 1948,
        birthDate: "1948-08-12",
        birthPlace: "Toshkent",
        deathYear: 2018,
        deathDate: "2018-09-03",
        deathPlace: "Toshkent",
        isLiving: false,
        fatherId: "mem_abdulla",
        motherId: "mem_salima",
        spouseIds: ["mem_gulnora"],
        photoUrl: "",
        profession: "Bosh muhandis, ixtirochi",
        bio: "O'zbekiston energetika tizimida ulkan iz qoldirgan, energetika sohasida kashfiyotlar muallifi.",
        generation: 3
      },
      {
        id: "mem_gulnora",
        firstName: "Gulnora",
        lastName: "Rahimova",
        middleName: "Anvar qizi",
        nickname: "",
        gender: "female",
        birthYear: 1952,
        birthDate: "1952-03-08",
        birthPlace: "Toshkent",
        deathYear: null,
        deathDate: "",
        deathPlace: "",
        isLiving: true,
        fatherId: null,
        motherId: null,
        spouseIds: ["mem_rustam"],
        photoUrl: "",
        profession: "Iqtisodchi, bank xodimi",
        bio: "Moliya-iqtisod sohasida faoliyat yuritgan, hozirda tabarruk nafaqada, nevaralar ardog'ida.",
        generation: 3
      },
      {
        id: "mem_ziyoda",
        firstName: "Ziyoda",
        lastName: "Rahimova",
        middleName: "Abdulla qizi",
        nickname: "",
        gender: "female",
        birthYear: 1954,
        birthDate: "1954-10-19",
        birthPlace: "Toshkent",
        deathYear: null,
        deathDate: "",
        deathPlace: "",
        isLiving: true,
        fatherId: "mem_abdulla",
        motherId: "mem_salima",
        spouseIds: [],
        photoUrl: "",
        profession: "Shifokor-pediatr",
        bio: "Oliy toifali bolalar shifokori, bolalar salomatligini himoya qilishda katta xizmat qilgan.",
        generation: 3
      },
      {
        id: "mem_alisher",
        firstName: "Alisher",
        lastName: "Rahimov",
        middleName: "Mahmud o'g'li",
        nickname: "",
        gender: "male",
        birthYear: 1956,
        birthDate: "1956-05-22",
        birthPlace: "Farg'ona",
        deathYear: null,
        deathDate: "",
        deathPlace: "",
        isLiving: true,
        fatherId: "mem_mahmud",
        motherId: "mem_xadicha",
        spouseIds: ["mem_muyassar"],
        photoUrl: "",
        profession: "Qishloq xo'jaligi mutaxassisi, fermer",
        bio: "Zamonaviy issiqxonalar va bog'dorchilik klasteri asoschisi.",
        generation: 3
      },
      {
        id: "mem_muyassar",
        firstName: "Muyassar",
        lastName: "Rahimova",
        middleName: "Habib qizi",
        nickname: "",
        gender: "female",
        birthYear: 1960,
        birthDate: "1960-01-30",
        birthPlace: "Andijon",
        deathYear: null,
        deathDate: "",
        deathPlace: "",
        isLiving: true,
        fatherId: null,
        motherId: null,
        spouseIds: ["mem_alisher"],
        photoUrl: "",
        profession: "Kimyo-biologiya o'qituvchisi",
        bio: "Ko'plab olimpiada g'oliblarini tayyorlagan oliy toifali ustoz.",
        generation: 3
      },
      {
        id: "mem_dilshod",
        firstName: "Dilshod",
        lastName: "Rahimov",
        middleName: "Mahmud o'g'li",
        nickname: "",
        gender: "male",
        birthYear: 1962,
        birthDate: "1962-12-04",
        birthPlace: "Farg'ona",
        deathYear: null,
        deathDate: "",
        deathPlace: "",
        isLiving: true,
        fatherId: "mem_mahmud",
        motherId: "mem_xadicha",
        spouseIds: [],
        photoUrl: "",
        profession: "Xalqaro logistika eksperti",
        bio: "Tadbirkorlik va xalqaro savdo sohasida faoliyat yuritadi.",
        generation: 3
      },
      {
        id: "mem_bobur",
        firstName: "Bobur",
        lastName: "Rahimov",
        middleName: "Rustam o'g'li",
        nickname: "",
        gender: "male",
        birthYear: 1980,
        birthDate: "1980-02-17",
        birthPlace: "Toshkent",
        deathYear: null,
        deathDate: "",
        deathPlace: "",
        isLiving: true,
        fatherId: "mem_rustam",
        motherId: "mem_gulnora",
        spouseIds: ["mem_nargiza"],
        photoUrl: "",
        profession: "Dasturiy injiniring rahbari (Tech Lead)",
        bio: "Xalqaro IT kompaniyalarida mas'ul lavozimlarda faoliyat yuritadi, innovatsion loyihalar muallifi.",
        generation: 4
      },
      {
        id: "mem_nargiza",
        firstName: "Nargiza",
        lastName: "Rahimova",
        middleName: "Akrom qizi",
        nickname: "",
        gender: "female",
        birthYear: 1984,
        birthDate: "1984-07-14",
        birthPlace: "Toshkent",
        deathYear: null,
        deathDate: "",
        deathPlace: "",
        isLiving: true,
        fatherId: null,
        motherId: null,
        spouseIds: ["mem_bobur"],
        photoUrl: "",
        profession: "Grafik dizayner va rassom",
        bio: "Kitob bezaklari va madaniy illyustratsiyalar bilan shug'ullanadi.",
        generation: 4
      },
      {
        id: "mem_nilufar",
        firstName: "Nilufar",
        lastName: "Rahimova",
        middleName: "Rustam qizi",
        nickname: "",
        gender: "female",
        birthYear: 1985,
        birthDate: "1985-09-28",
        birthPlace: "Toshkent",
        deathYear: null,
        deathDate: "",
        deathPlace: "",
        isLiving: true,
        fatherId: "mem_rustam",
        motherId: "mem_gulnora",
        spouseIds: [],
        photoUrl: "",
        profession: "Ingliz tili filologi, tarjimon",
        bio: "Xalqaro konferensiyalarda sinxron tarjimonlik qiladi.",
        generation: 4
      },
      {
        id: "mem_sardor",
        firstName: "Sardor",
        lastName: "Rahimov",
        middleName: "Alisher o'g'li",
        nickname: "",
        gender: "male",
        birthYear: 1988,
        birthDate: "1988-06-11",
        birthPlace: "Farg'ona",
        deathYear: null,
        deathDate: "",
        deathPlace: "",
        isLiving: true,
        fatherId: "mem_alisher",
        motherId: "mem_muyassar",
        spouseIds: [],
        photoUrl: "",
        profession: "Investitsiya tahlilchisi",
        bio: "Yirik korxonalarda moliyaviy strategiya va investitsiyalarni boshqaradi.",
        generation: 4
      },
      {
        id: "mem_jamshid",
        firstName: "Jamshid",
        lastName: "Rahimov",
        middleName: "Dilshod o'g'li",
        nickname: "",
        gender: "male",
        birthYear: 1992,
        birthDate: "1992-11-03",
        birthPlace: "Toshkent",
        deathYear: null,
        deathDate: "",
        deathPlace: "",
        isLiving: true,
        fatherId: "mem_dilshod",
        motherId: null,
        spouseIds: [],
        photoUrl: "",
        profession: "Shaharsozlik arxitektori",
        bio: "Zamonaviy eko-shaharlar va jamoat maskanlari loyihalash bo'yicha mutaxassis.",
        generation: 4
      },
      {
        id: "mem_temur",
        firstName: "Temur",
        lastName: "Rahimov",
        middleName: "Bobur o'g'li",
        nickname: "",
        gender: "male",
        birthYear: 2010,
        birthDate: "2010-04-09",
        birthPlace: "Toshkent",
        deathYear: null,
        deathDate: "",
        deathPlace: "",
        isLiving: true,
        fatherId: "mem_bobur",
        motherId: "mem_nargiza",
        spouseIds: [],
        photoUrl: "",
        profession: "O'quvchi, robototexnika qiziqishi",
        bio: "Sulolaning 5-avlodi. Matematika va dasturlashga qiziqadi, xalqaro robototexnika tanlovlari ishtirokchisi.",
        generation: 5
      },
      {
        id: "mem_madina",
        firstName: "Madina",
        lastName: "Rahimova",
        middleName: "Bobur qizi",
        nickname: "",
        gender: "female",
        birthYear: 2015,
        birthDate: "2015-12-20",
        birthPlace: "Toshkent",
        deathYear: null,
        deathDate: "",
        deathPlace: "",
        isLiving: true,
        fatherId: "mem_bobur",
        motherId: "mem_nargiza",
        spouseIds: [],
        photoUrl: "",
        profession: "O'quvchi, gimnastika va rasm",
        bio: "Sulolaning 5-avlodi. Badiiy gimnastika bilan shug'ullanadi.",
        generation: 5
      }
    ]
  };
}

// Sample Default Memories Generator
function getDefaultMemories() {
  return [
    {
      id: "memo_1",
      title: "Karim boboning Qo'qondagi naqqoshlik ustaxonasi",
      year: 1952,
      date: "1952-yil bahor",
      place: "Qo'qon shahar, Dahbidi mahallasi",
      imageUrl: "https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=1200&q=80",
      description: "Karim bobo (Usta Karim) o'z shogirdlari va o'g'illari bilan birga an'anaviy o'zbek o'ymakorligi va milliy uylar ustunlarini bezatayotgan davrlari. Ushbu surat sulolamizning hunarmandchilik ildizlaridan qadrli yodgorlikdir.",
      taggedMemberIds: ["mem_karim", "mem_abdulla", "mem_mahmud"],
      createdAt: new Date().toISOString()
    },
    {
      id: "memo_2",
      title: "Abdulla boboning maktab jamoasi bilan uchrashuvi",
      year: 1974,
      date: "1974-yil 1-sentyabr",
      place: "Toshkent shahar",
      imageUrl: "https://images.unsplash.com/photo-1524178232363-1fb2b075b655?auto=format&fit=crop&w=1200&q=80",
      description: "Abdulla Rahimov matematika fani o'qituvchisi va maktab direktori sifatida xalq maorifiga 40 yildan ortiq xizmat qildi. Ko'plab olimpiada g'oliblarini yetishtirgan tabarruk ustoz.",
      taggedMemberIds: ["mem_abdulla", "mem_salima"],
      createdAt: new Date().toISOString()
    },
    {
      id: "memo_3",
      title: "Farg'ona vodiysidagi olmali bog'da oilaviy yig'in",
      year: 1985,
      date: "1985-yil avgust",
      place: "Farg'ona",
      imageUrl: "https://images.unsplash.com/photo-1506869640319-fe1a24fd76dc?auto=format&fit=crop&w=1200&q=80",
      description: "Mahmud bobo barpo etgan mevali bog'da sulolaning katta yig'ini. Mahmud ota va Xadicha aya barcha farzandlarini bir dasturxon atrofida jamlagan qutlug' kunlardan biri.",
      taggedMemberIds: ["mem_mahmud", "mem_xadicha", "mem_alisher", "mem_dilshod"],
      createdAt: new Date().toISOString()
    },
    {
      id: "memo_4",
      title: "Temur va Madinaning xalqaro tanlovdagi g'alabasi",
      year: 2024,
      date: "2024-yil may",
      place: "Toshkent",
      imageUrl: "https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?auto=format&fit=crop&w=1200&q=80",
      description: "Sulolamizning 5-avlodi yoshlari. Temur robototexnika bo'yicha xalqaro musobaqada faxrli o'rinni egalladi, Madina esa badiiy gimnastika bo'yicha oltin medal sohibasi bo'ldi.",
      taggedMemberIds: ["mem_bobur", "mem_nargiza", "mem_temur", "mem_madina"],
      createdAt: new Date().toISOString()
    }
  ];
}

// Database helper functions
function readDb() {
  if (!fs.existsSync(DB_FILE)) {
    const seed = getInitialSeedData();
    seed.memories = getDefaultMemories();
    writeDb(seed);
    return seed;
  }
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    const db = JSON.parse(raw);
    if (!db.memories || db.memories.length === 0) {
      db.memories = getDefaultMemories();
      writeDb(db);
    }
    return db;
  } catch (err) {
    console.error('Error reading DB, restoring initial seed:', err);
    const seed = getInitialSeedData();
    seed.memories = getDefaultMemories();
    writeDb(seed);
    return seed;
  }
}

function writeDb(data) {
  // Create backup before writing
  try {
    if (fs.existsSync(DB_FILE)) {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backupPath = path.join(BACKUPS_DIR, `shajara_backup_${timestamp}.json`);
      fs.copyFileSync(DB_FILE, backupPath);

      // Keep only last 10 backups
      const files = fs.readdirSync(BACKUPS_DIR)
        .filter(f => f.startsWith('shajara_backup_'))
        .sort()
        .reverse();
      if (files.length > 10) {
        files.slice(10).forEach(oldFile => {
          try { fs.unlinkSync(path.join(BACKUPS_DIR, oldFile)); } catch (e) {}
        });
      }
    }
  } catch (e) {
    console.warn('Backup creation failed:', e.message);
  }

  // Atomic write via temp file
  const tmpFile = `${DB_FILE}.tmp_${Date.now()}`;
  fs.writeFileSync(tmpFile, JSON.stringify(data, null, 2), 'utf-8');
  fs.renameSync(tmpFile, DB_FILE);
}

// Config helper functions (Admin password)
function readConfig() {
  if (!fs.existsSync(CONFIG_FILE)) {
    const salt = bcrypt.genSaltSync(10);
    const hash = bcrypt.hashSync('admin123', salt);
    const initialConfig = {
      adminPasswordHash: hash,
      adminUsername: 'admin',
      lastPasswordChange: new Date().toISOString()
    };
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(initialConfig, null, 2), 'utf-8');
    return initialConfig;
  }
  try {
    return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf-8'));
  } catch (e) {
    return { adminPasswordHash: bcrypt.hashSync('admin123', 10), adminUsername: 'admin' };
  }
}

function writeConfig(config) {
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf-8');
}

// Authentication Middleware
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Avtorizatsiya talab etiladi (Token mavjud emas)!' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Yaroqsiz yoki muddati o‘tgan token!' });
    }
    req.user = user;
    next();
  });
}

// Calculate generations dynamically
function recalculateGenerations(members) {
  const memberMap = new Map();
  members.forEach(m => memberMap.set(m.id, m));

  const memo = new Map();

  function getGen(id, visited = new Set()) {
    if (!id || !memberMap.has(id)) return 1;
    if (visited.has(id)) return 1; // cycle protection
    if (memo.has(id)) return memo.get(id);

    visited.add(id);
    const m = memberMap.get(id);

    let maxParentGen = 0;
    if (m.fatherId && memberMap.has(m.fatherId)) {
      maxParentGen = Math.max(maxParentGen, getGen(m.fatherId, new Set(visited)));
    }
    if (m.motherId && memberMap.has(m.motherId)) {
      maxParentGen = Math.max(maxParentGen, getGen(m.motherId, new Set(visited)));
    }

    const gen = maxParentGen > 0 ? maxParentGen + 1 : 1;
    memo.set(id, gen);
    return gen;
  }

  return members.map(m => ({
    ...m,
    generation: getGen(m.id)
  }));
}

// =================== API ROUTES ===================

// Public: Get all data
app.get('/api/data', (req, res) => {
  try {
    const db = readDb();
    res.json({
      success: true,
      dynasty: db.dynasty,
      members: db.members,
      memories: db.memories || []
    });
  } catch (err) {
    res.status(500).json({ error: 'Ma’lumotlarni o‘qishda xatolik yuz berdi: ' + err.message });
  }
});

// Public: Statistics
app.get('/api/stats', (req, res) => {
  try {
    const db = readDb();
    const members = db.members || [];
    const total = members.length;
    const males = members.filter(m => m.gender === 'male').length;
    const females = members.filter(m => m.gender === 'female').length;
    const living = members.filter(m => m.isLiving).length;
    const deceased = total - living;

    const generations = [...new Set(members.map(m => m.generation || 1))].sort((a,b)=>a-b);
    const maxGen = generations.length > 0 ? Math.max(...generations) : 0;

    // Professions count
    const profs = {};
    members.forEach(m => {
      if (m.profession && m.profession.trim()) {
        const p = m.profession.split(',')[0].trim();
        profs[p] = (profs[p] || 0) + 1;
      }
    });

    res.json({
      total,
      males,
      females,
      living,
      deceased,
      generationsCount: maxGen,
      generations,
      topProfessions: profs
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Auth: Login
app.post('/api/auth/login', (req, res) => {
  const { password } = req.body;
  if (!password) {
    return res.status(400).json({ error: 'Parol kiritilmadi!' });
  }

  const config = readConfig();
  const isValid = bcrypt.compareSync(password, config.adminPasswordHash);

  if (!isValid) {
    return res.status(401).json({ error: 'Noto‘g‘ri admin paroli! Qaytadan urinib ko‘ring.' });
  }

  const token = jwt.sign({ role: 'admin', user: 'admin' }, JWT_SECRET, { expiresIn: '7d' });
  res.json({
    success: true,
    message: 'Muvaffaqiyatli tizimga kirildi!',
    token
  });
});

// Auth: Check Token Status
app.get('/api/auth/status', (req, res) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.json({ authenticated: false });

  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) return res.json({ authenticated: false });
    res.json({ authenticated: true, user: decoded });
  });
});

// Auth: Change Admin Password (Admin only)
app.post('/api/auth/change-password', authenticateToken, (req, res) => {
  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword) {
    return res.status(400).json({ error: 'Joriy va yangi parolni to‘liq kiriting!' });
  }
  if (newPassword.length < 5) {
    return res.status(400).json({ error: 'Yangi parol kamida 5 ta belgidan iborat bo‘lishi lozim!' });
  }

  const config = readConfig();
  const isValid = bcrypt.compareSync(currentPassword, config.adminPasswordHash);
  if (!isValid) {
    return res.status(401).json({ error: 'Joriy parol noto‘g‘ri!' });
  }

  config.adminPasswordHash = bcrypt.hashSync(newPassword, 10);
  config.lastPasswordChange = new Date().toISOString();
  writeConfig(config);

  res.json({ success: true, message: 'Admin paroli muvaffaqiyatli yangilandi!' });
});

// Admin: Update Dynasty Settings
app.put('/api/dynasty', authenticateToken, (req, res) => {
  const { title, subtitle, motto, rootPersonId } = req.body;
  const db = readDb();

  db.dynasty = {
    ...db.dynasty,
    title: title || db.dynasty.title,
    subtitle: subtitle !== undefined ? subtitle : db.dynasty.subtitle,
    motto: motto !== undefined ? motto : db.dynasty.motto,
    rootPersonId: rootPersonId !== undefined ? rootPersonId : db.dynasty.rootPersonId,
    updatedAt: new Date().toISOString()
  };

  writeDb(db);
  res.json({ success: true, dynasty: db.dynasty });
});

// Admin: Photo Upload
app.post('/api/upload', authenticateToken, upload.single('photo'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'Fayl yuklanmadi!' });
  }
  const photoUrl = `/uploads/${req.file.filename}`;
  res.json({ success: true, photoUrl });
});

// Admin: Add Member
app.post('/api/members', authenticateToken, (req, res) => {
  try {
    const data = req.body;
    if (!data.firstName || !data.gender) {
      return res.status(400).json({ error: 'Ism va jinsi ko‘rsatilishi shart!' });
    }

    const db = readDb();
    const newId = `mem_${Date.now()}_${uuidv4().slice(0, 4)}`;

    const newMember = {
      id: newId,
      firstName: data.firstName.trim(),
      lastName: (data.lastName || '').trim(),
      middleName: (data.middleName || '').trim(),
      nickname: (data.nickname || '').trim(),
      gender: data.gender === 'female' ? 'female' : 'male',
      birthYear: data.birthYear ? parseInt(data.birthYear, 10) : null,
      birthDate: data.birthDate || '',
      birthPlace: (data.birthPlace || '').trim(),
      deathYear: data.deathYear ? parseInt(data.deathYear, 10) : null,
      deathDate: data.deathDate || '',
      deathPlace: (data.deathPlace || '').trim(),
      isLiving: data.isLiving !== undefined ? Boolean(data.isLiving) : true,
      fatherId: data.fatherId || null,
      motherId: data.motherId || null,
      spouseIds: Array.isArray(data.spouseIds) ? data.spouseIds : (data.spouseId ? [data.spouseId] : []),
      photoUrl: data.photoUrl || '',
      profession: (data.profession || '').trim(),
      bio: (data.bio || '').trim(),
      generation: 1,
      createdAt: new Date().toISOString()
    };

    // If spouse selected, ensure mutual spouse relationship
    newMember.spouseIds.forEach(spId => {
      const spouse = db.members.find(m => m.id === spId);
      if (spouse) {
        spouse.spouseIds = spouse.spouseIds || [];
        if (!spouse.spouseIds.includes(newId)) {
          spouse.spouseIds.push(newId);
        }
      }
    });

    db.members.push(newMember);
    db.members = recalculateGenerations(db.members);

    writeDb(db);
    res.status(201).json({ success: true, member: newMember, allMembers: db.members });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Admin: Update Member
app.put('/api/members/:id', authenticateToken, (req, res) => {
  try {
    const memberId = req.params.id;
    const data = req.body;
    const db = readDb();

    const index = db.members.findIndex(m => m.id === memberId);
    if (index === -1) {
      return res.status(404).json({ error: 'A’zo topilmadi!' });
    }

    const oldSpouses = db.members[index].spouseIds || [];
    const newSpouses = Array.isArray(data.spouseIds) ? data.spouseIds : (data.spouseId ? [data.spouseId] : []);

    const updated = {
      ...db.members[index],
      firstName: data.firstName ? data.firstName.trim() : db.members[index].firstName,
      lastName: data.lastName !== undefined ? data.lastName.trim() : db.members[index].lastName,
      middleName: data.middleName !== undefined ? data.middleName.trim() : db.members[index].middleName,
      nickname: data.nickname !== undefined ? data.nickname.trim() : db.members[index].nickname,
      gender: data.gender === 'female' ? 'female' : 'male',
      birthYear: data.birthYear ? parseInt(data.birthYear, 10) : null,
      birthDate: data.birthDate !== undefined ? data.birthDate : db.members[index].birthDate,
      birthPlace: data.birthPlace !== undefined ? data.birthPlace.trim() : db.members[index].birthPlace,
      deathYear: data.deathYear ? parseInt(data.deathYear, 10) : null,
      deathDate: data.deathDate !== undefined ? data.deathDate : db.members[index].deathDate,
      deathPlace: data.deathPlace !== undefined ? data.deathPlace.trim() : db.members[index].deathPlace,
      isLiving: data.isLiving !== undefined ? Boolean(data.isLiving) : db.members[index].isLiving,
      fatherId: data.fatherId !== undefined ? (data.fatherId || null) : db.members[index].fatherId,
      motherId: data.motherId !== undefined ? (data.motherId || null) : db.members[index].motherId,
      spouseIds: newSpouses,
      photoUrl: data.photoUrl !== undefined ? data.photoUrl : db.members[index].photoUrl,
      profession: data.profession !== undefined ? data.profession.trim() : db.members[index].profession,
      bio: data.bio !== undefined ? data.bio.trim() : db.members[index].bio,
      updatedAt: new Date().toISOString()
    };

    // Clean up old spouse links if removed
    oldSpouses.forEach(spId => {
      if (!newSpouses.includes(spId)) {
        const prevSpouse = db.members.find(m => m.id === spId);
        if (prevSpouse && prevSpouse.spouseIds) {
          prevSpouse.spouseIds = prevSpouse.spouseIds.filter(id => id !== memberId);
        }
      }
    });

    // Add new spouse reciprocal links
    newSpouses.forEach(spId => {
      const sp = db.members.find(m => m.id === spId);
      if (sp) {
        sp.spouseIds = sp.spouseIds || [];
        if (!sp.spouseIds.includes(memberId)) {
          sp.spouseIds.push(memberId);
        }
      }
    });

    db.members[index] = updated;
    db.members = recalculateGenerations(db.members);

    writeDb(db);
    res.json({ success: true, member: updated, allMembers: db.members });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Admin: Delete Member
app.delete('/api/members/:id', authenticateToken, (req, res) => {
  try {
    const memberId = req.params.id;
    const db = readDb();

    const exists = db.members.some(m => m.id === memberId);
    if (!exists) {
      return res.status(404).json({ error: 'A’zo topilmadi!' });
    }

    // Remove member and clean references in others
    db.members = db.members.filter(m => m.id !== memberId);
    db.members.forEach(m => {
      if (m.fatherId === memberId) m.fatherId = null;
      if (m.motherId === memberId) m.motherId = null;
      if (m.spouseIds && m.spouseIds.includes(memberId)) {
        m.spouseIds = m.spouseIds.filter(id => id !== memberId);
      }
    });

    // If root deleted, reset root
    if (db.dynasty.rootPersonId === memberId) {
      db.dynasty.rootPersonId = db.members[0] ? db.members[0].id : null;
    }

    db.members = recalculateGenerations(db.members);
    writeDb(db);

    res.json({ success: true, message: 'A’zo muvaffaqiyatli o‘chirildi!', allMembers: db.members });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Admin: Clear all members (start fresh)
app.post('/api/members/clear', authenticateToken, (req, res) => {
  try {
    const db = readDb();
    db.members = [];
    db.dynasty.rootPersonId = null;
    writeDb(db);
    res.json({ success: true, message: 'Barcha ma’lumotlar tozalandi. Yangi shajarani boshlashingiz mumkin!' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Admin: Reset to sample seed data
app.post('/api/members/reset-seed', authenticateToken, (req, res) => {
  try {
    const seed = getInitialSeedData();
    writeDb(seed);
    res.json({ success: true, message: 'Namunaviy ma’lumotlar qayta yuklandi!', data: seed });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Admin: Backup download
app.get('/api/backup', authenticateToken, (req, res) => {
  try {
    const db = readDb();
    const filename = `shajara_zaxira_${new Date().toISOString().slice(0, 10)}.json`;
    res.setHeader('Content-disposition', `attachment; filename=${filename}`);
    res.setHeader('Content-type', 'application/json');
    res.send(JSON.stringify(db, null, 2));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Admin: Restore from JSON backup
app.post('/api/restore', authenticateToken, (req, res) => {
  try {
    const data = req.body;
    if (!data || !Array.isArray(data.members)) {
      return res.status(400).json({ error: 'Zaxira fayli formati noto‘g‘ri (members ro‘yxati topilmadi)!' });
    }

    const restored = {
      dynasty: data.dynasty || {
        title: "Sulola Shajarasi",
        subtitle: "",
        rootPersonId: data.members[0]?.id || null,
        updatedAt: new Date().toISOString()
      },
      members: recalculateGenerations(data.members)
    };

    writeDb(restored);
    res.json({ success: true, message: 'Shajara zaxiradan muvaffaqiyatli tiklandi!', data: restored });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =================== ESDALIKLAR (MEMORIES) API ===================

// Public: Get all memories
app.get('/api/memories', (req, res) => {
  try {
    const db = readDb();
    res.json({ success: true, memories: db.memories || [] });
  } catch (err) {
    res.status(500).json({ error: 'Esdaliklarni o‘qishda xatolik: ' + err.message });
  }
});

// Admin: Add memory
app.post('/api/memories', authenticateToken, (req, res) => {
  try {
    const data = req.body;
    if (!data.title) {
      return res.status(400).json({ error: 'Esdalik sarlavhasi kiritilishi shart!' });
    }
    if (!data.imageUrl) {
      return res.status(400).json({ error: 'Esdalik uchun fotosurat yuklanishi shart!' });
    }

    const db = readDb();
    db.memories = db.memories || [];

    const newMemory = {
      id: `memo_${Date.now()}_${uuidv4().slice(0, 4)}`,
      title: data.title.trim(),
      year: data.year ? parseInt(data.year, 10) : null,
      date: (data.date || '').trim(),
      place: (data.place || '').trim(),
      imageUrl: data.imageUrl.trim(),
      description: (data.description || '').trim(),
      taggedMemberIds: Array.isArray(data.taggedMemberIds) ? data.taggedMemberIds : [],
      createdAt: new Date().toISOString()
    };

    db.memories.unshift(newMemory);
    writeDb(db);

    res.status(201).json({ success: true, memory: newMemory, allMemories: db.memories });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Admin: Update memory
app.put('/api/memories/:id', authenticateToken, (req, res) => {
  try {
    const memoryId = req.params.id;
    const data = req.body;
    const db = readDb();
    db.memories = db.memories || [];

    const index = db.memories.findIndex(m => m.id === memoryId);
    if (index === -1) {
      return res.status(404).json({ error: 'Esdalik topilmadi!' });
    }

    const updated = {
      ...db.memories[index],
      title: data.title ? data.title.trim() : db.memories[index].title,
      year: data.year !== undefined ? (data.year ? parseInt(data.year, 10) : null) : db.memories[index].year,
      date: data.date !== undefined ? data.date.trim() : db.memories[index].date,
      place: data.place !== undefined ? data.place.trim() : db.memories[index].place,
      imageUrl: data.imageUrl !== undefined ? data.imageUrl.trim() : db.memories[index].imageUrl,
      description: data.description !== undefined ? data.description.trim() : db.memories[index].description,
      taggedMemberIds: Array.isArray(data.taggedMemberIds) ? data.taggedMemberIds : db.memories[index].taggedMemberIds,
      updatedAt: new Date().toISOString()
    };

    db.memories[index] = updated;
    writeDb(db);

    res.json({ success: true, memory: updated, allMemories: db.memories });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Admin: Delete memory
app.delete('/api/memories/:id', authenticateToken, (req, res) => {
  try {
    const memoryId = req.params.id;
    const db = readDb();
    db.memories = db.memories || [];

    const exists = db.memories.some(m => m.id === memoryId);
    if (!exists) {
      return res.status(404).json({ error: 'Esdalik topilmadi!' });
    }

    db.memories = db.memories.filter(m => m.id !== memoryId);
    writeDb(db);

    res.json({ success: true, message: 'Esdalik muvaffaqiyatli o‘chirildi!', allMemories: db.memories });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// SPA fallback
app.use((req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start Server
app.listen(PORT, () => {
  console.log(`===============================================`);
  console.log(`   🌳 Shajara Veb Dasturi Ishga Tushdi!`);
  console.log(`   Manzil: http://localhost:${PORT}`);
  console.log(`   Admin Paroli (boshlang'ich): admin123`);
  console.log(`===============================================`);
});
