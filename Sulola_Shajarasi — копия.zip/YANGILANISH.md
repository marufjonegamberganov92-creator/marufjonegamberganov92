# Sulola Shajarasi — 2.0 "Motion" yangilanishi

## O'rnatish
Arxivdagi `public/` papkasini loyihangizdagi `public/` ustiga nusxalang (fayllarni almashtiring):

| Fayl | Holati |
|---|---|
| `public/index.html` | yangilandi (yangi tugmalar, Vaqt mashinasi paneli, Ctrl+K oynasi, 2 ta yangi ulanish) |
| `public/js/tree.js` | yangilandi (API o'zgarmagan — `app.js` tegilmaydi) |
| `public/js/motion.js` | **yangi** |
| `public/css/motion.css` | **yangi** |
| `public/css/styles.css`, `modern.css` | o'zgarmagan |

`api.js`, `relatives.js`, `admin.js`, `app.js` fayllariga **tegish shart emas**. Barcha eski ID'lar saqlangan.

## Yangi imkoniyatlar
- **Daraxt o'sib chiqadi** — kartalar avlodma-avlod paydo bo'ladi, chiziqlar chizilib boradi. "O'stirish" tugmasi animatsiyani qayta ko'rsatadi.
- **Silliq yig'ish/ochish** — kartalar yangi joyiga suriladi, yangi farzandlar ota-onasidan "chiqadi".
- **Ajdodlar yo'li** — yoritilgan zanjir bo'ylab oltin uchqunlar oqadi.
- **Vaqt mashinasi** — ▶ bosilsa, sulola yillar bo'yicha o'sadi; har yil uchun "Hayot: N kishi" sanog'i.
- **Mini-xarita** (o'ng pastda) — bosib yoki sudrab daraxt bo'ylab yuring.
- **Avlod qatlamlari** — har avlod o'z fon chizig'i va "N-avlod" yorlig'i bilan.
- **Tezkor o'tish: Ctrl+K (Mac'da ⌘K) yoki "/"** — ism, kasb yoki yil yozing → Enter: daraxtda ko'rsatish, Shift+Enter: profil, Alt+Enter: ajdodlar yo'li.
- **Yosh ko'rsatkichi** kartalarda ("· 76 yosh"), jonli "Hayot" nuqtasi.
- **Klaviatura**: `+` `−` kattalashtirish, `0`/`F` markazlash, strelkalar bilan surish; bo'sh joyni 2 marta bosish — markazlash.
- **Sahifa harakati**: kirish animatsiyasi (sessiyada 1 marta), siljuvchi tab ko'rsatkichi, tablar orasida silliq o'tish, kartalar ketma-ket paydo bo'ladi, statistika raqamlari sanab chiqadi, tugmalarda to'lqin effekti.
- **"Hammasini ochish"** — barcha yig'ilgan shoxlarni bir bosishda ochadi.

## Xatti-harakatdagi o'zgarishlar
- `100%` tugmasi endi haqiqatan ham 100% masshtabga o'tkazadi (avval "markazlash" bilan bir xil edi).
- A'zo qo'shilgan/tahrirlangandan keyin daraxt joyidan sakramaydi, faqat o'zgargan kartalar silliq suriladi.
- Tizimda "harakatni kamaytirish" (prefers-reduced-motion) yoqilgan bo'lsa, barcha animatsiyalar o'chadi.
- Chop etishda xarita, panel va effektlar avtomatik yashiriladi.

## app.js uchun ixtiyoriy API
```js
tree.replayGrowth();          // daraxtni qayta o'stirish
tree.expandAll();             // barcha shoxlarni ochish
tree.setTimeYear(1960);       // vaqt filtri (null — o'chirish)
tree.getYearRange();          // { min, max }
document.addEventListener('shajara:data', e => ...); // setData chaqirilganda
```
