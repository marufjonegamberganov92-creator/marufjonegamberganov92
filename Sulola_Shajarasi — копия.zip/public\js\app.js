/**
 * Shajara - Asosiy Ilova Kontrolleri
 */

const App = {
  dynasty: null,
  members: [],
  memories: [],
  memberMap: new Map(),
  tree: null,
  activeTab: 'tree',
  currentViewingMember: null,
  currentViewingMemory: null,

  async init() {
    this.bindDOM();
    await Admin.init();
    await this.refreshAll();
  },

  bindDOM() {
    // Navigation Tabs
    const tabs = ['tree', 'members', 'memories', 'seven-ancestors', 'stats'];
    tabs.forEach(tabKey => {
      const btn = document.getElementById(`tab-btn-${tabKey}`);
      if (btn) {
        btn.addEventListener('click', () => this.switchTab(tabKey));
      }
    });

    // Search inputs
    const globalSearch = document.getElementById('global-search-input');
    if (globalSearch) {
      globalSearch.addEventListener('input', (e) => this.handleGlobalSearch(e.target.value));
      globalSearch.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          const results = Relatives.search(globalSearch.value, this.members);
          if (results.length > 0) {
            this.openPersonModal(results[0]);
            if (this.activeTab === 'tree') {
              this.tree.focusOnMember(results[0].id);
            }
          }
        }
      });
    }

    // Tree Controls
    document.getElementById('btn-zoom-in')?.addEventListener('click', () => this.tree?.zoomIn());
    document.getElementById('btn-zoom-out')?.addEventListener('click', () => this.tree?.zoomOut());
    document.getElementById('btn-zoom-reset')?.addEventListener('click', () => this.tree?.resetZoom());
    document.getElementById('btn-zoom-fit')?.addEventListener('click', () => this.tree?.fitToScreen());
    document.getElementById('btn-print-tree')?.addEventListener('click', () => {
      this.tree?.fitToScreen();
      setTimeout(() => window.print(), 300);
    });

    // Root Selector in Tree Header
    const treeRootSelect = document.getElementById('tree-root-select');
    if (treeRootSelect) {
      treeRootSelect.addEventListener('change', (e) => {
        if (this.tree && e.target.value) {
          this.tree.setRoot(e.target.value);
        }
      });
    }

    // Modal Close buttons
    document.querySelectorAll('[data-close-modal]').forEach(btn => {
      btn.addEventListener('click', () => {
        const modalId = btn.getAttribute('data-close-modal');
        document.getElementById(modalId)?.classList.add('hidden');
      });
    });

    // Close on backdrop click
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
          overlay.classList.add('hidden');
        }
      });
    });

    // Escape key
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay').forEach(m => m.classList.add('hidden'));
      }
    });

    // Admin Login Form
    document.getElementById('login-form')?.addEventListener('submit', (e) => {
      e.preventDefault();
      Admin.handleLogin();
    });

    // Add Member buttons
    document.querySelectorAll('.btn-open-add-member').forEach(btn => {
      btn.addEventListener('click', () => Admin.openMemberModal());
    });

    // Member Form Save
    document.getElementById('member-form')?.addEventListener('submit', (e) => {
      e.preventDefault();
      Admin.handleSaveMember();
    });

    // Photo input change
    const photoFileInput = document.getElementById('form-photo-file');
    if (photoFileInput) {
      photoFileInput.addEventListener('change', (e) => {
        if (e.target.files && e.target.files[0]) {
          Admin.handlePhotoUpload(e.target.files[0]);
        }
      });
    }

    // IsLiving checkbox toggle
    const isLivingCheck = document.getElementById('form-is-living');
    if (isLivingCheck) {
      isLivingCheck.addEventListener('change', (e) => {
        Admin.toggleDeathFields(!e.target.checked);
      });
    }

    // Settings Modal Open
    document.getElementById('btn-open-settings')?.addEventListener('click', () => {
      Admin.openSettingsModal();
    });

    // Settings Form Save
    document.getElementById('settings-dynasty-form')?.addEventListener('submit', (e) => {
      e.preventDefault();
      Admin.handleSaveDynastySettings();
    });

    // Change Password Form
    document.getElementById('change-password-form')?.addEventListener('submit', (e) => {
      e.preventDefault();
      Admin.handleChangePassword();
    });

    // Backup actions
    document.getElementById('btn-download-backup')?.addEventListener('click', () => {
      Admin.handleDownloadBackup();
    });

    const restoreInput = document.getElementById('restore-file-input');
    if (restoreInput) {
      restoreInput.addEventListener('change', (e) => {
        if (e.target.files && e.target.files[0]) {
          Admin.handleRestoreBackup(e.target.files[0]);
        }
      });
    }

    document.getElementById('btn-clear-all-members')?.addEventListener('click', () => {
      Admin.handleClearAll();
    });

    document.getElementById('btn-reset-demo-seed')?.addEventListener('click', () => {
      Admin.handleResetSeed();
    });

    // Members Directory Filters
    const directorySearch = document.getElementById('directory-search');
    const directoryGenFilter = document.getElementById('directory-gen-filter');
    const directoryGenderFilter = document.getElementById('directory-gender-filter');
    const directoryStatusFilter = document.getElementById('directory-status-filter');

    [directorySearch, directoryGenFilter, directoryGenderFilter, directoryStatusFilter].forEach(el => {
      el?.addEventListener('input', () => this.renderDirectoryList());
    });

    // Seven Ancestors Selector
    const ancestorSelect = document.getElementById('ancestor-person-select');
    if (ancestorSelect) {
      ancestorSelect.addEventListener('change', (e) => {
        this.renderSevenAncestors(e.target.value);
      });
    }

    // Memories (Esdaliklar) Listeners
    document.getElementById('btn-open-add-memory')?.addEventListener('click', () => {
      Admin.openMemoryModal();
    });

    const memoryFileInput = document.getElementById('memory-file-input');
    if (memoryFileInput) {
      memoryFileInput.addEventListener('change', (e) => {
        if (e.target.files && e.target.files[0]) {
          Admin.handleMemoryPhotoUpload(e.target.files[0]);
        }
      });
    }

    document.getElementById('memory-url-input')?.addEventListener('input', (e) => {
      Admin.updateMemoryPhotoPreview(e.target.value);
    });

    document.getElementById('memory-form')?.addEventListener('submit', (e) => {
      e.preventDefault();
      Admin.handleSaveMemory();
    });

    document.getElementById('lightbox-btn-edit')?.addEventListener('click', () => {
      if (this.currentViewingMemory) {
        document.getElementById('memory-lightbox-modal')?.classList.add('hidden');
        Admin.openMemoryModal(this.currentViewingMemory);
      }
    });

    document.getElementById('lightbox-btn-delete')?.addEventListener('click', () => {
      if (this.currentViewingMemory) {
        Admin.handleDeleteMemory(this.currentViewingMemory.id);
      }
    });

    // Memory filters
    const memorySearch = document.getElementById('memory-search-input');
    const memoryYearFilter = document.getElementById('memory-year-filter');
    const memoryMemberFilter = document.getElementById('memory-member-filter');

    [memorySearch, memoryYearFilter, memoryMemberFilter].forEach(el => {
      el?.addEventListener('input', () => this.renderMemoriesGallery());
    });
  },

  async refreshAll() {
    try {
      const data = await API.fetchData();
      this.dynasty = data.dynasty || {};
      this.members = data.members || [];
      this.memories = data.memories || [];
      this.memberMap.clear();
      this.members.forEach(m => this.memberMap.set(m.id, m));

      // Update header info
      this.updateHeaderInfo();

      // Init or update Tree
      if (!this.tree) {
        this.tree = new ShajaraTree('shajara-tree-canvas', {
          onNodeClick: (member) => this.openPersonModal(member)
        });
      }
      this.tree.setData(this.members, this.dynasty.rootPersonId);

      // Populate Tree Root Selector
      this.populateTreeRootSelect();

      // Populate Seven Ancestor Select
      this.populateAncestorSelect();

      // Update active view
      if (this.activeTab === 'members') {
        this.renderDirectoryList();
      } else if (this.activeTab === 'memories') {
        this.populateMemoryFilters();
        this.renderMemoriesGallery();
      } else if (this.activeTab === 'seven-ancestors') {
        const select = document.getElementById('ancestor-person-select');
        const selectedId = select?.value || this.members[this.members.length - 1]?.id || this.members[0]?.id;
        if (select && selectedId) select.value = selectedId;
        this.renderSevenAncestors(selectedId);
      } else if (this.activeTab === 'stats') {
        this.renderStatsView();
      }
    } catch (err) {
      this.showToast('Ma’lumotlarni yuklashda xatolik: ' + err.message, 'error');
    }
  },

  updateHeaderInfo() {
    const title = this.dynasty.title || 'Sulola Shajarasi';
    const subtitle = this.dynasty.subtitle || 'Ajdodlar qadri va avlodlar zanjiri';
    const motto = this.dynasty.motto || '';

    document.title = title;
    const titleEl = document.getElementById('dynasty-header-title');
    const subtitleEl = document.getElementById('dynasty-header-subtitle');
    const mottoEl = document.getElementById('dynasty-header-motto');

    if (titleEl) titleEl.textContent = title;
    if (subtitleEl) subtitleEl.textContent = subtitle;
    if (mottoEl) {
      if (motto) {
        mottoEl.textContent = `“${motto}”`;
        mottoEl.classList.remove('hidden');
      } else {
        mottoEl.classList.add('hidden');
      }
    }
  },

  populateTreeRootSelect() {
    const sel = document.getElementById('tree-root-select');
    if (!sel) return;
    sel.innerHTML = '<option value="">🌳 Asosiy ildizdan</option>';

    // Show older generations first
    const sorted = [...this.members].sort((a, b) => (a.generation || 1) - (b.generation || 1));
    sorted.forEach(m => {
      const opt = document.createElement('option');
      opt.value = m.id;
      opt.textContent = `${m.gender === 'male' ? '👨' : '👩'} ${m.firstName} ${m.lastName || ''} (${m.generation}-avlod)`;
      if (m.id === this.tree?.rootId) opt.selected = true;
      sel.appendChild(opt);
    });
  },

  populateAncestorSelect() {
    const sel = document.getElementById('ancestor-person-select');
    if (!sel) return;
    sel.innerHTML = '';

    // Show younger generation (latest descendants) first because they have more ancestors!
    const sorted = [...this.members].sort((a, b) => (b.generation || 1) - (a.generation || 1));
    sorted.forEach(m => {
      const opt = document.createElement('option');
      opt.value = m.id;
      opt.textContent = `${m.gender === 'male' ? '👨' : '👩'} ${m.firstName} ${m.lastName || ''} (${m.generation}-avlod, ${m.birthYear || '?'})`;
      sel.appendChild(opt);
    });
  },

  switchTab(tabKey) {
    this.activeTab = tabKey;
    const tabs = ['tree', 'members', 'memories', 'seven-ancestors', 'stats'];

    tabs.forEach(t => {
      const viewEl = document.getElementById(`view-${t}`);
      const btnEl = document.getElementById(`tab-btn-${t}`);
      const mobBtnEl = document.getElementById(`mob-tab-btn-${t}`);
      if (t === tabKey) {
        viewEl?.classList.remove('hidden');
        btnEl?.classList.add('bg-emerald-800', 'text-amber-100', 'shadow-xs', 'border', 'border-emerald-900');
        btnEl?.classList.remove('text-stone-700', 'hover:bg-[#e7dfcf]');
        mobBtnEl?.classList.add('bg-emerald-800', 'text-amber-100', 'shadow-xs');
        mobBtnEl?.classList.remove('bg-[#ede5d6]', 'text-stone-800');
      } else {
        viewEl?.classList.add('hidden');
        btnEl?.classList.remove('bg-emerald-800', 'text-amber-100', 'shadow-xs', 'border', 'border-emerald-900');
        btnEl?.classList.add('text-stone-700', 'hover:bg-[#e7dfcf]');
        mobBtnEl?.classList.remove('bg-emerald-800', 'text-amber-100', 'shadow-xs');
        mobBtnEl?.classList.add('bg-[#ede5d6]', 'text-stone-800');
      }
    });

    if (tabKey === 'tree') {
      setTimeout(() => this.tree?.fitToScreen(), 50);
    } else if (tabKey === 'members') {
      this.populateDirectoryFilters();
      this.renderDirectoryList();
    } else if (tabKey === 'memories') {
      this.populateMemoryFilters();
      this.renderMemoriesGallery();
    } else if (tabKey === 'seven-ancestors') {
      const sel = document.getElementById('ancestor-person-select');
      const val = sel?.value || this.members[this.members.length - 1]?.id || this.members[0]?.id;
      if (sel && val) sel.value = val;
      this.renderSevenAncestors(val);
    } else if (tabKey === 'stats') {
      this.renderStatsView();
    }
  },

  // Person Details Modal
  openPersonModal(member) {
    if (!member) return;
    this.currentViewingMember = member;

    const modal = document.getElementById('person-modal');
    if (!modal) return;

    const isMale = member.gender === 'male';

    // Avatar
    const avatarContainer = document.getElementById('modal-person-avatar');
    if (avatarContainer) {
      if (member.photoUrl) {
        avatarContainer.innerHTML = `<img src="${member.photoUrl}" alt="${member.firstName}" loading="lazy" decoding="async" class="w-24 h-24 rounded-full object-cover border-4 ${isMale ? 'border-sky-400' : 'border-rose-400'} shadow-md">`;
      } else {
        avatarContainer.innerHTML = `
          <div class="w-24 h-24 rounded-full ${isMale ? 'bg-sky-100 text-sky-600 border-sky-300' : 'bg-rose-100 text-rose-600 border-rose-300'} border-4 flex items-center justify-center text-3xl font-bold shadow-md">
            ${member.firstName.charAt(0)}
          </div>
        `;
      }
    }

    // Header info
    document.getElementById('modal-person-fullname').textContent = `${member.firstName} ${member.lastName || ''}`;
    document.getElementById('modal-person-middlename').textContent = member.middleName ? `(${member.middleName})` : '';

    const nickEl = document.getElementById('modal-person-nickname');
    if (nickEl) {
      if (member.nickname) {
        nickEl.textContent = `“${member.nickname}”`;
        nickEl.classList.remove('hidden');
      } else {
        nickEl.classList.add('hidden');
      }
    }

    // Badges
    const genBadge = document.getElementById('modal-person-gen');
    if (genBadge) {
      genBadge.textContent = `${member.generation}-avlod`;
      genBadge.className = `px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${isMale ? 'bg-sky-100 text-sky-800' : 'bg-rose-100 text-rose-800'}`;
    }

    const statusBadge = document.getElementById('modal-person-status');
    if (statusBadge) {
      if (member.isLiving) {
        statusBadge.innerHTML = `<span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800"><span class="w-2 h-2 rounded-full bg-emerald-500"></span> Hayot</span>`;
      } else {
        statusBadge.innerHTML = `<span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-700">🕊️ Marhum</span>`;
      }
    }

    // Life dates & place
    const birthStr = member.birthDate || (member.birthYear ? `${member.birthYear}-yil` : 'Noma’lum');
    const birthPlaceStr = member.birthPlace ? `, ${member.birthPlace}` : '';
    document.getElementById('modal-person-birth').textContent = `${birthStr}${birthPlaceStr}`;

    const deathContainer = document.getElementById('modal-person-death-container');
    if (deathContainer) {
      if (!member.isLiving) {
        deathContainer.classList.remove('hidden');
        const deathStr = member.deathDate || (member.deathYear ? `${member.deathYear}-yil` : 'Noma’lum');
        const deathPlaceStr = member.deathPlace ? `, ${member.deathPlace}` : '';
        document.getElementById('modal-person-death').textContent = `${deathStr}${deathPlaceStr}`;
      } else {
        deathContainer.classList.add('hidden');
      }
    }

    // Profession
    const profContainer = document.getElementById('modal-person-prof-container');
    if (profContainer) {
      if (member.profession) {
        profContainer.classList.remove('hidden');
        document.getElementById('modal-person-profession').textContent = member.profession;
      } else {
        profContainer.classList.add('hidden');
      }
    }

    // Bio
    const bioContainer = document.getElementById('modal-person-bio-container');
    if (bioContainer) {
      if (member.bio) {
        bioContainer.classList.remove('hidden');
        document.getElementById('modal-person-bio').textContent = member.bio;
      } else {
        bioContainer.classList.add('hidden');
      }
    }

    // Relatives
    this.renderPersonRelatives(member);

    // Tagged Memories in Person Profile
    this.renderPersonMemories(member);

    // Modal Actions
    const focusTreeBtn = document.getElementById('modal-btn-focus-tree');
    if (focusTreeBtn) {
      focusTreeBtn.onclick = () => {
        this.closePersonModal();
        this.switchTab('tree');
        this.tree.focusOnMember(member.id);
        this.tree.highlightLineage(member.id);
      };
    }

    const show7AncestorsBtn = document.getElementById('modal-btn-show-7ancestors');
    if (show7AncestorsBtn) {
      show7AncestorsBtn.onclick = () => {
        this.closePersonModal();
        this.switchTab('seven-ancestors');
        const sel = document.getElementById('ancestor-person-select');
        if (sel) sel.value = member.id;
        this.renderSevenAncestors(member.id);
      };
    }

    // Admin buttons inside modal
    const editBtn = document.getElementById('modal-btn-admin-edit');
    if (editBtn) {
      editBtn.onclick = () => {
        this.closePersonModal();
        Admin.openMemberModal(member);
      };
    }

    const deleteBtn = document.getElementById('modal-btn-admin-delete');
    if (deleteBtn) {
      deleteBtn.onclick = () => {
        Admin.handleDeleteMember(member.id);
      };
    }

    const addChildBtn = document.getElementById('modal-btn-admin-add-child');
    if (addChildBtn) {
      addChildBtn.onclick = () => {
        this.closePersonModal();
        const defaultParents = member.gender === 'male' ? { fatherId: member.id } : { motherId: member.id };
        Admin.openMemberModal(null, defaultParents);
      };
    }

    modal.classList.remove('hidden');
  },

  closePersonModal() {
    const modal = document.getElementById('person-modal');
    if (modal) modal.classList.add('hidden');
    this.currentViewingMember = null;
  },

  renderPersonRelatives(member) {
    const fam = Relatives.getImmediateFamily(member.id, this.members, this.memberMap);
    if (!fam) return;

    const renderChip = (m, label) => {
      if (!m) return `<span class="text-xs text-stone-400 italic">Kiritilmagan</span>`;
      const isMale = m.gender === 'male';
      const avatarHtml = m.photoUrl
        ? `<img src="${m.photoUrl}" alt="${m.firstName}" class="w-6 h-6 rounded-full object-cover border ${isMale ? 'border-sky-400' : 'border-rose-400'} shadow-xs flex-shrink-0 bg-stone-100">`
        : `<span class="w-6 h-6 rounded-full ${isMale ? 'bg-sky-100 text-sky-800 border-sky-200' : 'bg-rose-100 text-rose-800 border-rose-200'} border flex items-center justify-center font-serif font-bold text-[11px] flex-shrink-0 shadow-2xs">${m.firstName.charAt(0)}</span>`;

      return `
        <button type="button" class="relative-chip group inline-flex items-center gap-2 bg-[#fffdf8] hover:bg-[#faf5eb] border border-[#ded5c5] hover:border-amber-600/70 px-2.5 py-1.5 rounded-xl text-xs text-stone-800 shadow-xs hover:shadow transition-all duration-150 cursor-pointer text-left" data-member-id="${m.id}" title="${m.firstName} ${m.lastName || ''} profilini ko‘rish">
          ${avatarHtml}
          <div class="flex items-center gap-1.5 min-w-0">
            <span class="font-serif font-bold text-stone-900 group-hover:text-amber-900 leading-tight truncate">${m.firstName} ${m.lastName || ''}</span>
            ${label ? `<span class="text-[10px] font-sans font-medium px-1.5 py-0.5 rounded-md bg-[#f4ece0] text-stone-600 border border-[#e5dac7] leading-none whitespace-nowrap">${label}</span>` : ''}
          </div>
          <svg class="w-3 h-3 text-stone-400 group-hover:text-amber-700 group-hover:translate-x-0.5 transition flex-shrink-0 ml-0.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="9 18 15 12 9 6"/>
          </svg>
        </button>
      `;
    };

    // Father
    document.getElementById('rel-father-container').innerHTML = renderChip(fam.father, fam.father?.birthYear ? `${fam.father.birthYear}` : null);

    // Mother
    document.getElementById('rel-mother-container').innerHTML = renderChip(fam.mother, fam.mother?.birthYear ? `${fam.mother.birthYear}` : null);

    // Spouses
    const spousesEl = document.getElementById('rel-spouses-container');
    if (fam.spouses.length > 0) {
      spousesEl.innerHTML = fam.spouses.map(s => renderChip(s, 'Turmush o‘rtog‘i')).join(' ');
    } else {
      spousesEl.innerHTML = `<span class="text-xs text-stone-400 italic">Kiritilmagan</span>`;
    }

    // Children
    const childrenEl = document.getElementById('rel-children-container');
    if (fam.children.length > 0) {
      childrenEl.innerHTML = fam.children.map(c => renderChip(c, c.birthYear ? `${c.birthYear}` : null)).join(' ');
    } else {
      childrenEl.innerHTML = `<span class="text-xs text-stone-400 italic">Farzandlar mavjud emas</span>`;
    }

    // Siblings
    const siblingsEl = document.getElementById('rel-siblings-container');
    if (fam.siblings.length > 0) {
      siblingsEl.innerHTML = fam.siblings.map(s => renderChip(s, s.birthYear ? `${s.birthYear}` : null)).join(' ');
    } else {
      siblingsEl.innerHTML = `<span class="text-xs text-stone-400 italic">Aka-uka yoki opa-singillar mavjud emas</span>`;
    }

    // Click relative chips to jump to them
    document.querySelectorAll('.relative-chip').forEach(btn => {
      btn.addEventListener('click', () => {
        const targetId = btn.getAttribute('data-member-id');
        const target = this.memberMap.get(targetId);
        if (target) {
          this.openPersonModal(target);
        }
      });
    });
  },

  // 7 Ajdod View
  renderSevenAncestors(memberId) {
    const container = document.getElementById('seven-ancestors-list');
    if (!container) return;

    if (!memberId || !this.memberMap.has(memberId)) {
      container.innerHTML = `<div class="p-8 text-center text-slate-500">Sulola a’zosini tanlang</div>`;
      return;
    }

    const chain = Relatives.getSevenAncestors(memberId, this.memberMap);
    const targetMember = this.memberMap.get(memberId);

    let html = `
      <div class="mb-6 p-4 rounded-xl bg-gradient-to-r from-amber-500/10 via-emerald-500/10 to-transparent border border-amber-200">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-xl bg-amber-100 border border-amber-300 flex items-center justify-center flex-shrink-0 text-amber-800 shadow-xs">
            <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M19 17V5a2 2 0 0 0-2-2H4"/>
              <path d="M8 21h11a2 2 0 0 0 2-2v-2"/>
              <path d="M4 3a2 2 0 0 0-2 2v12a3 3 0 0 0 3 3h12a2 2 0 0 0 2-2V5"/>
              <path d="M7 8h8"/>
              <path d="M7 12h5"/>
            </svg>
          </div>
          <div>
            <h3 class="font-bold text-slate-900 text-lg">
              ${targetMember.firstName} ${targetMember.lastName || ''} ning Yetti Ajdodi
            </h3>
            <p class="text-xs text-slate-600 mt-0.5">
              O‘zbek an’analariga ko‘ra har bir o‘g‘il-qiz o‘zining 7 ota-bobosini bilishi burch hisoblanadi.
            </p>
          </div>
        </div>
      </div>
      <div class="space-y-4 relative">
    `;

    chain.forEach((item, idx) => {
      const m = item.member;
      const isMale = m.gender === 'male';
      const isSelf = idx === 0;

      const birthStr = m.birthYear ? m.birthYear : '?';
      const deathStr = m.isLiving ? 'hayot' : (m.deathYear ? m.deathYear : 'vafot');
      const yearsText = `${birthStr} – ${deathStr}`;

      const avatarHtml = m.photoUrl
        ? `<img src="${m.photoUrl}" alt="${m.firstName}" loading="lazy" decoding="async" class="w-12 h-12 rounded-full object-cover border-2 ${isMale ? 'border-amber-400' : 'border-rose-400'} flex-shrink-0">`
        : `<div class="w-12 h-12 rounded-full ${isMale ? 'bg-amber-100 text-amber-700 border-amber-300' : 'bg-rose-100 text-rose-700 border-rose-300'} border-2 flex items-center justify-center font-bold text-base flex-shrink-0">
             ${m.firstName.charAt(0)}
           </div>`;

      html += `
        <div class="ancestor-step flex items-start gap-4 p-4 rounded-xl border-2 transition ${
          isSelf
            ? 'bg-emerald-50/60 border-emerald-400 shadow-sm'
            : 'bg-white border-slate-200 hover:border-amber-400 hover:shadow-md'
        } cursor-pointer" onclick="App.openPersonModal(App.memberMap.get('${m.id}'))">
          <div class="relative z-10 flex-shrink-0">
            ${avatarHtml}
            <span class="absolute -bottom-1 -right-1 w-5 h-5 rounded-full ${
              isSelf ? 'bg-emerald-600' : 'bg-amber-600'
            } text-white font-bold text-[10px] flex items-center justify-center shadow">
              ${item.step}
            </span>
          </div>
          <div class="flex-1 min-w-0">
            <div class="flex items-center justify-between gap-2 flex-wrap">
              <span class="text-xs font-bold px-2 py-0.5 rounded ${
                isSelf ? 'bg-emerald-200 text-emerald-900' : 'bg-amber-100 text-amber-800'
              }">
                ${item.title}
              </span>
              <span class="text-xs text-slate-500 font-medium">${yearsText}</span>
            </div>
            <h4 class="font-bold text-slate-900 text-base mt-1 truncate">
              ${m.firstName} ${m.lastName || ''} ${m.middleName ? `(${m.middleName})` : ''}
            </h4>
            <div class="text-xs text-slate-600 mt-0.5">${item.desc}</div>
            ${m.profession ? `<div class="text-xs text-amber-700 font-medium mt-1 truncate">🛠️ ${m.profession}</div>` : ''}
          </div>
        </div>
      `;
    });

    // If less than 7 ancestors are known in the database
    if (chain.length < 7) {
      for (let missing = chain.length + 1; missing <= 7; missing++) {
        const meta = Relatives.ANCESTOR_TITLES[missing - 1];
        html += `
          <div class="ancestor-step flex items-center gap-4 p-3 rounded-xl border border-dashed border-slate-300 bg-slate-50/70 text-slate-400 opacity-75">
            <div class="w-10 h-10 rounded-full border border-dashed border-slate-300 flex items-center justify-center text-xs font-bold text-slate-400">
              ${missing}
            </div>
            <div class="flex-1">
              <span class="text-xs font-semibold text-slate-500">${meta.title}</span>
              <div class="text-xs italic text-slate-400">Ma’lumot kiritilmagan (Otasining otasini shajaraga qo‘shing)</div>
            </div>
          </div>
        `;
      }
    }

    html += `</div>`;
    container.innerHTML = html;
  },

  // Directory / All Members View
  populateDirectoryFilters() {
    const genFilter = document.getElementById('directory-gen-filter');
    if (!genFilter) return;

    const currentVal = genFilter.value;
    const generations = [...new Set(this.members.map(m => m.generation || 1))].sort((a,b)=>a-b);

    genFilter.innerHTML = '<option value="">Barcha avlodlar</option>';
    generations.forEach(g => {
      const opt = document.createElement('option');
      opt.value = g;
      opt.textContent = `${g}-avlod`;
      if (String(g) === currentVal) opt.selected = true;
      genFilter.appendChild(opt);
    });
  },

  renderDirectoryList() {
    const container = document.getElementById('directory-list-container');
    const countEl = document.getElementById('directory-count');
    if (!container) return;

    const query = document.getElementById('directory-search')?.value || '';
    const gen = document.getElementById('directory-gen-filter')?.value || '';
    const gender = document.getElementById('directory-gender-filter')?.value || '';
    const status = document.getElementById('directory-status-filter')?.value || '';

    let list = Relatives.search(query, this.members);

    if (gen) {
      list = list.filter(m => String(m.generation) === String(gen));
    }
    if (gender) {
      list = list.filter(m => m.gender === gender);
    }
    if (status) {
      if (status === 'living') list = list.filter(m => m.isLiving);
      if (status === 'deceased') list = list.filter(m => !m.isLiving);
    }

    if (countEl) {
      countEl.textContent = `${list.length} nafar a’zo topildi`;
    }

    if (list.length === 0) {
      container.innerHTML = `
        <div class="col-span-full p-12 text-center text-slate-400">
          <div class="text-4xl mb-2">🔍</div>
          <div class="text-base font-semibold text-slate-600">Mos a’zo topilmadi</div>
          <div class="text-xs mt-1">Filtr parametrlarini o‘zgartirib ko‘ring</div>
        </div>
      `;
      return;
    }

    container.innerHTML = list.map(m => {
      const isMale = m.gender === 'male';
      const birthStr = m.birthYear ? m.birthYear : '?';
      const deathStr = m.isLiving ? 'hayot' : (m.deathYear ? m.deathYear : 'vafot');
      const yearsText = `${birthStr} – ${deathStr}`;

      const avatarHtml = m.photoUrl
        ? `<img src="${m.photoUrl}" alt="${m.firstName}" loading="lazy" decoding="async" class="w-14 h-14 rounded-full object-cover border-2 ${isMale ? 'border-sky-400' : 'border-rose-400'} flex-shrink-0">`
        : `<div class="w-14 h-14 rounded-full ${isMale ? 'bg-sky-100 text-sky-700 border-sky-300' : 'bg-rose-100 text-rose-700 border-rose-300'} border-2 flex items-center justify-center font-bold text-lg flex-shrink-0">
             ${m.firstName.charAt(0)}
           </div>`;

      return `
        <div class="bg-white rounded-xl p-4 border border-slate-200 hover:border-emerald-400 shadow-sm hover:shadow-md transition cursor-pointer flex items-start gap-3.5" onclick="App.openPersonModal(App.memberMap.get('${m.id}'))">
          ${avatarHtml}
          <div class="flex-1 min-w-0">
            <div class="flex items-center justify-between gap-1">
              <span class="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${isMale ? 'bg-sky-50 text-sky-700' : 'bg-rose-50 text-rose-700'}">
                ${m.generation}-avlod
              </span>
              ${m.isLiving ? '<span class="text-[11px] text-emerald-600 font-semibold">● Hayot</span>' : '<span class="text-[11px] text-slate-400 font-medium">🕊️ Marhum</span>'}
            </div>
            <h4 class="font-bold text-slate-900 text-sm mt-1 truncate">
              ${m.firstName} ${m.lastName || ''}
            </h4>
            <div class="text-xs text-slate-500 font-medium">${yearsText}</div>
            ${m.profession ? `<div class="text-xs text-slate-600 mt-1 truncate">🛠️ ${m.profession}</div>` : ''}
            ${m.birthPlace ? `<div class="text-[11px] text-slate-400 mt-0.5 truncate">📍 ${m.birthPlace}</div>` : ''}
          </div>
        </div>
      `;
    }).join('');
  },

  // ================= ESDALIKLAR (MEMORIES & ARCHIVE) VIEW =================

  // Populate Memory filters (Years & Members)
  populateMemoryFilters() {
    const yearFilter = document.getElementById('memory-year-filter');
    const memberFilter = document.getElementById('memory-member-filter');
    if (!yearFilter || !memberFilter) return;

    // Years
    const currentYear = yearFilter.value;
    const years = [...new Set(this.memories.map(m => m.year).filter(Boolean))].sort((a,b)=>a-b);
    yearFilter.innerHTML = '<option value="">Barcha yillar</option>';
    years.forEach(y => {
      const opt = document.createElement('option');
      opt.value = y;
      opt.textContent = `${y}-yil`;
      if (String(y) === currentYear) opt.selected = true;
      yearFilter.appendChild(opt);
    });

    // Tagged Members
    const currentMember = memberFilter.value;
    memberFilter.innerHTML = '<option value="">A’zolar: Barchasi</option>';
    this.members.forEach(m => {
      const opt = document.createElement('option');
      opt.value = m.id;
      opt.textContent = `${m.gender === 'male' ? '👨' : '👩'} ${m.firstName} ${m.lastName || ''}`;
      if (m.id === currentMember) opt.selected = true;
      memberFilter.appendChild(opt);
    });
  },

  // Render Memories Gallery Grid
  renderMemoriesGallery() {
    const container = document.getElementById('memories-grid-container');
    const countEl = document.getElementById('memories-count-label');
    if (!container) return;

    const query = document.getElementById('memory-search-input')?.value.toLowerCase().trim() || '';
    const year = document.getElementById('memory-year-filter')?.value || '';
    const memberId = document.getElementById('memory-member-filter')?.value || '';

    let list = this.memories || [];

    if (query) {
      list = list.filter(m => {
        const title = (m.title || '').toLowerCase();
        const desc = (m.description || '').toLowerCase();
        const place = (m.place || '').toLowerCase();
        return title.includes(query) || desc.includes(query) || place.includes(query);
      });
    }

    if (year) {
      list = list.filter(m => String(m.year) === String(year));
    }

    if (memberId) {
      list = list.filter(m => m.taggedMemberIds && m.taggedMemberIds.includes(memberId));
    }

    if (countEl) {
      countEl.textContent = `${list.length} ta tarixiy fotosurat va xotira mavjud`;
    }

    if (list.length === 0) {
      container.innerHTML = `
        <div class="col-span-full p-12 text-center text-stone-400 bg-white rounded-2xl border border-stone-200">
          <div class="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-200 text-amber-700 mx-auto flex items-center justify-center mb-3">
            <svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
              <rect width="18" height="18" x="3" y="3" rx="3" ry="3"/>
              <circle cx="8.5" cy="8.5" r="1.5"/>
              <path d="m21 15-5-5L5 21"/>
            </svg>
          </div>
          <div class="text-base font-serif font-bold text-stone-700">Hech qanday esdalik topilmadi</div>
          <div class="text-xs text-stone-500 mt-1">Admin panelidan "Surat yuklash" tugmasi orqali yangi fotosurat qo‘shishingiz mumkin</div>
        </div>
      `;
      return;
    }

    container.innerHTML = list.map(m => {
      const yearText = m.date || (m.year ? `${m.year}-yil` : 'Tarixiy davr');
      const taggedMembers = (m.taggedMemberIds || [])
        .map(id => this.memberMap.get(id))
        .filter(Boolean);

      return `
        <div class="bg-white rounded-2xl overflow-hidden border border-stone-200 hover:border-amber-500 shadow-xs hover:shadow-md transition-all duration-300 cursor-pointer flex flex-col group" onclick="App.openMemoryLightbox(App.memories.find(item => item.id === '${m.id}'))">
          <div class="relative h-48 bg-stone-900 overflow-hidden">
            <img src="${m.imageUrl}" alt="${m.title}" loading="lazy" decoding="async" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" onerror="this.src='https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=600&q=80'">
            <div class="absolute inset-0 bg-gradient-to-t from-stone-950/70 via-transparent to-transparent opacity-80 group-hover:opacity-60 transition"></div>
            <div class="absolute top-2.5 left-2.5 px-2 py-0.5 rounded-full text-[9px] font-display font-extrabold uppercase tracking-widest bg-amber-100 text-amber-900 border border-amber-300 shadow-xs">
              ${yearText}
            </div>
            ${m.place ? `<div class="absolute bottom-2 left-2.5 text-[10.5px] font-medium text-amber-100 flex items-center gap-1 drop-shadow-md"><span>📍</span> <span>${m.place}</span></div>` : ''}
          </div>

          <div class="p-4 flex-1 flex flex-col justify-between">
            <div>
              <h3 class="font-serif font-bold text-stone-900 text-sm leading-snug group-hover:text-amber-800 transition line-clamp-2">
                ${m.title}
              </h3>
              ${m.description ? `<p class="text-xs text-stone-600 mt-1.5 line-clamp-2 leading-relaxed font-sans">${m.description}</p>` : ''}
            </div>

            ${taggedMembers.length > 0 ? `
              <div class="mt-3 pt-2.5 border-t border-stone-100 flex items-center justify-between text-[11px] text-stone-500">
                <span class="font-medium text-amber-900/70">Suratda:</span>
                <div class="flex items-center -space-x-1.5 overflow-hidden" title="${taggedMembers.map(t=>t.firstName).join(', ')}">
                  ${taggedMembers.slice(0, 4).map(t => `
                    <div class="w-6 h-6 rounded-full bg-stone-100 border border-white flex items-center justify-center text-[10px] font-bold text-stone-700 shadow-xs">
                      ${t.firstName.charAt(0)}
                    </div>
                  `).join('')}
                  ${taggedMembers.length > 4 ? `<div class="w-6 h-6 rounded-full bg-amber-100 border border-white flex items-center justify-center text-[9px] font-bold text-amber-800">+${taggedMembers.length - 4}</div>` : ''}
                </div>
              </div>
            ` : ''}
          </div>
        </div>
      `;
    }).join('');
  },

  // Open Lightbox for Memory
  openMemoryLightbox(memory) {
    if (!memory) return;
    this.currentViewingMemory = memory;

    const modal = document.getElementById('memory-lightbox-modal');
    if (!modal) return;

    document.getElementById('lightbox-img').src = memory.imageUrl;
    document.getElementById('lightbox-title').textContent = memory.title;
    document.getElementById('lightbox-year-badge').textContent = memory.date || (memory.year ? `${memory.year}-yil` : 'Tarixiy davr');
    document.getElementById('lightbox-date').textContent = memory.date ? `🗓️ ${memory.date}` : '';
    document.getElementById('lightbox-place').textContent = memory.place ? `📍 ${memory.place}` : '';
    document.getElementById('lightbox-desc').textContent = memory.description || 'Xotira tavsifi kiritilmagan.';

    // Tagged members
    const taggedSection = document.getElementById('lightbox-tagged-section');
    const taggedContainer = document.getElementById('lightbox-tagged-container');
    const tagged = (memory.taggedMemberIds || []).map(id => this.memberMap.get(id)).filter(Boolean);

    if (tagged.length > 0) {
      taggedSection.classList.remove('hidden');
      taggedContainer.innerHTML = tagged.map(m => {
        const isMale = m.gender === 'male';
        const avatar = m.photoUrl
          ? `<img src="${m.photoUrl}" alt="${m.firstName}" class="w-5 h-5 rounded-full object-cover border ${isMale ? 'border-sky-400' : 'border-rose-400'} shadow-2xs flex-shrink-0">`
          : `<span class="w-5 h-5 rounded-full ${isMale ? 'bg-sky-100 text-sky-800 border-sky-300' : 'bg-rose-100 text-rose-800 border-rose-300'} border flex items-center justify-center font-serif font-bold text-[10px] flex-shrink-0">${m.firstName.charAt(0)}</span>`;
        return `
          <button class="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-serif font-semibold bg-[#fffdf8] hover:bg-[#faf5eb] text-stone-800 border border-[#ded5c5] hover:border-amber-600 shadow-xs transition cursor-pointer" onclick="document.getElementById('memory-lightbox-modal').classList.add('hidden'); App.openPersonModal(App.memberMap.get('${m.id}'))">
            ${avatar}
            <span>${m.firstName} ${m.lastName || ''}</span>
          </button>
        `;
      }).join('');
    } else {
      taggedSection.classList.add('hidden');
    }

    modal.classList.remove('hidden');
  },

  // Render tagged memories in Person Profile
  renderPersonMemories(member) {
    const container = document.getElementById('modal-person-memories-container');
    const grid = document.getElementById('modal-person-memories-grid');
    if (!container || !grid) return;

    const tagged = (this.memories || []).filter(memo => memo.taggedMemberIds && memo.taggedMemberIds.includes(member.id));

    if (tagged.length > 0) {
      container.classList.remove('hidden');
      grid.innerHTML = tagged.map(memo => `
        <div class="group relative rounded-xl overflow-hidden border border-stone-200 shadow-xs cursor-pointer bg-stone-900 h-20" onclick="App.openMemoryLightbox(App.memories.find(m => m.id === '${memo.id}'))" title="${memo.title}">
          <img src="${memo.imageUrl}" alt="${memo.title}" loading="lazy" decoding="async" class="w-full h-full object-cover group-hover:scale-105 transition duration-300 opacity-90">
          <div class="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-transparent to-transparent flex items-end p-1.5">
            <span class="text-[10px] text-amber-100 font-medium truncate">${memo.title}</span>
          </div>
        </div>
      `).join('');
    } else {
      container.classList.add('hidden');
      grid.innerHTML = '';
    }
  },

  // Stats View
  async renderStatsView() {
    try {
      const stats = await API.fetchStats();

      document.getElementById('stat-total-members').textContent = stats.total;
      document.getElementById('stat-total-males').textContent = stats.males;
      document.getElementById('stat-total-females').textContent = stats.females;
      document.getElementById('stat-total-living').textContent = stats.living;
      document.getElementById('stat-total-deceased').textContent = stats.deceased;
      document.getElementById('stat-total-generations').textContent = stats.generationsCount;

      // Male/Female percentage bar
      const malePct = stats.total > 0 ? Math.round((stats.males / stats.total) * 100) : 50;
      const femalePct = 100 - malePct;
      const maleBar = document.getElementById('stat-bar-male');
      const femaleBar = document.getElementById('stat-bar-female');
      if (maleBar && femaleBar) {
        maleBar.style.width = `${malePct}%`;
        femaleBar.style.width = `${femalePct}%`;
      }
      document.getElementById('stat-pct-male').textContent = `${malePct}% erkaklar`;
      document.getElementById('stat-pct-female').textContent = `${femalePct}% ayollar`;

      // Generations Breakdown
      const genBreakdownContainer = document.getElementById('stat-generations-breakdown');
      if (genBreakdownContainer) {
        const countsByGen = {};
        this.members.forEach(m => {
          const g = m.generation || 1;
          countsByGen[g] = (countsByGen[g] || 0) + 1;
        });

        genBreakdownContainer.innerHTML = Object.entries(countsByGen).map(([g, count]) => {
          const pct = Math.round((count / (stats.total || 1)) * 100);
          return `
            <div class="space-y-1">
              <div class="flex items-center justify-between text-xs font-semibold">
                <span class="text-slate-700">${g}-avlod</span>
                <span class="text-slate-500">${count} nafar (${pct}%)</span>
              </div>
              <div class="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                <div class="bg-emerald-600 h-2.5 rounded-full transition-all duration-500" style="width: ${pct}%"></div>
              </div>
            </div>
          `;
        }).join('');
      }

      // Top Professions
      const profsContainer = document.getElementById('stat-professions-breakdown');
      if (profsContainer) {
        const entries = Object.entries(stats.topProfessions || {}).sort((a,b)=>b[1]-a[1]).slice(0, 8);
        if (entries.length > 0) {
          profsContainer.innerHTML = entries.map(([prof, count]) => `
            <div class="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg border border-slate-100 text-xs">
              <span class="font-medium text-slate-800 truncate">${prof}</span>
              <span class="font-bold text-emerald-700 px-2 py-0.5 bg-emerald-50 rounded-full">${count}</span>
            </div>
          `).join('');
        } else {
          profsContainer.innerHTML = `<div class="text-xs text-slate-400 italic">Kasblar kiritilmagan</div>`;
        }
      }
    } catch (e) {
      console.error('Stats error:', e);
    }
  },

  handleGlobalSearch(query) {
    if (!query || !query.trim()) return;
    const results = Relatives.search(query, this.members);
    const resultsDropdown = document.getElementById('search-results-dropdown');
    if (!resultsDropdown) return;

    if (results.length === 0) {
      resultsDropdown.innerHTML = `<div class="p-3 text-xs text-slate-400 text-center">Topilmadi</div>`;
      resultsDropdown.classList.remove('hidden');
      return;
    }

    resultsDropdown.innerHTML = results.slice(0, 6).map(m => {
      const isMale = m.gender === 'male';
      const avatar = m.photoUrl
        ? `<img src="${m.photoUrl}" alt="${m.firstName}" class="w-7 h-7 rounded-full object-cover border ${isMale ? 'border-sky-400' : 'border-rose-400'} shadow-2xs flex-shrink-0">`
        : `<div class="w-7 h-7 rounded-full ${isMale ? 'bg-sky-100 text-sky-800 border-sky-200' : 'bg-rose-100 text-rose-800 border-rose-200'} border flex items-center justify-center font-serif font-bold text-xs flex-shrink-0 shadow-2xs">${m.firstName.charAt(0)}</div>`;
      return `
        <div class="p-2.5 hover:bg-[#faf6ee] cursor-pointer flex items-center gap-2.5 border-b border-[#f0eae0] last:border-b-0 text-xs transition" onclick="App.openPersonModal(App.memberMap.get('${m.id}')); document.getElementById('search-results-dropdown').classList.add('hidden');">
          ${avatar}
          <div class="flex-1 min-w-0">
            <div class="font-serif font-bold text-stone-900 truncate">${m.firstName} ${m.lastName || ''}</div>
            <div class="text-[10.5px] text-stone-500 font-sans">${m.generation}-avlod (${m.birthYear || '?'})</div>
          </div>
          <svg class="w-3.5 h-3.5 text-stone-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
        </div>
      `;
    }).join('');

    resultsDropdown.classList.remove('hidden');
  },

  showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    const colors = {
      success: 'bg-emerald-600 text-white',
      error: 'bg-rose-600 text-white',
      info: 'bg-slate-800 text-white'
    };
    const icons = {
      success: '✅',
      error: '⚠️',
      info: 'ℹ️'
    };

    toast.className = `flex items-center gap-2 px-4 py-3 rounded-xl shadow-lg text-xs font-semibold transition-all transform duration-300 translate-y-2 opacity-0 ${colors[type] || colors.info}`;
    toast.innerHTML = `<span>${icons[type] || 'ℹ️'}</span> <span>${message}</span>`;

    container.appendChild(toast);

    setTimeout(() => {
      toast.classList.remove('translate-y-2', 'opacity-0');
    }, 20);

    setTimeout(() => {
      toast.classList.add('opacity-0', 'translate-y-2');
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  }
};

window.App = App;

// Close search dropdown on click outside
window.addEventListener('click', (e) => {
  const searchInput = document.getElementById('global-search-input');
  const searchDropdown = document.getElementById('search-results-dropdown');
  if (searchInput && searchDropdown && !searchInput.contains(e.target) && !searchDropdown.contains(e.target)) {
    searchDropdown.classList.add('hidden');
  }
});

// Boot app on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  App.init();
});
