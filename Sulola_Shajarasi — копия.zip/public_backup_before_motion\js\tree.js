/**
 * Shajara Interaktiv Daraxt Vizualizatsiyasi Dvigateli
 * - Juftlik (Er-xotin) to'liq kartochkalari
 * - Aniq "Hayot" va "Marhum" nishonlari
 * - Tepadan boshlanuvchi markazlashgan qulay kompozitsiya
 * - To'q, aniq va bir-biriga xalaqit bermaydigan shajara chiziqlari (Orthogonal bus routing)
 */

class ShajaraTree {
  constructor(containerId, options = {}) {
    this.container = document.getElementById(containerId);
    if (!this.container) throw new Error(`Container #${containerId} topilmadi`);

    this.options = {
      singleCardWidth: 230,
      coupleCardWidth: 430,
      cardHeight: 125,
      horizontalGap: 45,
      verticalGap: 95,
      onNodeClick: options.onNodeClick || (() => {}),
      ...options
    };

    this.members = [];
    this.memberMap = new Map();
    this.rootId = null;
    this.collapsedIds = new Set();
    this.selectedNodeId = null;
    this.highlightedAncestors = new Set();

    // Pan & Zoom state
    this.scale = 1;
    this.translateX = 0;
    this.translateY = 0;
    this.isDragging = false;
    this.startX = 0;
    this.startY = 0;
    this.animationFrameId = null;

    this.initDOM();
    this.bindEvents();
  }

  initDOM() {
    this.container.innerHTML = '';
    this.container.classList.add('tree-container');

    // Create SVG
    this.svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    this.svg.classList.add('tree-svg');

    // Defs for gradients & filters
    const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
    defs.innerHTML = `
      <linearGradient id="linkGradGold" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="#fbbf24"/>
        <stop offset="50%" stop-color="#d97706"/>
        <stop offset="100%" stop-color="#b45309"/>
      </linearGradient>

      <filter id="royalGlow" x="-20%" y="-20%" width="140%" height="140%">
        <feGaussianBlur stdDeviation="4" result="blur" />
        <feComposite in="SourceGraphic" in2="blur" operator="over" />
      </filter>
    `;
    this.svg.appendChild(defs);

    // Viewport group
    this.viewport = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    this.viewport.setAttribute('class', 'tree-viewport');

    // Effects layer
    this.effectsGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    this.effectsGroup.setAttribute('class', 'tree-effects');

    // Links layer
    this.linksGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    this.linksGroup.setAttribute('class', 'tree-links');

    // Nodes layer
    this.nodesGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    this.nodesGroup.setAttribute('class', 'tree-nodes');

    this.viewport.appendChild(this.effectsGroup);
    this.viewport.appendChild(this.linksGroup);
    this.viewport.appendChild(this.nodesGroup);
    this.svg.appendChild(this.viewport);
    this.container.appendChild(this.svg);
  }

  bindEvents() {
    // Mouse Pan
    this.container.addEventListener('mousedown', (e) => {
      if (e.target.closest('.node-interactive-btn') || e.target.closest('.member-sub-card') || e.target.closest('.node-card')) {
        return;
      }
      this.cancelAnimation();
      this.isDragging = true;
      this.startX = e.clientX - this.translateX;
      this.startY = e.clientY - this.translateY;
      this.container.classList.add('dragging');
    });

    window.addEventListener('mousemove', (e) => {
      if (!this.isDragging) return;
      this.translateX = e.clientX - this.startX;
      this.translateY = e.clientY - this.startY;
      this.applyTransform();
    });

    window.addEventListener('mouseup', () => {
      if (this.isDragging) {
        this.isDragging = false;
        this.container.classList.remove('dragging');
      }
    });

    // Mouse Zoom
    this.container.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.cancelAnimation();
      const rect = this.container.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;

      const zoomFactor = e.deltaY < 0 ? 1.12 : 0.88;
      const newScale = Math.min(Math.max(this.scale * zoomFactor, 0.2), 2.5);

      if (newScale !== this.scale) {
        this.translateX = mouseX - (mouseX - this.translateX) * (newScale / this.scale);
        this.translateY = mouseY - (mouseY - this.translateY) * (newScale / this.scale);
        this.scale = newScale;
        this.applyTransform();
      }
    }, { passive: false });

    // Touch Support
    let initialTouchDist = 0;
    this.container.addEventListener('touchstart', (e) => {
      this.cancelAnimation();
      if (e.touches.length === 1) {
        this.isDragging = true;
        this.startX = e.touches[0].clientX - this.translateX;
        this.startY = e.touches[0].clientY - this.translateY;
      } else if (e.touches.length === 2) {
        this.isDragging = false;
        initialTouchDist = Math.hypot(
          e.touches[0].clientX - e.touches[1].clientX,
          e.touches[0].clientY - e.touches[1].clientY
        );
      }
    }, { passive: true });

    this.container.addEventListener('touchmove', (e) => {
      if (e.touches.length === 1 && this.isDragging) {
        this.translateX = e.touches[0].clientX - this.startX;
        this.translateY = e.touches[0].clientY - this.startY;
        this.applyTransform();
      } else if (e.touches.length === 2) {
        const currentDist = Math.hypot(
          e.touches[0].clientX - e.touches[1].clientX,
          e.touches[0].clientY - e.touches[1].clientY
        );
        if (initialTouchDist > 0) {
          const factor = currentDist / initialTouchDist;
          this.scale = Math.min(Math.max(this.scale * factor, 0.2), 2.5);
          initialTouchDist = currentDist;
          this.applyTransform();
        }
      }
    }, { passive: true });

    this.container.addEventListener('touchend', () => {
      this.isDragging = false;
    });

    window.addEventListener('resize', () => {
      this.updateDimensions();
    });
  }

  cancelAnimation() {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
  }

  animateToTransform(targetX, targetY, targetScale, duration = 400) {
    this.cancelAnimation();

    const startX = this.translateX;
    const startY = this.translateY;
    const startScale = this.scale;
    const startTime = performance.now();

    const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);

    const step = (now) => {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = easeOutCubic(progress);

      this.translateX = startX + (targetX - startX) * eased;
      this.translateY = startY + (targetY - startY) * eased;
      this.scale = startScale + (targetScale - startScale) * eased;
      this.applyTransform();

      if (progress < 1) {
        this.animationFrameId = requestAnimationFrame(step);
      } else {
        this.animationFrameId = null;
      }
    };

    this.animationFrameId = requestAnimationFrame(step);
  }

  applyTransform() {
    this.viewport.setAttribute(
      'transform',
      `translate(${this.translateX}, ${this.translateY}) scale(${this.scale})`
    );
  }

  updateDimensions() {
    const rect = this.container.getBoundingClientRect();
    this.svg.setAttribute('width', rect.width);
    this.svg.setAttribute('height', rect.height);
  }

  setData(members, preferredRootId = null) {
    this.members = members || [];
    this.memberMap.clear();
    this.members.forEach(m => this.memberMap.set(m.id, m));

    if (preferredRootId && this.memberMap.has(preferredRootId)) {
      this.rootId = preferredRootId;
    } else {
      const roots = this.members.filter(m => !m.fatherId && !m.motherId);
      const maleRoot = roots.find(m => m.gender === 'male');
      this.rootId = maleRoot ? maleRoot.id : (roots[0]?.id || this.members[0]?.id || null);
    }

    this.render();
    setTimeout(() => this.fitToScreen(false), 90);
  }

  setRoot(rootId) {
    if (this.memberMap.has(rootId)) {
      this.rootId = rootId;
      this.render();
      setTimeout(() => this.fitToScreen(true), 60);
    }
  }

  getChildren(parentId) {
    return this.members.filter(m => m.fatherId === parentId || m.motherId === parentId)
      .sort((a, b) => (a.birthYear || 9999) - (b.birthYear || 9999));
  }

  getPrimarySpouse(memberId) {
    const m = this.memberMap.get(memberId);
    if (!m) return null;
    const spouseId = m.spouseIds?.[0];
    if (spouseId && this.memberMap.has(spouseId)) {
      return this.memberMap.get(spouseId);
    }
    // Also check mutual
    const mutual = this.members.find(other => other.spouseIds && other.spouseIds.includes(memberId));
    return mutual || null;
  }

  getNodeWidth(member) {
    const spouse = this.getPrimarySpouse(member.id);
    return spouse ? this.options.coupleCardWidth : this.options.singleCardWidth;
  }

  // Calculate hierarchical layout coordinates
  computeLayout(rootId) {
    const { cardHeight, horizontalGap, verticalGap } = this.options;
    const layoutNodes = [];
    const layoutLinks = [];

    if (!rootId || !this.memberMap.has(rootId)) return { nodes: [], links: [] };

    const visited = new Set();

    const measureSubtree = (nodeId) => {
      if (visited.has(nodeId)) return this.getNodeWidth(this.memberMap.get(nodeId) || { id: nodeId });
      const member = this.memberMap.get(nodeId);
      if (!member) return this.options.singleCardWidth;

      const myWidth = this.getNodeWidth(member);
      const children = this.getChildren(nodeId);
      const isCollapsed = this.collapsedIds.has(nodeId);

      if (children.length === 0 || isCollapsed) {
        return myWidth;
      }

      let totalChildrenWidth = 0;
      children.forEach((child, idx) => {
        const w = measureSubtree(child.id);
        totalChildrenWidth += w + (idx < children.length - 1 ? horizontalGap : 0);
      });

      return Math.max(myWidth, totalChildrenWidth);
    };

    visited.clear();

    const positionSubtree = (nodeId, startX, currentY, depth = 1) => {
      const member = this.memberMap.get(nodeId);
      if (!member) return;

      const spouse = this.getPrimarySpouse(nodeId);
      const isCouple = !!spouse;
      const nodeWidth = isCouple ? this.options.coupleCardWidth : this.options.singleCardWidth;

      const children = this.getChildren(nodeId);
      const isCollapsed = this.collapsedIds.has(nodeId);
      const subtreeWidth = measureSubtree(nodeId);

      const nodeX = startX + (subtreeWidth - nodeWidth) / 2;
      const nodeY = currentY;

      layoutNodes.push({
        id: member.id,
        member,
        spouse,
        isCouple,
        x: nodeX,
        y: nodeY,
        width: nodeWidth,
        height: cardHeight,
        depth,
        childrenCount: children.length,
        isCollapsed
      });

      if (!isCollapsed && children.length > 0) {
        let childX = startX;
        const nextY = currentY + cardHeight + verticalGap;
        const parentCenterBottomX = nodeX + nodeWidth / 2;
        const parentCenterBottomY = nodeY + cardHeight;

        const childTargets = [];

        children.forEach(child => {
          const childSubtreeWidth = measureSubtree(child.id);
          const childNodeWidth = this.getNodeWidth(child);
          const childActualX = childX + (childSubtreeWidth - childNodeWidth) / 2;

          childTargets.push({
            childId: child.id,
            x: childActualX + childNodeWidth / 2,
            y: nextY
          });

          positionSubtree(child.id, childX, nextY, depth + 1);
          childX += childSubtreeWidth + horizontalGap;
        });

        // Add Genealogical Bus Connector
        layoutLinks.push({
          parentId: member.id,
          px: parentCenterBottomX,
          py: parentCenterBottomY,
          nextY: nextY,
          children: childTargets
        });
      }
    };

    // Start near the top (y = 40)
    positionSubtree(rootId, 100, 40, 1);

    return { nodes: layoutNodes, links: layoutLinks };
  }

  // Draw expanding gold ripple on click
  triggerClickRipple(cx, cy) {
    const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    circle.setAttribute('cx', cx);
    circle.setAttribute('cy', cy);
    circle.setAttribute('r', '15');
    circle.setAttribute('fill', 'none');
    circle.setAttribute('stroke', '#d97706');
    circle.setAttribute('stroke-width', '4');
    circle.setAttribute('opacity', '0.9');
    circle.style.pointerEvents = 'none';
    circle.style.transition = 'all 0.6s cubic-bezier(0.1, 0.8, 0.2, 1)';

    this.effectsGroup.appendChild(circle);

    requestAnimationFrame(() => {
      circle.setAttribute('r', '110');
      circle.setAttribute('stroke-width', '1');
      circle.setAttribute('opacity', '0');
    });

    setTimeout(() => circle.remove(), 650);
  }

  render() {
    this.updateDimensions();
    this.linksGroup.innerHTML = '';
    this.nodesGroup.innerHTML = '';
    this.effectsGroup.innerHTML = '';

    if (!this.rootId) {
      this.showEmptyState();
      return;
    }

    const { nodes, links } = this.computeLayout(this.rootId);
    this.renderedNodes = nodes;
    this.renderedLinks = links;

    // 1. Draw Clean Genealogical Bus Connections
    // (Parent vertical drop -> horizontal bus bar -> child vertical drops)
    links.forEach(bus => {
      const { parentId, px, py, nextY, children } = bus;
      const midY = py + (nextY - py) / 2;

      const isParentHighlighted = this.highlightedAncestors.has(parentId);

      // Parent drop down to midY
      const parentDrop = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      parentDrop.setAttribute('d', `M ${px} ${py} L ${px} ${midY}`);
      parentDrop.setAttribute('class', `tree-link ${isParentHighlighted ? 'highlighted' : ''}`);
      this.linksGroup.appendChild(parentDrop);

      if (children.length === 1) {
        // Single child: simple connection from (px, midY) to (child.x, midY) to (child.x, nextY)
        const ch = children[0];
        const isChildHighlighted = this.highlightedAncestors.has(ch.childId);
        const singlePath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        singlePath.setAttribute('d', `M ${px} ${midY} L ${ch.x} ${midY} L ${ch.x} ${ch.y}`);
        singlePath.setAttribute('class', `tree-link ${isParentHighlighted && isChildHighlighted ? 'highlighted' : ''}`);
        this.linksGroup.appendChild(singlePath);
      } else {
        // Multiple children: Horizontal bus bar
        const minChildX = Math.min(...children.map(c => c.x));
        const maxChildX = Math.max(...children.map(c => c.x));

        const busMinX = Math.min(px, minChildX);
        const busMaxX = Math.max(px, maxChildX);

        const busBar = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        busBar.setAttribute('d', `M ${busMinX} ${midY} L ${busMaxX} ${midY}`);
        busBar.setAttribute('class', `tree-link ${isParentHighlighted ? 'highlighted' : ''}`);
        this.linksGroup.appendChild(busBar);

        // Individual vertical drop to each child
        children.forEach(ch => {
          const isChildHighlighted = this.highlightedAncestors.has(ch.childId);
          const drop = document.createElementNS('http://www.w3.org/2000/svg', 'path');
          drop.setAttribute('d', `M ${ch.x} ${midY} L ${ch.x} ${ch.y}`);
          drop.setAttribute('class', `tree-link ${isParentHighlighted && isChildHighlighted ? 'highlighted' : ''}`);
          this.linksGroup.appendChild(drop);
        });
      }
    });

    // 2. Helper to generate single person HTML block
    const renderPersonBlock = (m, roleLabel = null, isRightSide = false) => {
      const isMale = m.gender === 'male';
      const birthStr = m.birthYear ? m.birthYear : '?';
      const deathStr = m.isLiving ? 'hayot' : (m.deathYear ? m.deathYear : 'vafot');
      const yearsText = `${birthStr} – ${deathStr}`;

      const avatarHtml = m.photoUrl
        ? `<img src="${m.photoUrl}" alt="${m.firstName}" loading="lazy" decoding="async" class="w-12 h-12 rounded-full object-cover border-2 ${isMale ? 'border-sky-500' : 'border-rose-400'} shadow-sm flex-shrink-0 bg-stone-100" onerror="this.outerHTML='<div class=\\'w-12 h-12 rounded-full ${isMale ? 'bg-sky-100 text-sky-800' : 'bg-rose-100 text-rose-800'} flex items-center justify-center font-serif font-bold text-lg border-2 flex-shrink-0\\'>${m.firstName.charAt(0)}</div>'">`
        : `<div class="w-12 h-12 rounded-full ${isMale ? 'bg-sky-100 text-sky-800 border-sky-300' : 'bg-rose-100 text-rose-800 border-rose-300'} border-2 flex items-center justify-center font-serif font-bold text-lg flex-shrink-0 shadow-xs">
             ${m.firstName.charAt(0)}
           </div>`;

      // Status Badge (Crisp and unambiguous)
      const statusBadge = m.isLiving
        ? `<span class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9.5px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300" title="Hozirda hayot">🟢 Hayot</span>`
        : `<span class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9.5px] font-bold bg-stone-100 text-stone-600 border border-stone-200" title="Marhum">🕊️ Marhum</span>`;

      return `
        <div class="member-sub-card couple-half flex items-center gap-2.5 p-2 rounded-xl cursor-pointer" data-person-id="${m.id}" title="${m.firstName} ${m.lastName || ''} profilini ochish">
          ${avatarHtml}
          <div class="flex-1 min-w-0">
            <div class="flex items-center gap-1.5 flex-wrap">
              ${roleLabel ? `<span class="text-[9px] font-display uppercase tracking-wider font-extrabold px-1.5 py-0.2 rounded ${isMale ? 'bg-sky-50 text-sky-800 border border-sky-200' : 'bg-rose-50 text-rose-800 border border-rose-200'}">${roleLabel}</span>` : ''}
              ${statusBadge}
            </div>
            <h4 class="font-serif font-bold text-stone-900 text-[13.5px] truncate leading-snug mt-0.5" title="${m.firstName} ${m.lastName || ''}">
              ${m.firstName} ${m.lastName || ''}
            </h4>
            <div class="text-[11px] font-serif italic text-stone-600 truncate">${yearsText}</div>
          </div>
        </div>
      `;
    };

    // 3. Draw Nodes (Single or Couple)
    nodes.forEach(item => {
      const { member, spouse, isCouple, x, y, width, height, childrenCount, isCollapsed } = item;
      const isRoot = member.id === this.rootId;
      const isSelected = this.selectedNodeId === member.id || (spouse && this.selectedNodeId === spouse.id);
      const isHighlightedAncestor = this.highlightedAncestors.has(member.id) || (spouse && this.highlightedAncestors.has(spouse.id));

      const group = document.createElementNS('http://www.w3.org/2000/svg', 'g');
      group.setAttribute('transform', `translate(${x}, ${y})`);
      group.setAttribute('class', `tree-node ${isSelected ? 'selected' : ''} ${isHighlightedAncestor ? 'highlighted-ancestor' : ''}`);
      group.setAttribute('data-id', member.id);

      const fo = document.createElementNS('http://www.w3.org/2000/svg', 'foreignObject');
      fo.setAttribute('width', width);
      fo.setAttribute('height', height + 24);
      fo.style.overflow = 'visible';

      const card = document.createElement('div');
      card.className = `node-card ${isCouple ? 'card-couple' : (member.gender === 'male' ? 'card-single-male' : 'card-single-female')} ${isRoot ? 'card-root-glow' : ''}`;

      if (isCouple) {
        // Couple Card: Two full equal columns (Husband & Wife) with prominent names and years
        card.innerHTML = `
          <div class="card-corner-tl"></div>
          <div class="card-corner-br"></div>

          <!-- Top Dynasty Generation Badge -->
          <div class="absolute -top-2.5 left-4 px-2 py-0.5 rounded-full text-[9px] font-display uppercase tracking-widest font-extrabold bg-amber-100 text-amber-900 border border-amber-300 shadow-xs z-10">
            ${isRoot ? '👑 Sulola Asoschilari' : `${member.generation}-avlod oilasi`}
          </div>

          <div class="grid grid-cols-2 gap-1 items-center pt-1">
            <!-- Left: Husband/Primary -->
            ${renderPersonBlock(member, member.gender === 'male' ? 'Erkak' : 'Ayol')}

            <!-- Center Wedding Link Ornament -->
            <div class="relative flex items-center">
              <div class="absolute left-0 -ml-2.5 w-5 h-5 rounded-full bg-white border border-amber-300 text-amber-600 flex items-center justify-center text-xs shadow-xs z-10" title="Qonuniy turmush qurgan">
                💍
              </div>
              <!-- Right: Spouse -->
              ${renderPersonBlock(spouse, spouse.gender === 'female' ? 'Ayol' : 'Erkak', true)}
            </div>
          </div>
        `;
      } else {
        // Single Person Card
        card.innerHTML = `
          <div class="card-corner-tl"></div>
          <div class="card-corner-br"></div>

          <div class="p-1">
            <div class="flex items-center justify-between mb-0.5">
              <span class="text-[9px] font-display uppercase tracking-widest font-extrabold px-1.5 py-0.2 rounded ${
                member.gender === 'male' ? 'bg-sky-50 text-sky-800 border border-sky-200' : 'bg-rose-50 text-rose-800 border border-rose-200'
              }">
                ${member.generation}-avlod
              </span>
            </div>
            ${renderPersonBlock(member, null)}
          </div>
        `;
      }

      // Add Collapse/Expand Button if children exist
      if (childrenCount > 0) {
        const toggleBtn = document.createElement('div');
        toggleBtn.className = `node-interactive-btn absolute -bottom-3 left-1/2 -translate-x-1/2 px-2.5 py-0.5 rounded-full text-[10.5px] font-bold shadow-md cursor-pointer border transition-all duration-200 flex items-center gap-1 z-20 ${
          isCollapsed
            ? 'bg-amber-600 text-white border-amber-700 hover:bg-amber-700 hover:scale-105'
            : 'bg-white text-stone-700 border-stone-300 hover:bg-stone-50 hover:text-amber-700 hover:scale-105'
        }`;
        toggleBtn.innerHTML = isCollapsed
          ? `<span>+ ${childrenCount} farzand</span>`
          : `<span>— yopish</span>`;

        toggleBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          this.toggleCollapse(member.id);
        });

        card.appendChild(toggleBtn);
      }

      // Handle clicking on specific person inside the card
      card.querySelectorAll('.member-sub-card').forEach(sub => {
        sub.addEventListener('click', (e) => {
          e.stopPropagation();
          const targetId = sub.getAttribute('data-person-id');
          const targetMember = this.memberMap.get(targetId);
          if (targetMember) {
            this.triggerClickRipple(x + width / 2, y + height / 2);
            this.selectNode(targetMember.id);
            this.options.onNodeClick(targetMember);
          }
        });
      });

      // Clicking general card area
      card.addEventListener('click', () => {
        this.triggerClickRipple(x + width / 2, y + height / 2);
        this.selectNode(member.id);
        this.options.onNodeClick(member);
      });

      fo.appendChild(card);
      group.appendChild(fo);
      this.nodesGroup.appendChild(group);
    });
  }

  showEmptyState() {
    const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    text.setAttribute('x', '50%');
    text.setAttribute('y', '50%');
    text.setAttribute('text-anchor', 'middle');
    text.setAttribute('fill', '#8c7e68');
    text.setAttribute('font-family', 'Cinzel, Georgia, serif');
    text.setAttribute('font-size', '18');
    text.textContent = "Sulola daraxtida a'zolar mavjud emas. Admin panelidan a'zo qo'shing.";
    this.viewport.appendChild(text);
  }

  toggleCollapse(nodeId) {
    if (this.collapsedIds.has(nodeId)) {
      this.collapsedIds.delete(nodeId);
    } else {
      this.collapsedIds.add(nodeId);
    }
    this.render();
  }

  selectNode(nodeId) {
    this.selectedNodeId = nodeId;
    const allNodeEls = this.nodesGroup.querySelectorAll('.tree-node');
    allNodeEls.forEach(el => {
      const dataId = el.getAttribute('data-id');
      const renderedNode = this.renderedNodes?.find(n => n.id === dataId);
      if (dataId === nodeId || renderedNode?.spouse?.id === nodeId) {
        el.classList.add('selected');
      } else {
        el.classList.remove('selected');
      }
    });
  }

  highlightLineage(memberId) {
    this.highlightedAncestors.clear();
    let current = this.memberMap.get(memberId);

    while (current) {
      this.highlightedAncestors.add(current.id);
      if (current.fatherId && this.memberMap.has(current.fatherId)) {
        current = this.memberMap.get(current.fatherId);
      } else if (current.motherId && this.memberMap.has(current.motherId)) {
        current = this.memberMap.get(current.motherId);
      } else {
        break;
      }
    }

    this.render();
  }

  clearHighlight() {
    this.highlightedAncestors.clear();
    this.render();
  }

  focusOnMember(memberId, smooth = true) {
    if (!this.renderedNodes) return;
    const target = this.renderedNodes.find(n => n.id === memberId || n.spouse?.id === memberId);
    if (!target) return;

    this.selectNode(memberId);

    const rect = this.container.getBoundingClientRect();
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const targetScale = Math.max(Math.min(this.scale, 1.1), 0.9);
    const targetX = centerX - (target.x + target.width / 2) * targetScale;
    const targetY = centerY - (target.y + target.height / 2) * targetScale;

    if (smooth) {
      this.animateToTransform(targetX, targetY, targetScale, 450);
    } else {
      this.scale = targetScale;
      this.translateX = targetX;
      this.translateY = targetY;
      this.applyTransform();
    }
  }

  zoomIn() {
    const newScale = Math.min(this.scale * 1.25, 2.5);
    const rect = this.container.getBoundingClientRect();
    const cx = rect.width / 2;
    const cy = rect.height / 2;
    const targetX = cx - (cx - this.translateX) * (newScale / this.scale);
    const targetY = cy - (cy - this.translateY) * (newScale / this.scale);
    this.animateToTransform(targetX, targetY, newScale, 200);
  }

  zoomOut() {
    const newScale = Math.max(this.scale * 0.8, 0.2);
    const rect = this.container.getBoundingClientRect();
    const cx = rect.width / 2;
    const cy = rect.height / 2;
    const targetX = cx - (cx - this.translateX) * (newScale / this.scale);
    const targetY = cy - (cy - this.translateY) * (newScale / this.scale);
    this.animateToTransform(targetX, targetY, newScale, 200);
  }

  resetZoom() {
    this.fitToScreen(true);
  }

  // Automatic Top-aligned & Centered Layout Fit
  fitToScreen(smooth = true) {
    if (!this.renderedNodes || this.renderedNodes.length === 0) return;

    const minX = Math.min(...this.renderedNodes.map(n => n.x));
    const maxX = Math.max(...this.renderedNodes.map(n => n.x + n.width));
    const minY = Math.min(...this.renderedNodes.map(n => n.y));
    const maxY = Math.max(...this.renderedNodes.map(n => n.y + n.height));

    const treeW = maxX - minX;
    const treeH = maxY - minY;

    const rect = this.container.getBoundingClientRect();
    const paddingX = 60;
    const paddingTop = 35;
    const paddingBottom = 60;

    const scaleX = (rect.width - paddingX * 2) / (treeW || 1);
    const scaleY = (rect.height - paddingTop - paddingBottom) / (treeH || 1);
    const targetScale = Math.min(Math.max(Math.min(scaleX, scaleY), 0.35), 0.95);

    // Center horizontally
    const targetX = (rect.width - treeW * targetScale) / 2 - minX * targetScale;
    // Align cleanly from the top (no empty void!)
    const targetY = paddingTop - minY * targetScale;

    if (smooth) {
      this.animateToTransform(targetX, targetY, targetScale, 480);
    } else {
      this.scale = targetScale;
      this.translateX = targetX;
      this.translateY = targetY;
      this.applyTransform();
    }
  }
}

window.ShajaraTree = ShajaraTree;
