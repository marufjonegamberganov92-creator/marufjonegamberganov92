@echo off
chcp 65001 >nul
title Sulola Shajarasi Veb Dasturi
color 0A

echo ========================================================
echo        🌳 SULOLA SHAJARASI DASTURI ISHGA TUSHMOQDA...
echo ========================================================
echo.

cd /d "%~dp0"

:: Brauzerni avtomatik ochish
start http://localhost:3000

:: Node serverni ishga tushirish
node server.js

pause
