/**
 * Shajara Backend API Bilan Aloqa Klienti
 */

const API = {
  TOKEN_KEY: 'shajara_admin_token',

  getToken() {
    return localStorage.getItem(this.TOKEN_KEY);
  },

  setToken(token) {
    if (token) {
      localStorage.setItem(this.TOKEN_KEY, token);
    } else {
      localStorage.removeItem(this.TOKEN_KEY);
    }
  },

  getHeaders(isJson = true) {
    const headers = {};
    if (isJson) {
      headers['Content-Type'] = 'application/json';
    }
    const token = this.getToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
  },

  async fetchData() {
    const res = await fetch('/api/data');
    if (!res.ok) throw new Error('Ma’lumotlarni yuklab bo‘lmadi');
    return await res.json();
  },

  async fetchStats() {
    const res = await fetch('/api/stats');
    if (!res.ok) throw new Error('Statistikani yuklab bo‘lmadi');
    return await res.json();
  },

  async login(password) {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Parol noto‘g‘ri');
    this.setToken(data.token);
    return data;
  },

  async checkAuth() {
    const token = this.getToken();
    if (!token) return false;
    try {
      const res = await fetch('/api/auth/status', {
        headers: this.getHeaders()
      });
      const data = await res.json();
      return !!data.authenticated;
    } catch {
      return false;
    }
  },

  logout() {
    this.setToken(null);
  },

  async saveMember(memberData, id = null) {
    const url = id ? `/api/members/${id}` : '/api/members';
    const method = id ? 'PUT' : 'POST';

    const res = await fetch(url, {
      method,
      headers: this.getHeaders(),
      body: JSON.stringify(memberData)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Saqlashda xatolik yuz berdi');
    return data;
  },

  async deleteMember(id) {
    const res = await fetch(`/api/members/${id}`, {
      method: 'DELETE',
      headers: this.getHeaders()
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'O‘chirishda xatolik yuz berdi');
    return data;
  },

  async uploadPhoto(file) {
    const formData = new FormData();
    formData.append('photo', file);

    const res = await fetch('/api/upload', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.getToken()}`
      },
      body: formData
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Rasm yuklashda xatolik');
    return data.photoUrl;
  },

  async updateDynasty(dynastyData) {
    const res = await fetch('/api/dynasty', {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(dynastyData)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Sulola ma’lumotlarini saqlab bo‘lmadi');
    return data;
  },

  async changePassword(currentPassword, newPassword) {
    const res = await fetch('/api/auth/change-password', {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ currentPassword, newPassword })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Parol o‘zgartirishda xatolik');
    return data;
  },

  async clearAllMembers() {
    const res = await fetch('/api/members/clear', {
      method: 'POST',
      headers: this.getHeaders()
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Ma’lumotlarni tozalab bo‘lmadi');
    return data;
  },

  async resetSeed() {
    const res = await fetch('/api/members/reset-seed', {
      method: 'POST',
      headers: this.getHeaders()
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Namunaviy ma’lumotlarni yuklab bo‘lmadi');
    return data;
  },

  async restoreBackup(backupJson) {
    const res = await fetch('/api/restore', {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(backupJson)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Zaxiradan tiklashda xatolik');
    return data;
  },

  async fetchMemories() {
    const res = await fetch('/api/memories');
    if (!res.ok) throw new Error('Esdaliklarni yuklab bo‘lmadi');
    const data = await res.json();
    return data.memories || [];
  },

  async saveMemory(memoryData, id = null) {
    const url = id ? `/api/memories/${id}` : '/api/memories';
    const method = id ? 'PUT' : 'POST';

    const res = await fetch(url, {
      method,
      headers: this.getHeaders(),
      body: JSON.stringify(memoryData)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Esdalikni saqlashda xatolik yuz berdi');
    return data;
  },

  async deleteMemory(id) {
    const res = await fetch(`/api/memories/${id}`, {
      method: 'DELETE',
      headers: this.getHeaders()
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Esdalikni o‘chirishda xatolik yuz berdi');
    return data;
  }
};

window.API = API;
