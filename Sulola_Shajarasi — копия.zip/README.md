# 🌳 Sulola Shajarasi (Family Tree Web Application)

O'zbek urf-odatlari va milliy an'analariga moslashtirilgan, interaktiv va zamonaviy **Sulola Shajarasi** veb-dasturi.

Ushbu dastur orqali har qanday qarindoshlar yoki mehmonlar veb-saytga kirib shajarani ko‘rishi, qidirishi va o‘rganishi mumkin. Ma’lumot kiritish, tahrirlash va o‘chirish esa faqat **Admin** (parol bilan himoyalangan) tomonidan amalga oshiriladi.

---

## 🚀 Qanday Ishga Tushiriladi?

### 1. Talablar
* Kompyuterda **Node.js** (v18 yoki undan yuqori) o‘rnatilgan bo‘lishi lozim.

### 2. Dasturni ishga tushirish
Terminal yoki PowerShell orqali loyiha papkasiga kiring:

```powershell
cd C:\Users\ids\.gemini\antigravity\scratch\shajara-app
```

Kutubxonalarni o‘rnatish (agar o‘rnatilmagan bo‘lsa):
```powershell
npm.cmd install
```

Serverni ishga tushirish:
```powershell
npm.cmd start
```

Brauzerda oching:
👉 **[http://localhost:3000](http://localhost:3000)**

---

## 🔐 Admin Hisobi (Boshqaruv)

* **Boshlang‘ich admin paroli:** `admin123`
* Tizimga kirish uchun yuqori o‘ng burchakdagi **"🔒 Admin Kirish"** tugmasini bosing.
* Kirgandan so‘ng yangi a’zo qo‘shish, tahrirlash, o‘chirish hamda sozlamalar tugmalari paydo bo‘ladi.
* **Parolni o‘zgartirish:** Sozlamalar (⚙️) menyusiga kirib o‘zingiz istagan yangi parolni o‘rnatishingiz mumkin.

---

## 🌟 Asosiy Imkoniyatlar

### 1. 🌳 Interaktiv Shajara Daraxti (Tree View)
* **Pan & Zoom:** Sichqoncha orqali shajarani erkin siljitish va kattalashtirish/kichraytirish.
* **Shoxlarni yig‘ish/ochish:** Katta sulolalarda ko‘rish qulay bo‘lishi uchun har bir ota-onaning bolalar shoxini bitta bosish bilan yopish yoki ochish (`—` / `+ N ta farzand`).
* **Bo‘g‘inlar va aloqalar:** Erkaklar (ko‘k), ayollar (pushti), turmush o‘rtoqlari va avlodlar zanjiri.
* **Markazlashtirish va fit:** Har qanday kattalikdagi shajarani bitta bosishda ekranga to‘liq moslashtirish.
* **Chop etish (Print / PDF):** Devorga ilish yoki arxiv uchun yuqori sifatli ko‘rinishda chop etish yoki PDF sifatida saqlash.

### 2. 📜 "Yetti Ajdod" Zanjiri
* O‘zbek an’analariga ko‘ra har bir o‘g‘il-qiz o‘zining 7 ota-bobosini bilishi zarur.
* Dasturda istalgan a’zoni tanlasangiz, uning to‘g‘ri ota zanjiri bo‘yicha 7 ajdodi:
  1. **O‘zi**
  2. **Otasi**
  3. **Bobosi**
  4. **Katta bobosi**
  5. **Bobokaloni**
  6. **Pushti kamari (Elobodo)**
  7. **Ajdod (Urug‘boshi)**
* Shohona ko‘rinishda suratlar, yashagan davrlari va unvonlari bilan chiqadi.

### 3. 🖼️ "Esdaliklar" va Foto-Arxiv (Yangi)
* Sulolaning qadimiy fotosuratlari, arxiv hujjatlari va qadrli xotiralari uchun maxsus galereya.
* **Surat yuklash:** Admin kompyuterdan to‘g‘ridan-to‘g‘ri surat yuklashi yoki URL kiritishi mumkin.
* **Ma’lumotlar:** Surat sarlavhasi, olingan yili/sanasi, joyi va tarixiy tavsifi.
* **Shaxslarni belgilash (Tag):** Suratda aynan qaysi sulola a’zolari borligini belgilab qo‘yish mumkin.
* **Lightbox (Katta ko‘rinish):** Suratni to‘liq ekranda ochib xotira matnini o‘qish va undagi shaxslarning profiliga o‘tish.
* **Shaxs profilida aks etish:** Shaxs kartasini ochganingizda, u qatnashgan barcha tarixiy fotosuratlar avtomatik ko‘rinadi.

### 4. 👥 Sulola A’zolari Ro‘yxati va Qidiruv
* Barcha a’zolarni tezkor filtrlar orqali saralash (avlodlar bo‘yicha, jinsi bo‘yicha, hayot yoki marhumlar).
* Real-vaqt rejimida F.I.Sh, kasb yoki tug‘ilgan joy bo‘yicha tezkor qidiruv.

### 4. 📊 Sulola Statistikasi (Analytics)
* Sulola a’zolarining umumiy soni, erkaklar va ayollar foizi.
* Avlodlar (bo‘g‘inlar) kesimida taqsimot.
* Suloladagi eng ko‘p tarqalgan kasblar va sohalar xaritasi.

### 5. 💾 Xavfsiz Zaxira (Backup & Restore)
* Shajara ma’lumotlari `data/shajara.json` faylida saqlanadi.
* Har safar ma’lumot o‘zgarganda tizim avtomatik ravishda `data/backups/` papkasiga zaxira nusxa oladi.
* Admin istalgan vaqtda bitta tugma bilan to‘liq zaxirani o‘z kompyuteriga yuklab olishi (JSON) yoki boshqa kompyuterga ko‘chirish uchun tiklashi mumkin.

---

## 📁 Loyiha Tuzilishi

```text
shajara-app/
├── server.js               # Express backend API, xavfsizlik va zaxiralash
├── package.json            # Loyiha sozlamalari
├── data/
│   ├── shajara.json        # Asosiy sulola ma'lumotlar bazasi
│   ├── config.json         # Admin paroli (bcrypt hash)
│   └── backups/            # Har bir o'zgarishda olinadigan avtomatik zaxiralar
├── uploads/                # A'zolarning fotosuratlari
└── public/                 # Foydalanuvchi interfeysi (Frontend)
    ├── index.html          # Asosiy sahifa va modallar
    ├── css/
    │   └── styles.css      # Maxsus uslublar, animatsiyalar va chop etish qoidalari
    └── js/
        ├── app.js          # Asosiy ilova kontrolleri
        ├── tree.js         # Interaktiv SVG daraxt vizualizatsiyasi
        ├── api.js          # Backend API klienti
        ├── admin.js        # Admin modallari va boshqaruv mantiqi
        └── relatives.js    # Qarindoshlik va 7 ajdod kalkulyatori
```

---

## 🌐 Internetga Joylashtirish (Deploy)

Ushbu dasturni butun qarindoshlar ko‘rishi uchun bepul yoki arzon bulutli serverlarga (masalan, **Render.com**, **Railway.app**, yoki o‘zingizning VPS serveringizga) bir necha daqiqada joylashtirish mumkin:
1. Kodni GitHub-ga yuklang.
2. Render / Railway-da yangi "Web Service" oching va ushbu repozitoriyni ulang.
3. Start command: `npm start`
4. Dastur jonli ishlay boshlaydi va o‘z domen manzilingizga ega bo‘ladi!
