/**
 * Shajara Admin Boshqaruv Tizimi
 */

const Admin = {
  isAdmin: false,
  editingMemberId: null,

  async init() {
    this.isAdmin = await API.checkAuth();
    this.updateAdminUI();
  },

  updateAdminUI() {
    const adminBadges = document.querySelectorAll('.admin-only');
    adminBadges.forEach(el => {
      if (this.isAdmin) {
        el.classList.remove('hidden');
      } else {
        el.classList.add('hidden');
      }
    });

    const guestBadges = document.querySelectorAll('.guest-only');
    guestBadges.forEach(el => {
      if (!this.isAdmin) {
        el.classList.remove('hidden');
      } else {
        el.classList.add('hidden');
      }
    });

    const authBtn = document.getElementById('auth-action-btn');
    if (authBtn) {
      if (this.isAdmin) {
        authBtn.innerHTML = `
          <span class="h-8 inline-flex items-center gap-1.5 text-xs font-serif font-semibold bg-emerald-800 hover:bg-emerald-900 text-amber-100 px-3 rounded-lg shadow-2xs transition border border-emerald-950">
            <svg class="w-3.5 h-3.5 text-amber-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
              <path d="m9 12 2 2 4-4"/>
            </svg>
            <span>Admin Faol</span>
            <span class="text-amber-200/40">|</span>
            <button type="button" class="hover:text-white hover:underline cursor-pointer flex items-center gap-1 text-amber-100" id="logout-sub-btn">
              <span>Chiqish</span>
              <svg class="w-3 h-3 text-amber-300/80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                <polyline points="16 17 21 12 16 7"/>
                <line x1="21" y1="12" x2="9" y2="12"/>
              </svg>
            </button>
          </span>
        `;
        const logoutSub = document.getElementById('logout-sub-btn');
        if (logoutSub) {
          logoutSub.addEventListener('click', (e) => {
            e.stopPropagation();
            this.logout();
          });
        }
      } else {
        authBtn.innerHTML = `
          <button id="open-login-btn" class="h-8 inline-flex items-center gap-1.5 text-xs font-serif font-semibold bg-stone-800 hover:bg-stone-900 text-amber-100 px-3 rounded-lg shadow-2xs transition border border-stone-950">
            <svg class="w-3.5 h-3.5 text-amber-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <rect width="18" height="11" x="3" y="11" rx="2" ry="2"/>
              <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
            </svg>
            <span>Admin Kirish</span>
          </button>
        `;
        const openLogin = document.getElementById('open-login-btn');
        if (openLogin) {
          openLogin.addEventListener('click', () => this.openLoginModal());
        }
      }
    }
  },

  openLoginModal() {
    const modal = document.getElementById('login-modal');
    if (!modal) return;
    const input = document.getElementById('admin-password-input');
    const err = document.getElementById('login-error-msg');
    if (input) input.value = '';
    if (err) err.classList.add('hidden');
    modal.classList.remove('hidden');
    setTimeout(() => input?.focus(), 50);
  },

  closeLoginModal() {
    const modal = document.getElementById('login-modal');
    if (modal) modal.classList.add('hidden');
  },

  async handleLogin() {
    const input = document.getElementById('admin-password-input');
    const err = document.getElementById('login-error-msg');
    const password = input ? input.value : '';

    if (!password) {
      if (err) {
        err.textContent = 'Parolni kiriting!';
        err.classList.remove('hidden');
      }
      return;
    }

    try {
      await API.login(password);
      this.isAdmin = true;
      this.closeLoginModal();
      this.updateAdminUI();
      App.showToast('Tizimga admin sifatida muvaffaqiyatli kirdingiz!', 'success');
      App.refreshAll();
    } catch (e) {
      if (err) {
        err.textContent = e.message;
        err.classList.remove('hidden');
      }
    }
  },

  logout() {
    API.logout();
    this.isAdmin = false;
    this.updateAdminUI();
    App.showToast('Admin rejimidan chiqildi.', 'info');
    App.refreshAll();
  },

  // Open modal to add or edit member
  openMemberModal(member = null, defaultParents = {}) {
    if (!this.isAdmin) {
      this.openLoginModal();
      return;
    }

    this.editingMemberId = member ? member.id : null;
    const modal = document.getElementById('member-form-modal');
    if (!modal) return;

    const titleEl = document.getElementById('member-modal-title');
    if (titleEl) {
      titleEl.textContent = member ? 'A’zo Ma’lumotlarini Tahrirlash' : 'Yangi Sulola A’zosini Qo‘shish';
    }

    // Populate Parent & Spouse Dropdowns
    this.populateMemberSelects(member ? member.id : null, defaultParents);

    // Fill form fields
    document.getElementById('form-first-name').value = member?.firstName || '';
    document.getElementById('form-last-name').value = member?.lastName || '';
    document.getElementById('form-middle-name').value = member?.middleName || '';
    document.getElementById('form-nickname').value = member?.nickname || '';

    // Gender
    const gender = member ? member.gender : (defaultParents.gender || 'male');
    const genderMaleRadio = document.getElementById('form-gender-male');
    const genderFemaleRadio = document.getElementById('form-gender-female');
    if (gender === 'female') {
      genderFemaleRadio.checked = true;
    } else {
      genderMaleRadio.checked = true;
    }

    // Dates
    document.getElementById('form-birth-year').value = member?.birthYear || '';
    document.getElementById('form-birth-date').value = member?.birthDate || '';
    document.getElementById('form-birth-place').value = member?.birthPlace || '';

    const isLiving = member ? member.isLiving : true;
    const isLivingCheck = document.getElementById('form-is-living');
    if (isLivingCheck) {
      isLivingCheck.checked = isLiving;
      this.toggleDeathFields(!isLiving);
    }

    document.getElementById('form-death-year').value = member?.deathYear || '';
    document.getElementById('form-death-date').value = member?.deathDate || '';
    document.getElementById('form-death-place').value = member?.deathPlace || '';

    // Profession, bio, photo
    document.getElementById('form-profession').value = member?.profession || '';
    document.getElementById('form-bio').value = member?.bio || '';
    document.getElementById('form-photo-url').value = member?.photoUrl || '';

    // Preview Photo
    this.updatePhotoPreview(member?.photoUrl || '');

    modal.classList.remove('hidden');
  },

  closeMemberModal() {
    const modal = document.getElementById('member-form-modal');
    if (modal) modal.classList.add('hidden');
    this.editingMemberId = null;
  },

  toggleDeathFields(show) {
    const container = document.getElementById('death-fields-container');
    if (container) {
      if (show) {
        container.classList.remove('hidden');
      } else {
        container.classList.add('hidden');
      }
    }
  },

  populateMemberSelects(currentMemberId, defaultParents = {}) {
    const members = App.members || [];
    const fatherSelect = document.getElementById('form-father-id');
    const motherSelect = document.getElementById('form-mother-id');
    const spouseSelect = document.getElementById('form-spouse-id');

    if (!fatherSelect || !motherSelect || !spouseSelect) return;

    fatherSelect.innerHTML = '<option value="">-- Otasi tanlanmagan --</option>';
    motherSelect.innerHTML = '<option value="">-- Onasi tanlanmagan --</option>';
    spouseSelect.innerHTML = '<option value="">-- Turmush o‘rtog‘i tanlanmagan --</option>';

    const currentMember = currentMemberId ? members.find(m => m.id === currentMemberId) : null;
    const fatherId = currentMember ? currentMember.fatherId : (defaultParents.fatherId || '');
    const motherId = currentMember ? currentMember.motherId : (defaultParents.motherId || '');
    const spouseId = currentMember?.spouseIds?.[0] || defaultParents.spouseId || '';

    members.forEach(m => {
      if (m.id === currentMemberId) return; // cannot be parent/spouse to oneself

      const label = `${m.firstName} ${m.lastName || ''} (${m.birthYear || '?'}) [${m.generation}-avlod]`;

      if (m.gender === 'male') {
        const opt = document.createElement('option');
        opt.value = m.id;
        opt.textContent = `👨 ${label}`;
        if (m.id === fatherId) opt.selected = true;
        fatherSelect.appendChild(opt);
      } else {
        const opt = document.createElement('option');
        opt.value = m.id;
        opt.textContent = `👩 ${label}`;
        if (m.id === motherId) opt.selected = true;
        motherSelect.appendChild(opt);
      }

      // Spouse list
      const spouseOpt = document.createElement('option');
      spouseOpt.value = m.id;
      spouseOpt.textContent = `${m.gender === 'male' ? '👨' : '👩'} ${label}`;
      if (m.id === spouseId) spouseOpt.selected = true;
      spouseSelect.appendChild(spouseOpt);
    });
  },

  updatePhotoPreview(url) {
    const preview = document.getElementById('photo-preview-img');
    const placeholder = document.getElementById('photo-preview-placeholder');
    if (!preview || !placeholder) return;

    if (url) {
      preview.src = url;
      preview.classList.remove('hidden');
      placeholder.classList.add('hidden');
    } else {
      preview.src = '';
      preview.classList.add('hidden');
      placeholder.classList.remove('hidden');
    }
  },

  async handlePhotoUpload(file) {
    if (!file) return;
    try {
      App.showToast('Rasm yuklanmoqda...', 'info');
      const photoUrl = await API.uploadPhoto(file);
      document.getElementById('form-photo-url').value = photoUrl;
      this.updatePhotoPreview(photoUrl);
      App.showToast('Rasm muvaffaqiyatli yuklandi!', 'success');
    } catch (err) {
      App.showToast(err.message, 'error');
    }
  },

  async handleSaveMember() {
    const firstName = document.getElementById('form-first-name').value.trim();
    if (!firstName) {
      App.showToast('Iltimos, ismni kiriting!', 'error');
      return;
    }

    const gender = document.getElementById('form-gender-female').checked ? 'female' : 'male';
    const isLiving = document.getElementById('form-is-living').checked;

    const memberData = {
      firstName,
      lastName: document.getElementById('form-last-name').value.trim(),
      middleName: document.getElementById('form-middle-name').value.trim(),
      nickname: document.getElementById('form-nickname').value.trim(),
      gender,
      birthYear: document.getElementById('form-birth-year').value || null,
      birthDate: document.getElementById('form-birth-date').value || '',
      birthPlace: document.getElementById('form-birth-place').value.trim(),
      isLiving,
      deathYear: !isLiving ? (document.getElementById('form-death-year').value || null) : null,
      deathDate: !isLiving ? (document.getElementById('form-death-date').value || '') : '',
      deathPlace: !isLiving ? document.getElementById('form-death-place').value.trim() : '',
      fatherId: document.getElementById('form-father-id').value || null,
      motherId: document.getElementById('form-mother-id').value || null,
      spouseIds: document.getElementById('form-spouse-id').value ? [document.getElementById('form-spouse-id').value] : [],
      profession: document.getElementById('form-profession').value.trim(),
      bio: document.getElementById('form-bio').value.trim(),
      photoUrl: document.getElementById('form-photo-url').value.trim()
    };

    try {
      App.showToast('Saqlanmoqda...', 'info');
      await API.saveMember(memberData, this.editingMemberId);
      this.closeMemberModal();
      App.showToast(
        this.editingMemberId ? 'A’zo ma’lumotlari muvaffaqiyatli yangilandi!' : 'Yangi a’zo shajaraga qo‘shildi!',
        'success'
      );
      await App.refreshAll();
    } catch (err) {
      App.showToast(err.message, 'error');
    }
  },

  async handleDeleteMember(id) {
    if (!this.isAdmin) return;
    const member = App.members.find(m => m.id === id);
    const name = member ? `${member.firstName} ${member.lastName || ''}` : 'ushbu a’zoni';

    if (!confirm(`Haqiqatan ham ${name} shajaradan o‘chirilsinmi?\nUnga bog‘langan qarindoshlik aloqalari avtomatik to‘g‘rilanadi.`)) {
      return;
    }

    try {
      App.showToast('O‘chirilmoqda...', 'info');
      await API.deleteMember(id);
      App.closePersonModal();
      App.showToast('A’zo muvaffaqiyatli o‘chirildi!', 'success');
      await App.refreshAll();
    } catch (err) {
      App.showToast(err.message, 'error');
    }
  },

  // Dynasty Settings & Backups Modal
  openSettingsModal() {
    if (!this.isAdmin) {
      this.openLoginModal();
      return;
    }

    const modal = document.getElementById('settings-modal');
    if (!modal) return;

    // Fill current dynasty info
    const dynasty = App.dynasty || {};
    document.getElementById('settings-dynasty-title').value = dynasty.title || '';
    document.getElementById('settings-dynasty-subtitle').value = dynasty.subtitle || '';
    document.getElementById('settings-dynasty-motto').value = dynasty.motto || '';

    // Populate root person selector
    const rootSelect = document.getElementById('settings-root-person');
    if (rootSelect) {
      rootSelect.innerHTML = '<option value="">-- Avtomatik aniqlash --</option>';
      (App.members || []).forEach(m => {
        const opt = document.createElement('option');
        opt.value = m.id;
        opt.textContent = `${m.gender === 'male' ? '👨' : '👩'} ${m.firstName} ${m.lastName || ''} (${m.birthYear || '?'})`;
        if (m.id === dynasty.rootPersonId) opt.selected = true;
        rootSelect.appendChild(opt);
      });
    }

    modal.classList.remove('hidden');
  },

  closeSettingsModal() {
    const modal = document.getElementById('settings-modal');
    if (modal) modal.classList.add('hidden');
  },

  async handleSaveDynastySettings() {
    const title = document.getElementById('settings-dynasty-title').value.trim();
    const subtitle = document.getElementById('settings-dynasty-subtitle').value.trim();
    const motto = document.getElementById('settings-dynasty-motto').value.trim();
    const rootPersonId = document.getElementById('settings-root-person').value || null;

    try {
      App.showToast('Sulola ma’lumotlari saqlanmoqda...', 'info');
      await API.updateDynasty({ title, subtitle, motto, rootPersonId });
      App.showToast('Sulola sozlamalari yangilandi!', 'success');
      await App.refreshAll();
    } catch (err) {
      App.showToast(err.message, 'error');
    }
  },

  async handleChangePassword() {
    const currentPass = document.getElementById('pass-current').value;
    const newPass = document.getElementById('pass-new').value;
    const confirmPass = document.getElementById('pass-confirm').value;

    if (!currentPass || !newPass) {
      App.showToast('Barcha parol maydonlarini to‘ldiring!', 'error');
      return;
    }
    if (newPass !== confirmPass) {
      App.showToast('Yangi parollar bir-biriga mos kelmadi!', 'error');
      return;
    }
    if (newPass.length < 5) {
      App.showToast('Yangi parol kamida 5 ta belgidan iborat bo‘lsin!', 'error');
      return;
    }

    try {
      await API.changePassword(currentPass, newPass);
      document.getElementById('pass-current').value = '';
      document.getElementById('pass-new').value = '';
      document.getElementById('pass-confirm').value = '';
      App.showToast('Admin paroli muvaffaqiyatli o‘zgartirildi!', 'success');
    } catch (err) {
      App.showToast(err.message, 'error');
    }
  },

  async handleDownloadBackup() {
    try {
      const token = API.getToken();
      const res = await fetch('/api/backup', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!res.ok) throw new Error('Zaxira nusxasini yuklab bo‘lmadi');
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `shajara_zaxira_${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      App.showToast('Zaxira fayli yuklab olindi!', 'success');
    } catch (err) {
      App.showToast(err.message, 'error');
    }
  },

  async handleRestoreBackup(file) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const json = JSON.parse(e.target.result);
        if (!confirm('Ushbu zaxira faylini tiklamoqchimisiz? Joriy ma’lumotlar yangilanadi.')) return;
        App.showToast('Tiklanmoqda...', 'info');
        await API.restoreBackup(json);
        this.closeSettingsModal();
        App.showToast('Shajara zaxiradan muvaffaqiyatli tiklandi!', 'success');
        await App.refreshAll();
      } catch (err) {
        App.showToast('Xatolik: Fayl JSON formati noto‘g‘ri yoki buzilgan: ' + err.message, 'error');
      }
    };
    reader.readAsText(file);
  },

  async handleClearAll() {
    if (!confirm('DIQQAT! Barcha sulola a’zolari o‘chiriladi va dastur bo‘sh holatga keladi.\nUshbu amalni bajarishdan oldin zaxira nusxasini yuklab olishingiz tavsiya etiladi.\n\nDavom ettirilsinmi?')) {
      return;
    }
    try {
      await API.clearAllMembers();
      this.closeSettingsModal();
      App.showToast('Barcha ma’lumotlar tozalandi!', 'info');
      await App.refreshAll();
    } catch (err) {
      App.showToast(err.message, 'error');
    }
  },

  async handleResetSeed() {
    if (!confirm('Namunaviy sulola ma’lumotlarini qayta yuklamoqchimisiz?')) return;
    try {
      await API.resetSeed();
      this.closeSettingsModal();
      App.showToast('Namunaviy shajara qayta yuklandi!', 'success');
      await App.refreshAll();
    } catch (err) {
      App.showToast(err.message, 'error');
    }
  },

  // ================= ESDALIKLAR (MEMORIES) BOSHQARUVI =================
  editingMemoryId: null,

  openMemoryModal(memory = null) {
    if (!this.isAdmin) {
      this.openLoginModal();
      return;
    }

    this.editingMemoryId = memory ? memory.id : null;
    const modal = document.getElementById('memory-form-modal');
    if (!modal) return;

    const titleEl = document.getElementById('memory-form-modal-title');
    if (titleEl) {
      titleEl.innerHTML = memory
        ? '<span>📷</span> Esdalikni Tahrirlash'
        : '<span>📷</span> Yangi Esdalik / Fotosurat Qo‘shish';
    }

    document.getElementById('memory-form-title').value = memory?.title || '';
    document.getElementById('memory-form-year').value = memory?.year || '';
    document.getElementById('memory-form-date').value = memory?.date || '';
    document.getElementById('memory-form-place').value = memory?.place || '';
    document.getElementById('memory-form-desc').value = memory?.description || '';
    document.getElementById('memory-url-input').value = memory?.imageUrl || '';

    // Preview
    this.updateMemoryPhotoPreview(memory?.imageUrl || '');

    // Tagged members checklist
    this.populateMemoryMembersChecklist(memory?.taggedMemberIds || []);

    modal.classList.remove('hidden');
  },

  closeMemoryModal() {
    const modal = document.getElementById('memory-form-modal');
    if (modal) modal.classList.add('hidden');
    this.editingMemoryId = null;
  },

  updateMemoryPhotoPreview(url) {
    const preview = document.getElementById('memory-preview-img');
    const placeholder = document.getElementById('memory-preview-placeholder');
    if (!preview || !placeholder) return;

    if (url) {
      preview.src = url;
      preview.classList.remove('hidden');
      placeholder.classList.add('hidden');
    } else {
      preview.src = '';
      preview.classList.add('hidden');
      placeholder.classList.remove('hidden');
    }
  },

  async handleMemoryPhotoUpload(file) {
    if (!file) return;
    try {
      App.showToast('Fotosurat yuklanmoqda...', 'info');
      const photoUrl = await API.uploadPhoto(file);
      document.getElementById('memory-url-input').value = photoUrl;
      this.updateMemoryPhotoPreview(photoUrl);
      App.showToast('Fotosurat muvaffaqiyatli yuklandi!', 'success');
    } catch (err) {
      App.showToast(err.message, 'error');
    }
  },

  populateMemoryMembersChecklist(selectedMemberIds = []) {
    const container = document.getElementById('memory-form-members-checklist');
    if (!container) return;

    const members = App.members || [];
    container.innerHTML = members.map(m => {
      const isChecked = selectedMemberIds.includes(m.id);
      const isMale = m.gender === 'male';
      return `
        <label class="flex items-center gap-2 p-1.5 rounded-lg hover:bg-[#faf5eb] border border-transparent hover:border-[#ded5c5] cursor-pointer transition">
          <input type="checkbox" name="tagged-member" value="${m.id}" ${isChecked ? 'checked' : ''} class="rounded text-amber-700 focus:ring-amber-500">
          <span class="w-4 h-4 rounded-full ${isMale ? 'bg-sky-100 text-sky-800' : 'bg-rose-100 text-rose-800'} text-[9px] font-serif font-bold flex items-center justify-center flex-shrink-0">
            ${m.firstName.charAt(0)}
          </span>
          <span class="text-xs truncate font-medium text-stone-800">${m.firstName} ${m.lastName || ''} <span class="text-stone-400">(${m.birthYear || '?'})</span></span>
        </label>
      `;
    }).join('');
  },

  async handleSaveMemory() {
    const title = document.getElementById('memory-form-title').value.trim();
    const imageUrl = document.getElementById('memory-url-input').value.trim();

    if (!title) {
      App.showToast('Iltimos, esdalik sarlavhasini kiriting!', 'error');
      return;
    }
    if (!imageUrl) {
      App.showToast('Iltimos, fotosurat yuklang yoki URL manzilini kiriting!', 'error');
      return;
    }

    const yearVal = document.getElementById('memory-form-year').value;
    const dateVal = document.getElementById('memory-form-date').value.trim();
    const placeVal = document.getElementById('memory-form-place').value.trim();
    const descVal = document.getElementById('memory-form-desc').value.trim();

    const taggedMemberIds = [];
    document.querySelectorAll('#memory-form-members-checklist input[type="checkbox"]:checked').forEach(cb => {
      taggedMemberIds.push(cb.value);
    });

    const memoryData = {
      title,
      imageUrl,
      year: yearVal ? parseInt(yearVal, 10) : null,
      date: dateVal,
      place: placeVal,
      description: descVal,
      taggedMemberIds
    };

    try {
      App.showToast('Esdalik saqlanmoqda...', 'info');
      await API.saveMemory(memoryData, this.editingMemoryId);
      this.closeMemoryModal();
      document.getElementById('memory-lightbox-modal')?.classList.add('hidden');
      App.showToast(
        this.editingMemoryId ? 'Esdalik muvaffaqiyatli yangilandi!' : 'Yangi esdalik foto-arxivga qo‘shildi!',
        'success'
      );
      await App.refreshAll();
    } catch (err) {
      App.showToast(err.message, 'error');
    }
  },

  async handleDeleteMemory(id) {
    if (!this.isAdmin) return;
    if (!confirm('Haqiqatan ham ushbu esdalik va fotosuratni arxivdan o‘chirmoqchimisiz?')) return;

    try {
      App.showToast('O‘chirilmoqda...', 'info');
      await API.deleteMemory(id);
      document.getElementById('memory-lightbox-modal')?.classList.add('hidden');
      App.showToast('Esdalik muvaffaqiyatli o‘chirildi!', 'success');
      await App.refreshAll();
    } catch (err) {
      App.showToast(err.message, 'error');
    }
  }
};

window.Admin = Admin;
