/**
 * Qarindoshlik Aloqalari va "Yetti Ajdod" Hisoblagichi
 */

const Relatives = {
  // O'zbek milliy an'anasidagi 7 ajdod nomlari
  ANCESTOR_TITLES: [
    { level: 1, title: "O'zi", desc: "Sulola davomchisi" },
    { level: 2, title: "Otasi", desc: "1-ajdod: Parvarish va tarbiya beruvchi zot" },
    { level: 3, title: "Bobosi", desc: "2-ajdod: Otaning otasi, xonadon oqsoqoli" },
    { level: 4, title: "Katta bobosi", desc: "3-ajdod: Boboning otasi" },
    { level: 5, title: "Bobokaloni", desc: "4-ajdod: Nasl suyanchig'i" },
    { level: 6, title: "Pushti kamari (Elobodo)", desc: "5-ajdod: Sulola tayanchi" },
    { level: 7, title: "Ajdod (Urug'boshi)", desc: "6-ajdod: Sulola shajarasi boshi" }
  ],

  // Berilgan shaxsning 7 ajdodini aniqlash (Ota zanjiri bo'yicha)
  getSevenAncestors(memberId, memberMap) {
    const list = [];
    let current = memberMap.get(memberId);
    let stepIndex = 0;

    while (current && stepIndex < 7) {
      const meta = this.ANCESTOR_TITLES[stepIndex] || {
        level: stepIndex + 1,
        title: `${stepIndex + 1}-ajdod`,
        desc: "Ajdodlar zanjiri"
      };

      list.push({
        step: stepIndex + 1,
        title: meta.title,
        desc: meta.desc,
        member: current
      });

      // Shajara an'anasiga ko'ra ota bo'yicha yuqorilanadi, agar otasi kiritilmagan bo'lsa onasi bo'yicha
      if (current.fatherId && memberMap.has(current.fatherId)) {
        current = memberMap.get(current.fatherId);
      } else if (current.motherId && memberMap.has(current.motherId)) {
        current = memberMap.get(current.motherId);
      } else {
        break;
      }
      stepIndex++;
    }

    return list;
  },

  // Bevosita qarindoshlarni aniqlash
  getImmediateFamily(memberId, members, memberMap) {
    const target = memberMap.get(memberId);
    if (!target) return null;

    const father = target.fatherId ? memberMap.get(target.fatherId) : null;
    const mother = target.motherId ? memberMap.get(target.motherId) : null;

    // Spouses
    const spouseIds = target.spouseIds || [];
    const spouses = spouseIds.map(id => memberMap.get(id)).filter(Boolean);
    members.forEach(m => {
      if (m.spouseIds && m.spouseIds.includes(memberId) && !spouses.some(s => s.id === m.id)) {
        spouses.push(m);
      }
    });

    // Children
    const children = members
      .filter(m => m.fatherId === memberId || m.motherId === memberId)
      .sort((a, b) => (a.birthYear || 9999) - (b.birthYear || 9999));

    // Siblings (share same father or mother, but not target)
    const siblings = members.filter(m => {
      if (m.id === memberId) return false;
      const sameFather = target.fatherId && m.fatherId === target.fatherId;
      const sameMother = target.motherId && m.motherId === target.motherId;
      return sameFather || sameMother;
    }).sort((a, b) => (a.birthYear || 9999) - (b.birthYear || 9999));

    return {
      target,
      father,
      mother,
      spouses,
      children,
      siblings
    };
  },

  // Qidiruv
  search(query, members) {
    if (!query || !query.trim()) return members;
    const q = query.toLowerCase().trim();

    return members.filter(m => {
      const fullName = `${m.firstName || ''} ${m.lastName || ''} ${m.middleName || ''} ${m.nickname || ''}`.toLowerCase();
      const prof = (m.profession || '').toLowerCase();
      const place = `${m.birthPlace || ''} ${m.deathPlace || ''}`.toLowerCase();
      const year = `${m.birthYear || ''} ${m.deathYear || ''}`;

      return fullName.includes(q) || prof.includes(q) || place.includes(q) || year.includes(q);
    });
  }
};

window.Relatives = Relatives;
